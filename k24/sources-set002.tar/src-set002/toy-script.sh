#!/bin/bash          
echo Hello World;
ls ~/ |fmt
