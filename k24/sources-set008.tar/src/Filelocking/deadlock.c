#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

main( ){
	int fd; 
	struct flock first_lock;
	struct flock second_lock;

	first_lock.l_type = F_WRLCK;
	first_lock.l_whence =  SEEK_SET;
	first_lock.l_start = 0 ;
	first_lock.l_len= 10;

	second_lock.l_type = F_WRLCK;
	second_lock.l_whence =  SEEK_SET;
	second_lock.l_start = 10;
	second_lock.l_len= 5;


	fd=open("locktest", O_RDWR);

	if ( fcntl(fd, F_SETLKW, &first_lock) == -1 )
		perror("-A:");
	printf("A: lock obtained by processs %d \n",getpid());

  	switch(fork()) {
  		case -1: 
			perror("error on fork");
			exit(1);
  		case 0:	/* child */
			if ( fcntl(fd, F_SETLKW, &second_lock) == -1 )
				perror("-B:");
			printf("B: lock obtained by process %d\n",getpid());

			if ( fcntl(fd, F_SETLKW, &first_lock) == -1 ){
				perror("-C:"); 
				printf("Process %d terminating\n",getpid());					exit(1);
				}
			else printf("C: lock obtained by process %d\n",getpid());
			printf("Process %d successfully acquired BOTH locks \n",getpid());
			exit(0);
		default: /* parent */
			printf("Parent process %d sleeping \n",getpid());
			sleep(10);
			if ( fcntl(fd, F_SETLK, &second_lock) == -1 ){
				perror("--D:");
				printf("Process %d about to terminate\n",getpid());
				}
  			else printf("D: lock obtained by process %d\n",getpid());
			sleep(1);
			printf("Process %d on its way out of here \n",getpid());
  	}
}
