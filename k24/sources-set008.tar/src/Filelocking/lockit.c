#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

main( ){
	int fd; 
	struct flock my_lock;

	my_lock.l_type = F_WRLCK;
	my_lock.l_whence =  SEEK_SET;
	my_lock.l_start = 0 ;
	my_lock.l_len= 10;

	fd=open("locktest", O_RDWR);

	// lock first 10 bytes  
	if ( fcntl(fd, F_SETLKW, &my_lock) == -1 ){
		perror("parent: locking");
    		exit(1);
    		}

	printf("parent: locked record \n");

  	switch(fork()){
  		case -1: 
			perror("fork"); exit(1);
  		case 0:
			printf("child: trying to lock file \n");
			my_lock.l_len = 5 ;
			if ( (fcntl(fd, F_SETLKW, &my_lock)) == -1 ){
				perror("child: problem in locking");
				exit(1);
				}
			printf("child: locked \n"); sleep(1);
			printf("child: exiting \n");
			fflush(stdout); fflush(stderr); exit(1);
		default:
			printf("parent: just about unlocking now \n");
			sleep(5);
			my_lock.l_type = F_UNLCK;
			printf("parent: unlocking -now- \n");
			if ( fcntl(fd, F_SETLK, &my_lock) == -1 ){
				perror("parent: problem in unlocking! \n");
				exit(1); }
  			printf("parent: has unlocked and is now exiting \n");
			fflush(stdout); fflush(stderr); wait(NULL);
  	}
	sleep(2);
}
