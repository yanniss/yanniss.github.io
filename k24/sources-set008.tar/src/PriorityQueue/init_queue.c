#include <stdio.h>
#include <stdlib.h>
#include "q.h"

int warn(char *s){
	fprintf(stderr,"Warning: %s\n",s);
}

int init_queue(void){
	int queue_id;

	if ( (queue_id = msgget(QKEY, IPC_CREAT | QPERM)) == -1 )
		perror("msgget failed");
	return(queue_id);
}

