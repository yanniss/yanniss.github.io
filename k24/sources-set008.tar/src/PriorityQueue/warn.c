#include <stdio.h>
#include <stdlib.h>
#include "q.h"

int warn(char *s){
	fprintf(stderr,"Warning: %s\n",s);
}

