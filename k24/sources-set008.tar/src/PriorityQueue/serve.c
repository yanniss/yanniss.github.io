#include "q.h"

int serve(void){
	int mlen, r_qid;
	struct q_entry r_entry;

	if ( (r_qid=init_queue()) == -1) return(-1);

	for(;;){
		if ( (mlen=msgrcv(r_qid, &r_entry, MAXOBN,		
			(-1 * MAXPRIOR) , MSG_NOERROR) ) == -1 ){
			perror("mesgrcv failed"); return(-1);
			}
		else {
			r_entry.mtext[mlen]='\0';
			proc_obj(&r_entry);
			}
		}
}
