#include <stdio.h>
#include <stdlib.h>
#include "q.h"

int enter(char *objname, int priority){
	int len, s_qid;
	struct q_entry s_entry;

	if ( (len=strlen(objname)) > MAXOBN){
		warn("name too long\n"); exit(1);
		}
	if ( priority > MAXPRIOR || priority < 0 ){
		warn("invalid priority level"); return(-1);
		}
	if ( (s_qid = init_queue()) == -1 ) return(-1);
	
	s_entry.mtype= (long)priority;
	strncpy(s_entry.mtext, objname, MAXOBN);

	if (msgsnd(s_qid, &s_entry, len, 0) == -1 ){
		perror("msgsnd failed"); return(-1);}
	else	return(0);
}

