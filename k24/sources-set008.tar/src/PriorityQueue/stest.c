#include <stdio.h>
#include <stdlib.h>
#include "q.h"

extern void server();

main(){
	pid_t pid;
	
	switch (pid=fork()){
	case 0:	// child
		serve();
		break;
	case -1:
		warn("fork to start the server failed");
		break;
	default:
		printf("server process pid is %d \n", pid);
	}
exit(pid != 1 ? 0 : 1);
}

int proc_obj(struct q_entry *msg){
	printf("\npriority: %ld name: %s\n", msg->mtype, msg->mtext);
	}
