#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>


#define TIME_MEM_KEY 99
#define TIME_SEM_KEY 9900
#define oops(m,x) { perror(m); exit(x); }

union semun{
	int val;
	struct semid_ds *buf;
	ushort *array;
	};

int seg_id, semset_id;

void cleanup(int);

set_sem_value(int semset_id, int semnum, int val){

	union semun initval;

        initval.val = val;
        if (semctl(semset_id, semnum, SETVAL, initval) == -1 )
                oops("semctl",4);
}

wait_and_lock(int semset_id){
        struct sembuf actions[2];

        actions[0].sem_num = 0;
        actions[0].sem_flg = SEM_UNDO;
        actions[0].sem_op = 0;

        actions[1].sem_num = 1;
        actions[1].sem_flg = SEM_UNDO;
        actions[1].sem_op = +1;

        if (semop(semset_id, actions, 2) == -1 ) oops("semop: locking", 10);
}

release_lock(int semset_id){
        struct sembuf actions[1];

        actions[0].sem_num = 1;
        actions[0].sem_flg = SEM_UNDO;
        actions[0].sem_op = -1;

        if (semop(semset_id, actions, 1) == -1 ) oops("semop: unlocking", 11);
}


main(){
char *mem_ptr;
long now;
int n;

seg_id = shmget( TIME_MEM_KEY, 100, 0666|IPC_CREAT );
if ( seg_id == -1 ) oops("shmget", 1);

mem_ptr = (char *)shmat (seg_id, NULL, 0);
if (mem_ptr == (char *) -1 ) oops("shmat",2);

semset_id = semget (TIME_SEM_KEY, 2, (0666| IPC_CREAT | IPC_EXCL));
if  ( semset_id == -1 ) oops("semget",1);

set_sem_value(semset_id, 0, 0 );
set_sem_value(semset_id, 1, 0 );

signal(SIGINT, cleanup);

for (n=0;n<60; n++){
	time(&now);
	printf("Time Server waiting for lock \n");
	wait_and_lock(semset_id);
	strcpy(mem_ptr, ctime(&now));
	printf("Time Server updating time %s",mem_ptr);
	release_lock(semset_id);
	printf("Time Server lets lock go \n");
	sleep(1);
	}
cleanup(0);
}

void cleanup(int n){
	shmctl(seg_id, IPC_RMID, NULL);   /* remove shared mem */
	semctl(semset_id, 0, IPC_RMID, NULL); /*remove sem set */
	printf("Cleaned up before exiting\n");
}

