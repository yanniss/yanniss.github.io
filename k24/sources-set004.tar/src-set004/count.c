#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#define BUFSIZE 27

main(){
	// char buffer[BUFSIZE];
	char *buffer=NULL;
	int  filedes;
	ssize_t nread;
	long total=0;

	if ((filedes=open("anotherfile", O_RDONLY))== -1){
		printf("error in opening anotherfile \n");
		exit(1);
		}
	
	while ( (nread=read(filedes,buffer,BUFSIZE)) > 0 )
		total += nread;
	printf("Total char in anotherfile %ld \n",total);
	exit(0);
}
