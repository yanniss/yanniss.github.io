#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>

void foohandler(int);
int flag=0;

int main(){
  int lpid=0; 
  printf("The process ID of this program is %d \n",getpid());
  lpid=getpid();
  signal(SIGINT, foohandler);
  while (flag==0){
	kill(lpid, SIGINT);
	pause();
	}
}

void foohandler(int signum){   /* no explicit call to handler foo */
  signal(SIGINT, foohandler);  /* re-establish handler for next time */
  flag=1;
}
