#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


main(int argc, char *argv[]){
struct stat mybuf;

if (argc<2) { exit(0);}

while(--argc){
  if (stat(*++argv, &mybuf) < 0) { 
        perror(*argv); continue;
        }

  if ((mybuf.st_mode & S_IFMT) == S_IFREG )
	printf("The time is: %s \n", (char *)(ctime(&mybuf.st_mtime)) );
  }
}


