#include <stdio.h>
#include <unistd.h>
#include <stdio.h>


main(){
	alarm(3); // schedule an alarm signal
	printf("Looping for good!");
	// fflush(NULL);
	while (1) ;
	printf("This line should be never part of the output\n");
	}
