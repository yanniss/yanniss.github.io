#include <stdio.h>
#include <signal.h>

main(){
  void  wakeup(int);

  printf("about to sleep for 5 seconds \n");
  signal(SIGALRM, wakeup);

  alarm(5);
  pause();
  printf("Hola Amigo\n");
}

void wakeup(int signum){
  printf("Alarm received from kernel\n");
}
