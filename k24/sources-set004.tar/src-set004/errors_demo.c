#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main(){
   FILE *fp=NULL;  char *p=NULL; int stat=0;

   fp=fopen("a_non_existent_file","r");

   if (fp == NULL) {
	printf("errno = %d \n", errno);
	perror("fopen");
	}

   p=(char *)malloc(2147483647);
   if (p==NULL) {
	printf("errno = %d \n",errno);
	perror("malloc");
	}
   else { printf("Carry on\n"); }
   
   stat=unlink("/etc/motd");
   if (stat == -1) {
	printf("errno = %d \n",errno);
        perror("unlink");
	}

   return(1);
}
