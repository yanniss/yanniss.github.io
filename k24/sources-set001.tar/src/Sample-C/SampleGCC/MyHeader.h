#include	<stdio.h>

#define	 	YES	1
#define		NO	2
#define		FALSE	20
#define		TRUE	30
#define		MAXSIZE	64

struct item{
	char 		*word;
	struct	item 	*next;
	};



/*
 *	ad@di.uoa.gr 03/02
 */
