
#include <stdio.h>

main(){
int i=0;

while(1) {;}
}
