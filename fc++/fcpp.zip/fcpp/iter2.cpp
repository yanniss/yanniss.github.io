#include <vector>
#include <iostream>
#include "prelude.hpp"

using namespace boost::fcpp;
using namespace std;

int main() {
   list<int> some_list;

   {
      vector<int> v;
      v.push_back(1);
      v.push_back(2);
      v.push_back(3);
      some_list = list<int>( v.begin(), v.end() );

      // Necessary to force evaluation, else dangling reference
      length( some_list );
   }
   while( some_list ) {
      cout << some_list.head() << " ";
      some_list = some_list.tail();
   }
   cout << endl;
}

