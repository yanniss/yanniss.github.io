#include <iostream>
#include "prelude.hpp"
using std::endl;
using std::cout;
using namespace boost::fcpp;

int main() {
   // These will die unless FCPP_DEBUG
   list<int> l;
   try {
      head(l);
   }
   catch( fcpp_exception& e ) {
      cout << e.what() << endl;
   }
   try {
      tail(l);
   }
   catch( fcpp_exception& e ) {
      cout << e.what() << endl;
   }

   odd_list<int> m;
   try {
      head(m);
   }
   catch( fcpp_exception& e ) {
      cout << e.what() << endl;
   }
   try {
      tail(m);
   }
   catch( fcpp_exception& e ) {
      cout << e.what() << endl;
   }

   list<int> huge = enum_from_to(1,200000);
   length(huge);
   // likely to blow stack unless FCPP_SAFE_LIST
}

