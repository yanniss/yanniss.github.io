#include <iostream>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::cout;
using std::endl;

struct Fact : public c_fun_type<int,int> {
   mutable int count;
   Fact() : count(0) {}
   int operator()( int x ) const {
      if( x==0 ) { cout << count << endl; return 1; }
      else { count++; return x * (*this)(x-1); }
   }
} fact;

int main() {
   cout << fact(5) << endl;
   cout << fact(5) << endl;

   Fact fa, fb;
   fun1<int,int> f = make_fun1( fa );
   fun1<int,int> g = make_fun1( fa );
   fun1<int,int> h = make_fun1( fb );

   f(7);
   g(8);
   h(9);
   
   fun1<int,int> i( h );
   i(2);

   return 0;
}
