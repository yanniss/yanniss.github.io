#include <iostream>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::cout;
using std::endl;

// take 5 (map odd [1..])
// [True,False,True,False,True]

int main() {
   list<int> li = enum_from( 1 );
   list<bool> lb = map( odd, li );
   lb = take( 5, lb );
   
   // or just
   
   lb = take( 5, map( odd, enum_from(1) ) );

   while( lb ) {
      cout << head(lb) << " ";
      lb = tail(lb);
   }
   cout << endl;
   return 0;
}
   
