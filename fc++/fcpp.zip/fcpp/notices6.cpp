#include <iostream>
#include <cassert>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::cout;
using std::endl;

bool prime( int x ) {
   if( x<2 ) return false;
   for( int i=2; i<x; i++ )
      if( x%i == 0 )
         return false;
   return true;
}

bool big( int x ) {
   return x > 100;
}

int main() {
   using boost::fcpp::plus;
   using boost::fcpp::minus;

   fun1<int,bool> f = make_fun1( ptr_to_fun(&prime) );
   assert( f(11) == true );
   f = make_fun1( ptr_to_fun(&big) );
   assert( f(11) == false );

   fun2<int,int,int> g = make_fun2( monomorphize2<int,int,int>( plus ) );
   assert( g(3,2) == 5 );
   g = minus;  // make_fun2 and monomorphize2 can be implicit
   assert( g(3,2) == 1 );

   cout << "ok" << endl;
}
