//
// Copyright (c) 2000-2003 Brian McNamara and Yannis Smaragdakis
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is granted without fee,
// provided that the above copyright notice and this permission notice
// appear in all source code copies and supporting documentation. The
// software is provided "as is" without any express or implied
// warranty.

#ifndef BOOST_FCPP_LIST_HPP
#define BOOST_FCPP_LIST_HPP

///////////////////////////////////////////////////////////////////////////
// Here we implement (lazy) lists in the list class.  There are also a
// number of functions associated with lists:
//  - head, tail, cons, cat, null
///////////////////////////////////////////////////////////////////////////

// Order-of-initialization debugging help
// Note that you only might need this with the BOOST_FCPP_1_3_LIST_IMPL version
#ifdef BOOST_FCPP_OOI_DEBUG
#include <iostream>
#include <typeinfo>
#endif

#include <exception>
#include <new>
#include <cstdlib>

#include "reuse.hpp"

namespace boost {
namespace fcpp {

struct fcpp_exception : public std::exception {
   const char* s;
   fcpp_exception( const char* ss ) : s(ss) {}
   const char* what() const throw() { return s; }
};

namespace impl {
struct XCons; struct XHead; struct XTail; struct XNull; struct XCat;

struct CacheEmpty {};
struct CacheDummy {};

template <class T> struct Cache;
template <class T> struct odd_list;
template <class T> struct list_iterator;
template <class T, class It> struct ListItHelp;
template <class U,class F> struct cvt;
template <class T, class F, class R> struct ListHelp;
template <class T> Cache<T>* xempty_helper();
template <class T, class F, class R> struct ConsHelp;

struct ListRaw {};

template <class T> 
class list {
   boost::intrusive_ptr<Cache<T> > rep; // never NIL, unless an empty odd_list

   template <class U> friend class Cache;
   template <class U> friend class odd_list;
   template <class U, class F, class R> friend struct ConsHelp;
   template <class U,class F> friend struct cvt;

   list( const boost::intrusive_ptr<Cache<T> >& p ) : rep(p) {}
   list( ListRaw, Cache<T>* p ) : rep(p) {}

   bool priv_isEmpty() const { 
      return rep->cache().second.rep == Cache<T>::XNIL(); 
   }
   T priv_head() const { 
#ifdef BOOST_FCPP_DEBUG
      if( priv_isEmpty() )
         throw fcpp_exception("Tried to take head() of empty list");
#endif
      return rep->cache().first(); 
   }
   list<T> priv_tail() const { 
#ifdef BOOST_FCPP_DEBUG
      if( priv_isEmpty() )
         throw fcpp_exception("Tried to take tail() of empty list");
#endif
      return rep->cache().second; 
   }
public:
   typedef T value_type;

   list( a_unique_type_for_nil ) : rep( Cache<T>::XEMPTY() ) {}
   list() : rep( Cache<T>::XEMPTY() ) {}

   template <class F>  // works on both ()->odd_list and ()->list 
   list( const F& f )
   : rep( ListHelp<T,F,typename F::result_type>()(f) ) {}

   // Note:  this constructor is still part of list and thus still lazy;
   // the iterators may not get evaluated until much later.  This is a
   // feature, not a bug.  So if the iterators are going to be invalidated
   // before you finish using the list, then you'd better force evaluation 
   // of the entire list before the iterators go away.
   template <class It>
   list( const It& begin, const It& end )
   : rep( new Cache<T>( ListItHelp<T,It>(begin,end) ) ) {}

   list( const odd_list<T>& e )
   : rep( (e.second.rep != Cache<T>::XNIL()) ? 
          new Cache<T>(e) : Cache<T>::XEMPTY() ) {}

#ifdef BOOST_FCPP_SAFE_LIST
   // Long lists create long recursions of destructors that blow the
   // stack.  So we have an iterative destructor.  It is quite tricky to
   // get right.  The danger is that, when "bypassing" a node to be
   // unlinked and destructed, that node's 'next' pointer is, in fact, a
   // list object, whose destructor will be called.  As a result, as you
   // bypass a node, you need to see if its refC is down to 1, and if
   // so, mutate its next pointer so that when its destructor is called,
   // it won't cause a recursive cascade.  
   ~list() {
      while( rep != Cache<T>::XNIL() && rep != Cache<T>::XBAD() ) {
         if( rep->refC == 1 ) {
            // This is a rotate(), but this sequence is actually faster
            // than rotate(), so we do it explicitly
            boost::intrusive_ptr<Cache<T> > tmp( rep );
            rep = rep->val.second.rep;
            tmp->val.second.rep = Cache<T>::XNIL();
         }
         else
            rep = rep->val.second.rep;
      }
   }
#endif

   operator bool() const { return !priv_isEmpty(); }
   const odd_list<T>& force() const { return rep->cache(); }
   const list<T>& delay() const { return *this; }
   // Note: force returns a reference; implicit conversion now returns a copy.
   operator odd_list<T>() const { return force(); }

   // VC++7.1 says line below makes "return l;" (when l is a list and
   // function returns an odd_list) illegal, and I think it's right.
   //operator const odd_list<T>&() const { return force(); }

   T head() const { return priv_head(); }
   list<T> tail() const { return priv_tail(); }

   // The following helps makes list almost an STL "container"
   typedef list_iterator<T> const_iterator;
   typedef const_iterator iterator;         // list is immutable
   iterator begin() const { return list_iterator<T>( *this ); }
   iterator end() const   { return list_iterator<T>(); }
};

struct OddListDummyX {};
struct OddListDummyY {};

template <class T> 
class odd_list {
   typedef 
      typename boost::type_with_alignment<boost::alignment_of<T>::value>::type
      fst_type;
   fst_type fst;

   const T& first() const { 
      return *static_cast<const T*>(static_cast<const void*>(&fst)); 
   }
   T& first() { 
      return *static_cast<T*>(static_cast<void*>(&fst));
   }
   list<T>  second;   // If XNIL, then this odd_list is NIL

   template <class U> friend class list;
   template <class U> friend class Cache;

   odd_list( OddListDummyX ) : second( Cache<T>::XNIL() ) { }

   odd_list( OddListDummyY )
   : second( Cache<T>::XBAD() ) { }

   void init( const T& x ) {
      new (static_cast<void*>(&fst)) T(x);
   } 

   bool fst_is_valid() const {
      if( second.rep != Cache<T>::XNIL() )
         if( second.rep != Cache<T>::XBAD() )
            return true;
      return false;
   }

   bool priv_isEmpty() const { return second.rep == Cache<T>::XNIL(); }
   T priv_head() const { 
#ifdef BOOST_FCPP_DEBUG
      if( priv_isEmpty() )
         throw fcpp_exception("Tried to take head() of empty odd_list");
#endif
      return first(); 
   }
   list<T> priv_tail() const { 
#ifdef BOOST_FCPP_DEBUG
      if( priv_isEmpty() )
         throw fcpp_exception("Tried to take tail() of empty odd_list");
#endif
      return second; 
   }

public:
   typedef T value_type;

   odd_list() : second( Cache<T>::XNIL() ) { }
   odd_list( a_unique_type_for_nil ) : second( Cache<T>::XNIL() ) { }
   odd_list( const T& x, const list<T>& y ) : second(y) { init(x); }
   odd_list( const T& x, a_unique_type_for_nil ) 
   : second(Cache<T>::XEMPTY()) { init(x); }

   odd_list( const odd_list<T>& x ) : second(x.second) {
      if( fst_is_valid() ) {
         init( x.first() );
      }
   }

   odd_list<T>& operator=( const odd_list<T>& x ) {
      if( this == &x ) return *this;  
      if( fst_is_valid() ) {
         if( x.fst_is_valid() )
            first() = x.first();
         else
            first().~T();
      }
      else {
         if( x.fst_is_valid() )
            init( x.first() );
      }
      second = x.second;
      return *this;
   }
      
   ~odd_list() {
      if( fst_is_valid() ) {
         first().~T(); 
      }
   }

   operator bool() const { return !priv_isEmpty(); }
   const odd_list<T>& force() const { return *this; }
   list<T> delay() const { return list<T>(*this); }

   T head() const { return priv_head(); }
   list<T> tail() const { return priv_tail(); }
};

// This converts ()->list<T> to ()->odd_list<T>.
// In other words, here is the 'extra work' done when using the
// unoptimized interface.
template <class U,class F>
struct cvt : public c_fun_type<odd_list<U> > {
   F f;
   cvt( const F& ff ) : f(ff) {}
   odd_list<U> operator()() const {
      list<U> l = f();
      return l.force();
   }
};

// I malloc a RefCountType to hold the refCount and init it to 1 to ensure the
// refCount will never get to 0, so the destructor-of-global-object
// order at the end of the program is a non-issue.  In other words, the
// memory allocated here is only reclaimed by the operating system.
template <class T> 
Cache<T>* xnil_helper() {
   void *p = std::malloc( sizeof(RefCountType) );
#ifdef BOOST_FCPP_OOI_DEBUG
   std::cout << "making a nil/bad:" << typeid(T).name() 
             << " at address " << p << std::endl;
#endif
   *((RefCountType*)p) = 1;
   return static_cast<Cache<T>*>( p );
}

template <class T> 
Cache<T>* xempty_helper() {
#ifdef BOOST_FCPP_1_3_LIST_IMPL
   (void) Cache<T>::xnil;   // Make sure xnil exists before moving forward
#endif
   return new Cache<T>( CacheEmpty() );
}

template <class T> 
class Cache : boost::noncopyable {
   mutable RefCountType refC;
   mutable fun0<odd_list<T> >   fxn;
   mutable odd_list<T>          val;
   // val.second.rep can be XBAD, XNIL, or a valid ptr
   //  - XBAD: val is invalid (fxn is valid)
   //  - XNIL: this is the empty list
   //  - anything else: val.first() is head, val.second is tail()

   // This functoid should never be called; it represents a
   // self-referent Cache, which should be impossible under the current
   // implementation.  Nonetheless, we need a 'dummy' function object to
   // represent invalid 'fxn's (val.second.rep!=XBAD), and this
   // implementation seems to be among the most reasonable.
   struct blackhole_helper : c_fun_type< odd_list<T> > {
      odd_list<T> operator()() const {
         throw fcpp_exception("You have entered a black hole.");
      }
   };
#ifdef BOOST_FCPP_1_3_LIST_IMPL
   static boost::intrusive_ptr<Cache<T> > xnil, xbad;
   static boost::intrusive_ptr<Cache<T> > xempty;
#endif

   // Don't get rid of these XFOO() functions; they impose no overhead,
   // and provide a useful place to add debugging code for tracking down
   // before-main()-order-of-initialization problems.
   static const boost::intrusive_ptr<Cache<T> >& XEMPTY() {
#ifndef BOOST_FCPP_1_3_LIST_IMPL
      static boost::intrusive_ptr<Cache<T> > xempty( xempty_helper<T>() );
#endif
#ifdef BOOST_FCPP_OOI_DEBUG
      static bool b = true;
      if(b) {
         std::cout << "access xempty:" << typeid(T).name() << std::endl;
         b = false;
      }
#endif
      return xempty;
   }
   static const boost::intrusive_ptr<Cache<T> >& XNIL() {    // this list is nil
#ifndef BOOST_FCPP_1_3_LIST_IMPL
      static boost::intrusive_ptr<Cache<T> > xnil( xnil_helper<T>() );
#endif
#ifdef BOOST_FCPP_OOI_DEBUG
      static bool b = true;
      if(b) {
         std::cout << "access xnil:" << typeid(T).name() << std::endl;
         b = false;
      }
#endif
      return xnil;
   }
   static const boost::intrusive_ptr<Cache<T> >& XBAD() {    // the pair is invalid; use fxn
#ifndef BOOST_FCPP_1_3_LIST_IMPL
      static boost::intrusive_ptr<Cache<T> > xbad( xnil_helper<T>() );
#endif
#ifdef BOOST_FCPP_OOI_DEBUG
      static bool b = true;
      if(b) {
         std::cout << "access xbad:" << typeid(T).name() << std::endl;
         b = false;
      }
#endif
      return xbad;
   }
   static fun0<odd_list<T> > the_blackhole;
   static fun0<odd_list<T> >& blackhole() {
#ifndef BOOST_FCPP_1_3_LIST_IMPL
      static fun0<odd_list<T> > the_blackhole( make_fun0( blackhole_helper() ) );
#endif
      return the_blackhole;
   }

   odd_list<T>& cache() const {
      if( val.second.rep == XBAD() ) {
         val = fxn();
         fxn = blackhole();
      }
      return val;
   }

   template <class U> friend class list;
   template <class U> friend class odd_list;
   template <class U, class F, class R> friend struct ConsHelp;
   template <class U,class F> friend struct cvt;
   template <class U, class F, class R> friend struct ListHelp;
   template <class U> friend Cache<U>* xempty_helper();

   Cache( CacheEmpty ) : refC(0), fxn(blackhole()), val() {}
   Cache( const odd_list<T>& x ) : refC(0), fxn(blackhole()), val(x) {}
   Cache( const T& x, const list<T>& l ) : refC(0),fxn(blackhole()),val(x,l) {}
   Cache( CacheDummy ) : refC(0), fxn(blackhole()), val( OddListDummyX() ) {}

   Cache( const fun0<odd_list<T> >& f )
   : refC(0), fxn(f), val( OddListDummyY() ) {}

   template <class F>
   Cache( const F& f )    // ()->odd_list
   : refC(0), fxn(make_fun0(f)), val( OddListDummyY() ) {}

   // This is for ()->list<T> to ()->odd_list<T>
   struct CvtFxn {};
   template <class F>
   Cache( CvtFxn, const F& f )    // ()->list
   : refC(0), fxn(make_fun0(cvt<T,F>(f))), val( OddListDummyY() ) {}

   template <class X>
   friend void intrusive_ptr_add_ref( const Cache<X>* p );
   template <class X>
   friend void intrusive_ptr_release( const Cache<X>* p );
};
template <class T>
void intrusive_ptr_add_ref( const Cache<T>* p ) {
   ++ (p->refC);
}
template <class T>
void intrusive_ptr_release( const Cache<T>* p ) {
   if( !--(p->refC) ) delete p;
}

#ifdef BOOST_FCPP_1_3_LIST_IMPL
template <class T>
fun0<odd_list<T> > Cache<T>::the_blackhole( make_fun0( blackhole_helper() ) );

template <class T> boost::intrusive_ptr<Cache<T> > 
Cache<T>::xnil( xnil_helper<T>() );
template <class T> boost::intrusive_ptr<Cache<T> > 
Cache<T>::xbad( xnil_helper<T>() );
template <class T> boost::intrusive_ptr<Cache<T> > 
Cache<T>::xempty( xempty_helper<T>() );
#endif

// Rest of list's stuff

template <class T, class F> struct ListHelp<T,F,list<T> > {
   boost::intrusive_ptr<Cache<T> > operator()( const F& f ) const {
      return boost::intrusive_ptr<Cache<T> >
         (new Cache<T>(Cache<T>::CvtFxn(),f));
   }
};
template <class T, class F> struct ListHelp<T,F,odd_list<T> > {
   boost::intrusive_ptr<Cache<T> > operator()( const F& f ) const {
      return boost::intrusive_ptr<Cache<T> >(new Cache<T>(f));
   }
};

template <class T, class It>
struct ListItHelp : public c_fun_type<odd_list<T> > {
   It begin, end;
   ListItHelp( const It& b, const It& e ) : begin(b), end(e) {}
   odd_list<T> operator()() const;
};
   
template <class T>
class list_iterator 
: public std::iterator<std::input_iterator_tag,T,ptrdiff_t> {
   list<T> l;
   bool is_nil;
   void advance() {
      l = l.tail();
      if( !l )
         is_nil = true;
   }
   class Proxy {  // needed for operator->
      const T x;
      friend class list_iterator;
      Proxy( const T& xx ) : x(xx) {}
   public:
      const T* operator->() const { return &x; }
   };
public:
   list_iterator() : l(), is_nil(true) {}
   explicit list_iterator( const list<T>& ll ) : l(ll), is_nil(!ll) {}

   const T operator*() const { return l.head(); }
   const Proxy operator->() const { return Proxy(l.head()); }
   list_iterator<T>& operator++() {
      advance();
      return *this;
   }
   const list_iterator<T> operator++(int) {
      list_iterator<T> i( *this );
      advance();
      return i;
   }
   bool operator==( const list_iterator<T>& i ) const {
      return is_nil && i.is_nil;
   }
   bool operator!=( const list_iterator<T>& i ) const {
      return ! this->operator==(i);
   }
};
}

using impl::list;
using impl::odd_list;
using impl::list_iterator;

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

namespace impl{
struct XHead {
   template <class LT>
   struct sig : public fun_type<LT,typename LT::value_type> {};

   template <class T>
   T operator()( const list<T>& l ) const {
      return l.head();
   }
   template <class T>
   T operator()( const odd_list<T>& l ) const {
      return l.head();
   }
};
}
typedef full1<impl::XHead> head_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN head_type head;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

namespace impl {
struct XTail {
   template <class LT>
   struct sig : public fun_type<LT,list<typename LT::value_type> > {};

   template <class T>
   list<T> operator()( const list<T>& l ) const {
      return l.tail();
   }
   template <class T>
   list<T> operator()( const odd_list<T>& l ) const {
      return l.tail();
   }
};
}
typedef full1<impl::XTail> tail_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN tail_type tail;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

namespace impl {
struct XNull {
   template <class LT>
   struct sig : public fun_type<LT,bool> {};

   template <class T>
   bool operator()( const list<T>& l ) const {
      return !l;
   }
   template <class T>
   bool operator()( const odd_list<T>& l ) const {
      return !l;
   }
};
}
typedef full1<impl::XNull> null_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN null_type null;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

namespace impl {
template <class T, class F> struct ConsHelp<T,F,list<T> > {
   odd_list<T> operator()( const T& x, const F& f ) const {
      return odd_list<T>(x, list<T>(
         boost::intrusive_ptr<Cache<T> >(new Cache<T>(Cache<T>::CvtFxn(),f))));
   }
};
template <class T, class F> struct ConsHelp<T,F,odd_list<T> > {
   odd_list<T> operator()( const T& x, const F& f ) const {
      return odd_list<T>(x, list<T>( ListRaw(), new Cache<T>(f) ));
   }
};
struct XCons {
   template <class T, class L>
   struct sig : public fun_type<T,L,odd_list<T> > {};

   template <class T>
   odd_list<T> operator()( const T& x, const list<T>& l ) const {
      return odd_list<T>(x,l);
   }
   template <class T>
   odd_list<T> operator()( const T& x, const odd_list<T>& l ) const {
      return odd_list<T>(x,l);
   }
   template <class T>
   odd_list<T> operator()( const T& x, const a_unique_type_for_nil& ) const {
      return odd_list<T>(x,NIL);
   }

   template <class T, class F>
   odd_list<T> operator()( const T& x, const F& f ) const {
      return ConsHelp<T,F,typename F::result_type>()(x,f);
   }
};
}
typedef full2<impl::XCons> cons_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN cons_type cons;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

template <class T, class It>
odd_list<T> impl::ListItHelp<T,It>::operator()() const {
   if( begin == end ) return NIL;
   It tmp = begin;
   T x( *begin );
   return cons( x, ListItHelp<T,It>( ++tmp, end ) );
}

namespace impl {
class XCat {
   // The Intel compiler doesn't like it when I overload this function,
   // so I just used class template partial specialization in a nested
   // helper class to code around it.
   template <class L, class M>
   struct Helper : public c_fun_type<L,M,odd_list<typename L::value_type> > {
      odd_list<typename L::value_type> 
      operator()( const L& l, const M& m, 
             reuser2<INV,VAR,INV,Helper,list<typename L::value_type>,M>
             r = NIL ) const {
         if( null(l) ) 
            return m().force();
         else
            return cons( head(l), r( *this, tail(l), m ) );
      }
   };
   template <class L, class T>
   struct Helper<L,list<T> >
   : public c_fun_type<L,list<T>,odd_list<typename L::value_type> > {
      odd_list<T> 
      operator()( const L& l, const list<T>& m,
             reuser2<INV,VAR,INV,Helper,list<typename L::value_type>,list<T> >
             r = NIL ) const {
         if( null(l) ) 
            return m.force();
         else
            return cons( head(l), r( *this, tail(l), m ) );
      }
   };
   template <class L, class T>
   struct Helper<L,odd_list<T> > 
   : public c_fun_type<L,odd_list<T>,odd_list<typename L::value_type> > {
      odd_list<T> 
      operator()( const L& l, const odd_list<T>& m,
          reuser2<INV,VAR,INV,Helper,list<typename L::value_type>,odd_list<T> >
          r = NIL ) const {
         if( null(l) ) 
            return m;
         else
            return cons( head(l), r( *this, tail(l), m ) );
      }
   };
   template <class L>
   struct Helper<L,a_unique_type_for_nil> 
   : public c_fun_type<L,
                  a_unique_type_for_nil,odd_list<typename L::value_type> > {
      odd_list<typename L::value_type> 
      operator()( const L& l, const a_unique_type_for_nil& ) const {
         return l;
      }
   };
public:
   template <class L, class M>
   struct sig : public fun_type<L,M,odd_list<typename L::value_type> > {};

   // Note: first arg must be a list, but second arg can be either a list 
   // or a function that returns a list.
   template <class L, class M>
   odd_list<typename L::value_type> 
   operator()( const L& l, const M& m ) const {
      return Helper<L,M>()(l,m);
   }
};
}
typedef full2<impl::XCat> cat_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN cat_type cat;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

namespace impl {
struct XDelay {
   template <class L>
   struct sig : public fun_type<L,list<typename L::value_type> > {};

   template <class L>
   list<typename L::value_type> operator()( const L& l ) const {
      return l.delay();
   }
};
}
typedef full1<impl::XDelay> delay_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN delay_type delay;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

namespace impl {
struct XForce {
   template <class L>
   struct sig : public fun_type<L,odd_list<typename L::value_type> > {};

   template <class L>
   odd_list<typename L::value_type> operator()( const L& l ) const {
      return l.force();
   }
};
}
typedef full1<impl::XForce> force_type;
BOOST_FCPP_MAYBE_NAMESPACE_OPEN
BOOST_FCPP_MAYBE_EXTERN force_type force;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

//////////////////////////////////////////////////////////////////////
// op== and op<, overloaded for all combos of list, odd_list, and NIL
//////////////////////////////////////////////////////////////////////

template <class T>
bool operator==( const odd_list<T>& a, a_unique_type_for_nil ) {
   return null(a);
}
template <class T>
bool operator==( const list<T>& a, a_unique_type_for_nil ) {
   return null(a);
}
template <class T>
bool operator==( a_unique_type_for_nil, const odd_list<T>& a ) {
   return null(a);
}
template <class T>
bool operator==( a_unique_type_for_nil, const list<T>& a ) {
   return null(a);
}
template <class T>
bool operator==( const list<T>& a, const list<T>& b ) {
   if( null(a) && null(b) )
      return true;
   if( null(a) || null(b) )
      return false;
   return (head(a)==head(b)) && (tail(a)==tail(b));
}
template <class T>
bool operator==( const odd_list<T>& a, const odd_list<T>& b ) {
   if( null(a) && null(b) )
      return true;
   if( null(a) || null(b) )
      return false;
   return (head(a)==head(b)) && (tail(a)==tail(b));
}
template <class T>
bool operator==( const list<T>& a, const odd_list<T>& b ) {
   if( null(a) && null(b) )
      return true;
   if( null(a) || null(b) )
      return false;
   return (head(a)==head(b)) && (tail(a)==tail(b));
}
template <class T>
bool operator==( const odd_list<T>& a, const list<T>& b ) {
   if( null(a) && null(b) )
      return true;
   if( null(a) || null(b) )
      return false;
   return (head(a)==head(b)) && (tail(a)==tail(b));
}

template <class T>
bool operator<( const list<T>& a, const list<T>& b ) {
   if( null(a) && !null(b) )  return true;
   if( null(b) )              return false;
   if( head(b) < head(a) )    return false;
   if( head(a) < head(b) )    return true;
   return (tail(a) < tail(b));
}
template <class T>
bool operator<( const odd_list<T>& a, const list<T>& b ) {
   if( null(a) && !null(b) )  return true;
   if( null(b) )              return false;
   if( head(b) < head(a) )    return false;
   if( head(a) < head(b) )    return true;
   return (tail(a) < tail(b));
}
template <class T>
bool operator<( const list<T>& a, const odd_list<T>& b ) {
   if( null(a) && !null(b) )  return true;
   if( null(b) )              return false;
   if( head(b) < head(a) )    return false;
   if( head(a) < head(b) )    return true;
   return (tail(a) < tail(b));
}
template <class T>
bool operator<( const odd_list<T>& a, const odd_list<T>& b ) {
   if( null(a) && !null(b) )  return true;
   if( null(b) )              return false;
   if( head(b) < head(a) )    return false;
   if( head(a) < head(b) )    return true;
   return (tail(a) < tail(b));
}
template <class T>
bool operator<( const odd_list<T>&, a_unique_type_for_nil ) {
   return false;
}
template <class T>
bool operator<( const list<T>&, a_unique_type_for_nil ) {
   return false;
}
template <class T>
bool operator<( a_unique_type_for_nil, const odd_list<T>& b ) {
   return !null(b);
}
template <class T>
bool operator<( a_unique_type_for_nil, const list<T>& b ) {
   return !null(b);
}

//////////////////////////////////////////////////////////////////////
// Handy functions for making list literals
//////////////////////////////////////////////////////////////////////
// Yes, these aren't functoids, they're just template functions.  I'm
// lazy and created these mostly to make it easily to make little lists
// in the sample code snippets that appear in papers.

template <class T>
list<T> list_with( const T& a ) {
   list<T> l;
   l = cons( a, l );
   return l;
}

template <class T>
list<T> list_with( const T& a, const T& b ) {
   list<T> l;
   l = cons( b, l );
   l = cons( a, l );
   return l;
}

template <class T>
list<T> list_with( const T& a, const T& b, const T& c ) {
   list<T> l;
   l = cons( c, l );
   l = cons( b, l );
   l = cons( a, l );
   return l;
}

template <class T>
list<T> list_with( const T& a, const T& b, const T& c, const T& d ) {
   list<T> l;
   l = cons( d, l );
   l = cons( c, l );
   l = cons( b, l );
   l = cons( a, l );
   return l;
}

template <class T>
list<T> 
list_with( const T& a, const T& b, const T& c, const T& d, const T& e ) {
   list<T> l;
   l = cons( e, l );
   l = cons( d, l );
   l = cons( c, l );
   l = cons( b, l );
   l = cons( a, l );
   return l;
}

} // namespace fcpp
} // namespace boost

#endif
