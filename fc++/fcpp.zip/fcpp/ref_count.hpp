//
// Copyright (c) 2000-2003 Brian McNamara and Yannis Smaragdakis
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is granted without fee,
// provided that the above copyright notice and this permission notice
// appear in all source code copies and supporting documentation. The
// software is provided "as is" without any express or implied
// warranty.

#ifndef BOOST_FCPP_REF_HPP
#define BOOST_FCPP_REF_HPP

#include "config.hpp"
#include "boost/intrusive_ptr.hpp"
#include "boost/shared_ptr.hpp"

namespace boost {
namespace fcpp {
   typedef unsigned int RefCountType;
} // end namespace fcpp 
} // end namespace boost 

#endif
