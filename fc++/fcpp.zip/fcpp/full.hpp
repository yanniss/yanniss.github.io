//
// Copyright (c) 2000-2003 Brian McNamara and Yannis Smaragdakis
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is granted without fee,
// provided that the above copyright notice and this permission notice
// appear in all source code copies and supporting documentation. The
// software is provided "as is" without any express or implied
// warranty.

#ifndef BOOST_FCPP_FULL_HPP
#define BOOST_FCPP_FULL_HPP

#include "smart.hpp"
#include "curry.hpp"
#include "pre_lambda.hpp"

namespace boost {
namespace fcpp {

//////////////////////////////////////////////////////////////////////
// Full functoids
//////////////////////////////////////////////////////////////////////
// Just as curryable2/curryable3 serve as wrappers which decorate
// functoids to give them 'curryability', fulln are wrappers to give
// functoids _all_ the 'features' that functoids can have.  The current
// "extra feature set" for functoids is
//   - curryability     (ability to call with fewer args)
//   - lambda-awareness (operator[] for use inside lambda)
//   - smartness        (inherited typedefs to answer introspective questions)
// The fulln classes just combine all of the features into one
// uber-wrapper which does it all.

// Don't forget that any features added here need to be added to 
// the indirect functoids in function.h, too.
// And also to the Uncurryable class in prelude.h.

// FIX THIS: It would be swell if fullN could detect if the functoid it
// wraps is monomorphic, so that it can export the monomorphic
// interfaces (to work like old STL adaptables).  Then again, result_of
// might make that never worth implementing.

template <class F>
class full0 
: public smart_functoid0, public c_fun_type<typename RT<F>::result_type> {
   F f;
public:
   full0() : f() {}
   full0( const F& ff ) : f(ff) {}
#ifdef BOOST_FCPP_ENABLE_LAMBDA
   typedef full0 This;
   template <class A> typename fcpp_lambda::BracketCallable<This,A>::Result
   operator[]( const A& a ) const
   { return fcpp_lambda::BracketCallable<This,A>::go( *this, a ); }
#endif
   inline typename RT<F>::result_type operator()() const {
      return f();
   }
};

template <class F>
class full1 : public smart_functoid1 {
   F f;
public:
   full1() : f() {}
   full1( const F& ff ) : f(ff) {}
#ifdef BOOST_FCPP_ENABLE_LAMBDA
   typedef full1 This;
   template <class A> typename fcpp_lambda::BracketCallable<This,A>::Result
   operator[]( const A& a ) const
   { return fcpp_lambda::BracketCallable<This,A>::go( *this, a ); }
#endif
   template <class T> struct sig 
      : public fun_type<typename RT<F,T>::arg1_type,
                       typename RT<F,T>::result_type> {};
   template <class T>
   inline typename sig<T>::result_type operator()( const T& x ) const {
      return f(x);
   }
   template <class X> struct result;
   template <class Me, class X>
   struct result<Me(X)> : public Type<typename sig<X>::result_type> {};
};

template <class F>
class full2 : public smart_functoid2 {
   F f;
public:
   full2() : f() {}
   full2( const F& ff ) : f(ff) {}
#ifdef BOOST_FCPP_ENABLE_LAMBDA
   typedef full2 This;
   template <class A> typename fcpp_lambda::BracketCallable<This,A>::Result
   operator[]( const A& a ) const
   { return fcpp_lambda::BracketCallable<This,A>::go( *this, a ); }
#endif
/////////////  copied from curryable2; added impl:: to binders  //////
   template <class X, class Y=void>
   struct sig
   : public fun_type<typename F::template sig<X,Y>::arg1_type,
                    typename F::template sig<X,Y>::arg2_type,
                    typename RT<F,X,Y>::result_type> {};

   template <class X>
   struct sig<X,void> : public fun_type<X,full1<impl::binder1of2<F,X> > > {};

   template <class Y>
   struct sig<auto_curry_type,Y>
   : public fun_type<auto_curry_type,Y,full1<impl::binder2of2<F,Y> > > {};

   template <class X>
   struct sig<X,auto_curry_type>
   : public fun_type<X,auto_curry_type,full1<impl::binder1of2<F,X> > > {};

   template <class X>
   typename sig<X>::result_type operator()( const X& x ) const {
      return make_full1( impl::binder1of2<F,X>(f,x) );
   }
   template <class X, class Y>
   inline typename sig<X,Y>::result_type
   operator()( const X& x, const Y& y ) const {
      // need partial specialization, so defer to a class helper
return impl::Curryable2Helper<typename sig<X,Y>::result_type,F,X,Y>::go(f,x,y);
   }
//////////////////////////////////////////////////////////////////////
   template <class X> struct result;
   template <class Me, class X, class Y>
   struct result<Me(X,Y)> : public Type<typename sig<X,Y>::result_type> {};
   template <class Me, class X>
   struct result<Me(X)> : public Type<typename sig<X,void>::result_type> {};
};

template <class F>
class full3 : public smart_functoid3 {
   F f;
public:
   full3() : f() {}
   full3( const F& ff ) : f(ff) {}
#ifdef BOOST_FCPP_ENABLE_LAMBDA
   typedef full3 This;
   template <class A> typename fcpp_lambda::BracketCallable<This,A>::Result
   operator[]( const A& a ) const
   { return fcpp_lambda::BracketCallable<This,A>::go( *this, a ); }
#endif
/////////////  copied from curryable3; added impl:: to all binders  //
   template <class X, class Y=void, class Z=void>
   struct sig
   : public fun_type<typename F::template sig<X,Y,Z>::arg1_type,
                    typename F::template sig<X,Y,Z>::arg2_type,
                    typename F::template sig<X,Y,Z>::arg3_type,
                    typename RT<F,X,Y,Z>::result_type> {};

   template <class X,class Y> struct sig<X,Y,void>
   : public fun_type<X,Y,full1<impl::binder1and2of3<F,X,Y> > > {};

   template <class X> struct sig<X,auto_curry_type,void>
   : public fun_type<X,auto_curry_type,full2<impl::binder1of3<F,X> > > {};

   template <class Y> struct sig<auto_curry_type,Y,void>
   : public fun_type<auto_curry_type,Y,full2<impl::binder2of3<F,Y> > > {};

   template <class X> struct sig<X,void,void>
   : public fun_type<X,full2<impl::binder1of3<F,X> > > {};

   template <class X> struct sig<X,auto_curry_type,auto_curry_type>
   : public fun_type<X,auto_curry_type,auto_curry_type,
                    full2<impl::binder1of3<F,X> > > {};

   template <class Y> struct sig<auto_curry_type,Y,auto_curry_type>
   : public fun_type<auto_curry_type,Y,auto_curry_type,
                    full2<impl::binder2of3<F,Y> > > {};

   template <class Z> struct sig<auto_curry_type,auto_curry_type,Z>
   : public fun_type<auto_curry_type,auto_curry_type,Z,
                    full2<impl::binder3of3<F,Z> > > {};

   template <class X,class Z> struct sig<X,auto_curry_type,Z>
   : public fun_type<X,auto_curry_type,Z,full1<impl::binder1and3of3<F,X,Z> > > {};

   template <class Y,class Z> struct sig<auto_curry_type,Y,Z>
   : public fun_type<auto_curry_type,Y,Z,full1<impl::binder2and3of3<F,Y,Z> > > {};

   template <class X,class Y> struct sig<X,Y,auto_curry_type>
   : public fun_type<X,Y,auto_curry_type,full1<impl::binder1and2of3<F,X,Y> > > {};

   template <class X,class Y>
   typename sig<X,Y>::result_type operator()( const X& x, const Y& y ) const {
      // need partial specialization, so defer to a class helper
return impl::Curryable3Helper2<typename sig<X,Y>::result_type,F,X,Y>::go(f,x,y);
   }
   template <class X>
   typename sig<X>::result_type operator()( const X& x ) const {
      return make_full2(impl::binder1of3<F,X>(f,x));
   }

   template <class X, class Y, class Z>
   inline typename sig<X,Y,Z>::result_type
   operator()( const X& x, const Y& y, const Z& z ) const {
      // need partial specialization, so defer to a class helper
      return impl::Curryable3Helper<typename sig<X,Y,Z>::result_type,F,X,Y,Z>
      ::go(f,x,y,z);
   }
//////////////////////////////////////////////////////////////////////
   template <class X> struct result;
   template <class Me, class X, class Y, class Z>
   struct result<Me(X,Y,Z)> :public Type<typename sig<X,Y,Z>::result_type> {};
   template <class Me, class X, class Y>
   struct result<Me(X,Y)> :public Type<typename sig<X,Y,void>::result_type> {};
   template <class Me, class X>
   struct result<Me(X)> :public Type<typename sig<X,void,void>::result_type> {};
};

template <class F> full0<F> make_full0( const F& f ) { return full0<F>(f); }
template <class F> full1<F> make_full1( const F& f ) { return full1<F>(f); }
template <class F> full2<F> make_full2( const F& f ) { return full2<F>(f); }
template <class F> full3<F> make_full3( const F& f ) { return full3<F>(f); }

//////////////////////////////////////////////////////////////////////
// Definitions of stuff heretofore put-off...
//////////////////////////////////////////////////////////////////////
// from curry.h:
typedef full1<impl::const_type> const_type;
typedef full2<impl::bind1of1_type> bind1of1_type;

typedef full2<impl::bind1of2_type> bind1of2_type;
typedef full2<impl::bind2of2_type> bind2of2_type;
typedef full3<impl::bind1and2of2_type> bind1and2of2_type;

// The only 4-arg function in the entire library; it isn't a functoid.
typedef impl::bind1and2and3of3_type bind1and2and3of3_type;

typedef full3<impl::bind1and2of3_type> bind1and2of3_type;
typedef full3<impl::bind2and3of3_type> bind2and3of3_type;
typedef full3<impl::bind1and3of3_type> bind1and3of3_type;
typedef full2<impl::bind1of3_type> bind1of3_type;
typedef full2<impl::bind2of3_type> bind2of3_type;
typedef full2<impl::bind3of3_type> bind3of3_type;

BOOST_FCPP_MAYBE_NAMESPACE_OPEN
   // C++ keyword, so add trailing underscore
BOOST_FCPP_MAYBE_EXTERN const_type const_;   
BOOST_FCPP_MAYBE_EXTERN bind1of1_type bind1of1;

BOOST_FCPP_MAYBE_EXTERN bind1of2_type bind1of2;
BOOST_FCPP_MAYBE_EXTERN bind2of2_type bind2of2;
BOOST_FCPP_MAYBE_EXTERN bind1and2of2_type bind1and2of2;

BOOST_FCPP_MAYBE_EXTERN bind1and2and3of3_type bind1and2and3of3;
BOOST_FCPP_MAYBE_EXTERN bind1and2of3_type bind1and2of3;
BOOST_FCPP_MAYBE_EXTERN bind2and3of3_type bind2and3of3;
BOOST_FCPP_MAYBE_EXTERN bind1and3of3_type bind1and3of3;
BOOST_FCPP_MAYBE_EXTERN bind1of3_type bind1of3;
BOOST_FCPP_MAYBE_EXTERN bind2of3_type bind2of3;
BOOST_FCPP_MAYBE_EXTERN bind3of3_type bind3of3;
BOOST_FCPP_MAYBE_NAMESPACE_CLOSE

} // end namespace fcpp
} // end namespace boost

#endif
