#include <typeinfo>
#include <iostream>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::cout;
using std::endl;

struct Apply {
   template <class F, class X, class Y>
   struct sig : public fun_type<F,X,Y,
                               typename F::template sig<X,Y>::result_type> {};

   template <class F, class X, class Y>
   typename F::template sig<X,Y>::result_type
   operator()( F f, X x, Y y ) {
      return f(x,y);
   }
} apply;
   
int main() {
   cout << typeid(apply( make_pair, 3, 'c' )).name() << endl;
}
