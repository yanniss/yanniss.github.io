#include <iostream>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::cout;
using std::endl;

int main() {
cout << "a" << endl;
   list<int> l = enum_from( 1 );
cout << "b" << endl;
   l = compose( tail, tail )( l );
cout << "c" << endl;
   l = take( 3, l );
cout << "d" << endl;
   
   while( l ) {
      cout << head(l) << " ";
      l = tail(l);
   }
   cout << endl;
   return 0;
}
   
