#include "prelude.hpp"
#include <iostream>
#include <typeinfo>

using namespace boost::fcpp;

using std::cout;
using std::endl;

int main() {
   using boost::fcpp::greater;
   using boost::fcpp::minus;
   using boost::fcpp::plus;
   cout << minus(7,4) << endl;
   cout << minus(7)(4) << endl;

   cout << minus(_,4)(7) << endl;
   cout << minus(7,_)(4) << endl;

   cout << until( greater(_,9), inc, 1 ) << endl;
   cout << until( greater(_,9), inc )(1) << endl;
   cout << until( greater(_,9) )(inc,1) << endl;

   cout << until( _, inc, _ )( greater(_,9), 1) << endl;
   cout << until( _, inc )( greater(_,9), 1) << endl;
   cout << until( _, _, 1 )( greater(_,9), inc) << endl;
   cout << until( greater(_,9), _, _ )(inc,1) << endl;

   cout << until( _, inc, 1 )(greater(_,9)) << endl;
   cout << until( greater(_,9), _, 1 )(inc) << endl;
   cout << until( greater(_,9), inc, _ )(1) << endl;


   cout << until( greater(_,9) )(inc)(1) << endl;
   cout << until( greater(_,9), _ )(inc)(1) << endl;
   cout << until( greater(_,9), _, _ )(inc)(1) << endl;

   cout << "test" << endl;

   cout << until( _, inc, _ )(greater(_,9) )(1) << endl;
   cout << until( _, _, 1 )(greater(_,9) )(inc) << endl;

   cout << "dec test" << endl;
   cout << until( less(_,1), dec, 9 ) << endl;



   //fun2<int,int,int> f = monomorphize2<int,int,int>( minus );
   fun2<int,int,int> f = make_fun2(monomorphize2<int,int,int>( minus ));


   
   cout << f(_,4)(5) << endl;
   fun1<int,int> sub4 = f(_,4);
   cout << sub4(5) << endl;

   fun1<int,int> decrement = minus(_,1);
   fun1<int,int> in = inc;
   cout << decrement(9) << ' ' << in(7) << endl;

   fun2<int,int,int> z = minus;
   cout << z(7,1) << endl;
   cout << z(7,_)(1) << endl;
   cout << minus(7,_)(1) << endl;

   //make_fun2(minus);
////////////////////////////////////////////////////////////////////// 
   cout << h_uncurry(plus)( make_pair(3,4) ) << endl;
   cout << h_curry(h_uncurry(plus))(3,4) << endl;
}

