#include <iostream>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::cin;
using std::cout;
using std::endl;

template <class Unary, class ArgThunk>
class thunkbinder1of1
: public c_fun_type<typename RT<Unary,ArgThunk>::result_type> {
   Unary f;
   ArgThunk a;
public:
   thunkbinder1of1( const Unary& x, const ArgThunk& y ) : f(x), a(y) {}
   typename RT<Unary,ArgThunk>::result_type operator()() const { return f(a()); }
};

// note to self; same as curry except for thunkbinder reference; can
// templatize it rather than have a 'new' class
struct CurryThunk1 {
  template <class Unary, class A1>
  struct sig : public fun_type<Unary, A1, thunkbinder1of1<Unary,A1> > {};

  template <class Unary, class A1>
  typename sig<Unary, A1>::result_type
  operator()( const Unary& f, const A1& a1 ) const {
    return thunkbinder1of1<Unary,A1>(f,a1);
  }
};
namespace { CurryThunk1 currythunk1, currythunk; }

class Counter {
   int count;
public:
   Counter() : count(0)             {}
   int get_count() const            { return count; }
   void increment_count()           { ++count; }
   void increment_count_by( int x ) { count += x; }
};

void show( int x ) {
   cout << "The counter is " << x << endl;
}

int main() {
   Counter c;
   fun0<void> menu_actions[] = {
      make_fun0( currythunk( ptr_to_fun( &show ),
                            curry1(ptr_to_fun(&Counter::get_count),&c) ) ),
      make_fun0( curry1( ptr_to_fun( &Counter::increment_count ), &c ) ),
      make_fun0( curry2( ptr_to_fun( &Counter::increment_count_by ), &c, 5 ) )
   };
   while( true ) {
      cout << "***Menu: (1) show count (2) increment "
           << "(3) inc. by 5 (4) quit" << endl;
      cout << "Select option: ";
      int choice;
      cin >> choice;
      if( choice==1 || choice==2 || choice==3 )
         menu_actions[choice-1]();
      else
         break;
   }
}

