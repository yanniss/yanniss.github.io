#include <iostream>
#include <utility>
#include "prelude.hpp"

using namespace boost::fcpp;

using std::pair;
using std::ostream;
using std::cout;
using std::endl;

ostream& operator<<( ostream& o, pair<int,int> p ) {
   o << "(" << p.first << "," << p.second << ")";
   return o;
}

template <class T>
ostream& operator<<( ostream& o, odd_list<T> l ) {
   while( l ) {
      o << head(l) << " ";
      l = tail(l);
   }
   return o;
}

template <class T>
ostream& operator<<( ostream& o, list<T> l ) {
   return (o << l.force());
}

struct Double : public c_fun_type<int,int> {
   int operator()( int x ) const {
      return 2*x;
   }
};

int main() {
   using boost::fcpp::plus;
   using boost::fcpp::greater;

   list<int> l = cat( list_with(0,2,5,7,9), list_with(11,15,18) );
   cout << "Original   :" << l << endl;
   list<list<int> > ll;
   ll = cons( l, ll );
   ll = cons( l, ll );
   cout << "concat_type     :" << curry1(concat,ll)() << endl;
   cout << "init_type       :" << curry1(init,l)() << endl;
   cout << "last_type       :" << curry1(last,l)() << endl;
   cout << "length_type     :" << curry1(length,l)() << endl;
   cout << "reverse_type    :" << curry1(boost::fcpp::reverse,l)() << endl;
   cout << "take_while_type<9:" << take_while(boost::fcpp::less(_,9))(l) << endl;
   cout << "drop_while_type<9:" << drop_while(boost::fcpp::less(_,9))(l) << endl;
   cout << "cycle_type (121):" 
#ifdef FCPP_SIMPLE_PRELUDE
        << take(3, curry1( cycle, cons(1,cons(2,NIL)).delay() )() ) << endl;
#else
        << take(3, curry1( cycle, cons(1,cons(2,NIL)) )() ) << endl;
#endif
   cout << "at_type(2)      :" << at(l)(2) << endl;
   cout << "filter_type >10 :" << filter( bind2of2( greater, 10 ))(l) << endl;
   cout << "foldr_type +    :" << foldr(plus,0)(l) << endl;
   cout << "foldr1_type +   :" << foldr1(plus)(l) << endl;
   cout << "foldl_type +    :" << foldl(plus,0)(l) << endl;
   cout << "foldl1_type +   :" << foldl1(plus)(l) << endl;
   cout << "scanr_type +    :" << scanr(plus,0)(l) << endl;
   cout << "scanr1_type +   :" << scanr1(plus)(l) << endl;
   cout << "scanl_type +    :" << scanl(plus,0)(l) << endl;
   cout << "scanl1_type +   :" << scanl1(plus)(l) << endl;
   cout << "drop_type 5     :" << drop(5)(l) << endl;

   cout << "take_type 5 of iterate_type double 1:" 
        << take(5,iterate(Double())(1)) << endl;
   cout << "take_type 5 of repeat 1        :" 
        << take(5, curry1(repeat,1)() ) << endl;

   pair<list<int>,list<int> > p = split_at( 5)( l );
   cout << "split_at_type 5 a:" << p.first << endl;
   cout << "split_at_type 5 b:" << p.second << endl;

   p = span( bind2of2( greater, 10 ))( l );
   cout << "span_type >10  a:" << p.first << endl;
   cout << "span_type >10  b:" << p.second << endl;

   p = curry2( break_type(), bind2of2(greater,10) )( l );
   cout << "break_type>10  a:" << p.first << endl;
   cout << "break_type>10  b:" << p.second << endl;
   list<bool> b = map( odd_type(), l );
   cout << "and_type odd_type    :" << and_type()(b) << endl;
   cout << "or_type  odd_type    :" << or_type()(b) << endl;
   cout << "and_type odd_type 0  :" << and_type()(take(1,b)) << endl;
   cout << "or_type  odd_type 0  :" << or_type()(take(1,b)) << endl;
   cout << "any_type >10    :" << any( bind2of2(greater,10))( l) << endl;
   cout << "all_type >10    :" << all( bind2of2(greater,10))( l) << endl;
   cout << "any_type >-10   :" << any( bind2of2(greater,-10))( l) << endl;
   cout << "all_type >-10   :" << all( bind2of2(greater,-10))( l) << endl;
   cout << "elem_type 10    :" << elem(10)(l) << endl;
   cout << "not_elem_type 10 :" << not_elem(10)(l) << endl;
   cout << "sum_type        :" << curry1(sum,l)() << endl;
   cout << "Producttail:" << curry1(product,tail(l))() << endl;
   cout << "maximum_type    :" << curry1(maximum,l)() << endl;
   cout << "minimum_type    :" << curry1(minimum,l)() << endl;
   cout << "zip_type w/ 1s  :" << zip(l)(repeat(1)) << endl;
   cout << "zip_type w/ +1s :" << zip_with(plus,l)(repeat(1)) << endl;
   cout << "gcd(30,18) :" << gcd(30)(18) << endl;

   return 0;
}
   
