// This program is based on the the paper
//    "Monadic Parser Combinators"
// by Graham Hutton and Erik Meijer.

#include <string>
#include <iostream>
#define BOOST_FCPP_ENABLE_LAMBDA
#include "prelude.hpp"

using std::cout;
using std::endl;
using std::string;
using std::cin;
using std::ostream;

using namespace boost::fcpp;

typedef list<char> String;

struct ParserM {
   // M a = String -> [(a,String)]

   // We use indirect functoids as a representation type, since we will
   // often need two functions with different behaviors (but the same
   // signatures) to appear to have the same type.
   template <class A> struct rep 
      { typedef fun1<String,list<std::pair<A,String> > > type; };
   template <class MA> struct unrep { typedef typename 
      RT<MA,String>::result_type::value_type::first_type type; };

   // ReRep is a type-identity in Haskell; here it "indirect"ifies the
   // type, so direct functoids are turned into indirect ones so that
   // only the signature information appears in the type.
   template <class MA> struct ReRep 
      { typedef typename rep<typename unrep<MA>::type>::type type; };

   struct XUnit {
      template <class A> struct sig : public fun_type<A,
         typename rep<A>::type> {};
      template <class A>
      typename sig<A>::result_type
      operator()( const A& a ) const {
         lambda_var<1> S;
         return lambda(S)[ cons[make_pair[a,S],NIL] ];
      }
   };
   typedef full1<XUnit> unit_type;
   static unit_type unit;

   struct XBind {
      template <class M, class K> struct sig : public fun_type<M,K,typename 
         ReRep<typename RT<K,typename unrep<M>::type>::result_type>::type> {};
      template <class M, class K>
      typename sig<M,K>::result_type
      operator()( const M& m, const K& k ) const {
         lambda_var<1> P;
         lambda_var<2> S;
         return lambda(S)[ concat[ comp_m<list_m>()
            [ k[fst[P]][snd[P]] | P <= m[S] ] ] ];
      }
   };
   typedef full2<XBind> bind_type;
   static bind_type bind;

   typedef fun1<String,a_unique_type_for_nil> zero_type;
   static zero_type zero;
};
ParserM::unit_type ParserM::unit;
ParserM::bind_type ParserM::bind;
ParserM::zero_type ParserM::zero = ignore( const_(NIL) );

struct XItem : public c_fun_type<String,odd_list<std::pair<char,String> > > {
   odd_list<std::pair<char,String> > operator()( const String& s ) const {
      if( null(s) )
         return NIL;
      else
         return cons( make_pair( head(s), tail(s) ), NIL );
   }
};
typedef full1<XItem> Item;
Item item;

struct XPlusP {
   template <class P, class Q, class S> struct sig : public 
      fun_type<P,Q,String,typename RT<cat_type,typename RT<P,String>::result_type,
      typename RT<curry1_type,Q,String>::result_type>::result_type> {};
   template <class P, class Q>
   typename sig<P,Q,String>::result_type
   operator()( const P& p, const Q& q, const String& s ) const {
      return p(s) ^cat^ curry1(q,s);
   }
};
typedef full3<XPlusP> PlusP;
PlusP plusP;

template <class Monad>
struct XManyM {
   // Monad a -> Monad [a]
   template <class MA>
   struct sig : public fun_type<MA, typename RT<typename
      plus_m_type<Monad>::type, typename LE<LAM<COMP<CALL<cons_type,LV<1>,LV<2>
      >,GETS<1,MA>,GETS<2,CALL<full1<XManyM<Monad> >,MA> > > > >::type,
      typename RT<typename unit_m_type<Monad>::type, list<typename
      Monad::template unrep<MA>::type> >::result_type>::result_type> {};

   template <class MA>
   typename sig<MA>::result_type operator()( const MA& ma ) const {
      typedef typename Monad::template unrep<MA>::type AA;
      lambda_var<1> A;
      lambda_var<2> AS;
      return lambda()[ comp_m<Monad>()[ cons(A,AS) | 
         A <= ma, AS <= make_full1(*this)[ma] ] ]() 
         ^plus_m<Monad>()^ unit_m<Monad>()( list<AA>() );
   }
};
// just_type using parser version here:    Parser a -> Parser [a]
typedef full1<XManyM<ParserM> > Many;
Many many;

// sat :: (char -> bool) -> Parser char
struct XSat {
   template <class P> struct sig : public fun_type<P,
      typename RT<typename LE<LAM<COMP<ParserM,LV<1>,GETS<1,Item>,
      GUARD<CALL<P,LV<1> > > > > >::type>::result_type> {};
   template <class P>
   typename sig<P>::result_type
   operator()( const P& p ) const {
      lambda_var<1> C;
      return lambda()[ comp_m<ParserM>()[ C | C<=item, guard[p[C]] ] ]();
   }
};
typedef full1<XSat> Sat;
Sat sat;

struct XCharP : public c_fun_type<char, 
   RT<Sat,RT<equal_type,char>::result_type>::result_type> {
   RT<Sat,RT<equal_type,char>::result_type>::result_type
   operator()( char c ) const {
      return sat( equal(c) );
   }
};
typedef full1<XCharP> CharP;
CharP charP;

struct XBetween {
   template <class T, class U, class V> struct sig 
      : public fun_type<T,T,T,bool> {};
   template <class T>
   bool operator()( const T& goal, const T& lower, const T& upper ) const {
      return less_equal(goal,upper) && greater_equal(goal,lower);
   }
};
typedef full3<XBetween> Between;
Between between;

typedef RT<Sat,RT<Between,auto_curry_type,char,char>
   ::result_type>::result_type Digit;
Digit digit = sat( between(_,'0','9') );

typedef Digit Lower;
Lower lower = sat( between(_,'a','z') );

typedef Digit Upper;
Upper upper = sat( between(_,'A','Z') );

typedef RT<PlusP,Lower,Upper>::result_type Letter;
Letter letter = lower ^plusP^ upper;

typedef RT<PlusP,Letter,Digit>::result_type AlphaNum;
AlphaNum alphaNum = letter ^plusP^ digit;

template <class Monad>
struct XMany1M {
   // Monad a -> Monad [a]
   template <class MA>
   struct sig : public fun_type<MA, typename LE<LAM<COMP<
      CALL<delay_type,CALL<cons_type,LV<1>,LV<2> > >,GETS<1,MA>,GETS<2,
      CALL<full1<XManyM<Monad> >,MA> > > > >::type> {};

   template <class MA>
   typename sig<MA>::result_type
   operator()( const MA& ma ) const {
      lambda_var<1> A;
      lambda_var<2> AS;
      return lambda()[ comp_m<Monad>() [ delay[cons[A,AS]] | 
         A <= ma, AS <= make_full1(XManyM<Monad>())[ma] ] ]();
   }
};
// just_type using parser version here:    Parser a -> Parser [a]
typedef full1<XMany1M<ParserM> > Many1;
Many1 many1;

struct XChainl1 {
   // Parser a -> Parser (a->a->a) -> Parser a
   // parses a series of items separated by left-associative operators

   typedef bind_m_type<ParserM>::type BIND;
   typedef unit_m_type<ParserM>::type UNIT;
   template <class P, class O>
   struct XRest {
      P p;
      O op;
      XRest( const P& pp, const O& oo ) : p(pp), op(oo) {}

      template <class X> struct sig : public fun_type<X,
         typename ParserM::rep<X>::type> {};
      template <class X>
      typename sig<X>::result_type
      operator()( const X& x ) const {
         lambda_var<1> F;
         lambda_var<2> Y;
         return (op ^BIND()^ lambda(F)[ 
                 p  %BIND()% lambda(Y)[
                 make_full1(*this)[ F[x,Y] ] ] ]) ^plusP^ UNIT()(x);
      }
   };

   template <class P, class O> struct sig : public fun_type<P,O,
      typename RT<BIND,P,full1<XRest<P,O> > >::result_type> {};
   template <class P, class O>
   typename sig<P,O>::result_type
   operator()( const P& p, const O& op ) const {
      return p ^BIND()^ make_full1(XRest<P,O>(p,op));
   }
};
typedef full2<XChainl1> Chainl1;
Chainl1 chainl1;

struct XChainr1 {
   // Parser a -> Parser (a->a->a) -> Parser a
   // parses a series of items separated by right-associative operators

   template <class P, class O> struct sig : public fun_type<P,O,
      typename ParserM::rep<typename ParserM::unrep<P>::type>::type> {};
   template <class P, class O>
   typename sig<P,O>::result_type
   operator()( const P& p, const O& op ) const {
      lambda_var<1> F;
      lambda_var<2> X;
      lambda_var<3> Y;
      return p ^bind_m<ParserM>()^ lambda(X)[ comp_m<ParserM>()
         [ F[X,Y] | F <= op, Y <= make_full2(*this)[p][op] ]
         %plusP% unit_m<ParserM>()[X] ];
   }
};
typedef full2<XChainr1> Chainr1;
Chainr1 chainr1;

struct XChainl {
   template <class P, class O, class V> struct sig : public fun_type<P,O,V,
      typename RT<PlusP,typename RT<Chainl1,P,O>::result_type,
      typename RT<typename unit_m_type<ParserM>::type,V>::result_type>::result_type> {};
   template <class P, class O, class V>
   typename sig<P,O,V>::result_type
   operator()( const P& p, const O& op, const V& v ) const {
      return (p ^chainl1^ op) ^plusP^ unit_m<ParserM>()(v);
   }
};
typedef full3<XChainl> Chainl;
Chainl chainl;

struct XChainr {
   template <class P, class O, class V> struct sig : public fun_type<P,O,V,
      typename RT<PlusP,typename RT<Chainr1,P,O>::result_type,
      typename RT<typename unit_m_type<ParserM>::type,V>::result_type>::result_type> {};
   template <class P, class O, class V>
   typename sig<P,O,V>::result_type
   operator()( const P& p, const O& op, const V& v ) const {
      return (p ^chainr1^ op) ^plusP^ unit_m<ParserM>()(v);
   }
};
typedef full3<XChainr> Chainr;
Chainr chainr;

typedef RT<LE<LAM<LET<BIND<1,LAM<LV<2>,LV<3>,CALL<plus_type,
   CALL<multiplies_type,int,LV<2> >,LV<3> > > >,CALL<Chainl1,COMP<ParserM,
   CALL<construct1_type<int>::type,CALL<minus_type,LV<4>,char> >,GETS<4,Digit> >,
   CALL<unit_m_type<ParserM>::type,LV<1> > > > > >::type>::result_type Nat;
Nat xnat() {
   lambda_var<1> OP;
   lambda_var<2> M;
   lambda_var<3> N;
   lambda_var<4> X;
   return lambda()[ let[ 
      OP == lambda(M,N)[ plus[multiplies[10,M],N] ]
      ].in[ comp_m<ParserM>()[ construct1<int>()[minus[X,'0']] | X<=digit ]
            %chainl1% unit_m<ParserM>()[OP] ] ]();
}
Nat nat = xnat();

typedef RT<LE<LAM<LET<BIND<3,CALL<PlusP,COMP<ParserM,CALL<
   construct1_type<fun1<int,int> >::type,negate_type>,CALL<CharP,char> >,CALL<
   unit_m_type<ParserM>::type,CALL<construct1_type<fun1<int,int> >::type,id_type> > > >, 
   COMP<ParserM,CALL<LV<1>,LV<2> >,GETS<1,LV<3> >,GETS<2,Nat> 
   > > > >::type>::result_type IntP;
IntP xintp() {
   lambda_var<1> F;
   lambda_var<2> N;
   lambda_var<3> OP;
   construct1_type<fun1<int,int> >::type cf = construct1<fun1<int,int> >();
   return lambda()[ let[ OP == comp_m<ParserM>()[ cf[negate] | charP['-'] ]
                               %plusP% unit_m<ParserM>()[ cf[id] ] ] 
      .in[ comp_m<ParserM>()[ F[N] | F<=OP, N<=nat ] ]   ]();
}
IntP intP = xintp();

struct XSepBy1 {
   // Parser a -> Parser b -> Parser [a]
   // parses "p (sep p)*", throwing away the separators
   template <class P, class S> struct sig : public fun_type<P,S,
      typename RT<typename LE<LAM<COMP<ParserM,CALL<delay_type,
      CALL<cons_type,LV<1>,LV<2> > >,GETS<1,P>,GETS<2,CALL<Many,
      COMP<ParserM,LV<3>,S,GETS<3,P> > > > > > >::type>::result_type> {};
   template <class P, class S>
   typename sig<P,S>::result_type
   operator()( const P& p, const S& sep ) const {
      lambda_var<1> X;
      lambda_var<2> XS;
      lambda_var<3> Y;
      return lambda()[ comp_m<ParserM>()[ delay[cons[X,XS]] |
         X <= p, XS <= many[ comp_m<ParserM>()[ Y | sep, Y <= p ] ] ] ]();
   }
};
typedef full2<XSepBy1> SepBy1;
SepBy1 sepBy1;

struct XBracket {
   template <class O, class P, class C> struct sig : public fun_type<O,P,C,
      typename RT<typename LE<LAM<COMP<ParserM,LV<1>,O,GETS<1,P>,C>
      > >::type>::result_type> {};
   template <class O, class P, class C>
   typename sig<O,P,C>::result_type
   operator()( const O& open, const P& p, const C& close ) const {
      lambda_var<1> X;
      return lambda()[ comp_m<ParserM>()[ X | open, X<=p, close ] ]();
   }
};
typedef full3<XBracket> Bracket;
Bracket bracket;

struct XSepBy {
   template <class P, class S> struct sig : public fun_type<P,S,
      typename RT<PlusP,typename RT<SepBy1,P,S>::result_type,
      typename RT<unit_m_type<ParserM>::type,list<typename
      ParserM::unrep<P>::type> >::result_type>::result_type> {};
   template <class P, class S>
   typename sig<P,S>::result_type
   operator()( const P& p, const S& sep ) const {
      typedef typename ParserM::unrep<P>::type A;
      list<A> l = NIL;
      return (p ^sepBy1^ sep) ^plusP^ unit_m<ParserM>()( l );
   }
};
typedef full2<XSepBy> SepBy;
SepBy sepBy;

struct XOps {
   // [(Parser a, b)] -> Parser b
   // given a list of pair<parser to parse op,op>, returns a parser
   template <class X> struct sig : public fun_type<X,
      typename RT<foldr1_type,PlusP,typename RT<typename LE<LAM<
      COMP<list_m,COMP<ParserM,CALL<snd_type,LV<1> >,CALL<fst_type,LV<1> > >,
      GETS<1,X> > > >::type>::result_type>::result_type> {};
   template <class X>
   typename sig<X>::result_type
   operator()( const X& xs ) const {
      lambda_var<1> P;
      return foldr1( plusP, lambda()[ comp_m<list_m>()[ 
         comp_m<ParserM>()[ snd[P] | fst[P] ]   | P <= xs ] ]() );
   }
};
typedef full1<XOps> Ops;
Ops ops;

//////////////////////////////////////////////////////////////////////

ostream& operator<<( ostream& o, const String& s ) {
   string ss( s.begin(), s.end() );
   return o << "\"" << ss << "\"";
}

template <class A, class B>
ostream& operator<<( ostream& o, const std::pair<A,B>& p ) {
   return o << "(" << p.first << "," << p.second << ")";
}

template <class T>
ostream& operator<<( ostream& o, odd_list<T> l ) {
   o << "[";
   if(l)
      for(;;) {
         o << head(l);
         l = tail(l);
         if(l)
            o << ",";
         else 
            break;
      }
   return o << "]";
}

template <class T>
ostream& operator<<( ostream& o, list<T> l ) {
   return o << l.force();
}

//////////////////////////////////////////////////////////////////////

int my_pow( int x, int y ) {
   int r = 1;
   while(y) {
      r *= x;
      --y;
   }
   return r;
}

typedef ParserM::rep<int>::type ExprP;
extern ExprP exprP;

typedef RT<Ops,list<std::pair<RT<CharP,char>::result_type,fun2<int,int,int> 
   > > >::result_type AddOp;
AddOp xaddOp() {
   typedef fun2<int,int,int> F;
   return ops( list_with( 
      boost::fcpp::make_pair( charP('+'), F(plus)  ), 
      boost::fcpp::make_pair( charP('-'), F(minus) )   ) );
}
AddOp addOp = xaddOp();

typedef AddOp ExpOp;
ExpOp xexpOp() {
   typedef fun2<int,int,int> F;
   return ops( list_with( boost::fcpp::make_pair(charP('^'),F(ptr_to_fun(&my_pow))) ) );
}
ExpOp expOp = xexpOp();
   
typedef RT<PlusP,Nat,RT<Bracket,RT<CharP,char>::result_type,
   ExprP,RT<CharP,char>::result_type>::result_type>::result_type Factor;
Factor xfactor() {
   static Factor result = nat ^plusP^ bracket( charP('('), exprP, charP(')') );
   return result;
}

typedef ExprP Term;  // I am too lazy to direct-type this
Term xterm() {
   static Term result = thunk_func_to_func(ptr_to_fun(&xfactor)) ^chainr1^ expOp;
   return result;
}

ExprP xexprP() {
   return thunk_func_to_func(ptr_to_fun(&xterm)) ^chainl1^ addOp;
}
ExprP exprP = xexprP();

//////////////////////////////////////////////////////////////////////
// Here I just want to show the straightforward way using indirect
// functoid types:

typedef ParserM::rep<int>::type P_int;
P_int dummy = ignore(const_(cons(make_pair(0,String()),NIL)));
P_int group=dummy, factor=dummy, term=dummy, expression=dummy;

int main() {
   lambda_var<91> S;
   factor     = lambda(S)[ (nat %plusP% dereference[&group])[S] ];
   term       = factor ^chainr1^ expOp;
   expression = term ^chainl1^ addOp;
   group      = bracket( charP('('), expression, charP(')') );
//////////////////////////////////////////////////////////////////////

   string ss;
   cout << "Enter a string to parse (e.g. '1+2^3-(2-1)^5'):" << endl;
   getline(cin,ss);
   String s( ss.begin(), ss.end() );
   length(s);  // force evaluation


   typedef ParserM P;
   lambda_var<1> X;
   list<std::pair<char,String> > lpcs = lambda()[ comp_m<P>()
      [ X | X <= item ] ]()(s);
   cout << "item: " << lpcs << endl;
   cout << "list of expression parses:" << endl << exprP(s) << endl;
   cout << "list of expression parses:" << endl << expression(s) << endl;

/*
This works.  I did it just to prove a point.
   list<std::pair<String,String> > lpss;
   lambda_var<12> lower;
   lambda_var<13> upper;
   lambda_var<14> letter;
   lambda_var<15> word;
   lpss = lambda()[ let[
      lower == comp_m<P>()[ X | X<=item, guard[logical_and[greater_equal[X,'a'],
                                                         less_equal[X,'z']]]],
      upper == comp_m<P>()[ X | X<=item, guard[logical_and[greater_equal[X,'A'],
                                                         less_equal[X,'Z']]]],
      letter == lower %plusP% upper,
      word == many[letter] 
      ].in[ word[s] ] ]();
   cout << lpss << endl;
*/

/* FIX THIS comment window
   list<std::pair<String,String> > lpss;
   lpss = many(letter)(s);
   cout << "many(letter): " << lpss << endl;
   lpss = many1(letter)(s);
   cout << "many1(letter): " << lpss << endl;

   list<std::pair<int,String> > lpis;
   lpis = nat(s);
   cout << "nat: " << lpis << endl;

   list<std::pair<list<int>,String> > lplis;
   lplis = bracket( charP('['), intP ^sepBy^ charP(','), charP(']') )(s);
   cout << "list of ints: " << lplis << endl;

   cout << "list of expression parses:" << endl << exprP(s) << endl;

   lambda_var<21> ex;
   lambda_var<22> tm;
   lambda_var<23> fc;
   lambda_var<24> S;
   fun1<String,list<std::pair<int,String> > > dummy = ignore( const_(
      list<std::pair<int,String> >() ) );
   cout << "Expr parses via letrec defs:" << endl <<
      lambda()[ letrec[
// need some way to break recursion... one way is shown below
//         ex == lambda(S)[ (tm %chainl1% addOp)[S] ],
         ex == if2[true,lambda(S)[ (tm %chainl1% addOp)[S] ],dummy],
         tm == lambda(S)[ (fc %chainr1% expOp)[S] ],
         fc == lambda(S)[ (nat %plusP% bracket[charP['('],ex,charP[')']])[S] ]
      ].in[ ex[s] ] ]() << endl;
*/
}
