// Copyright Brian McNamara and Yannis Smaragdakis 2000-2003. 
// Use, modification and distribution is subject to the 
// Boost Software License, Version 1.0.  (See accompanying file 
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FCPP_CONFIG_HPP
#define BOOST_FCPP_CONFIG_HPP

// Here we do a little macro setting-up for compile-time options
#ifdef BOOST_FCPP_DEFER_DEFINITIONS
#   define BOOST_FCPP_MAYBE_NAMESPACE_OPEN
#   define BOOST_FCPP_MAYBE_NAMESPACE_CLOSE
#   define BOOST_FCPP_MAYBE_EXTERN extern
#   define BOOST_FCPP_MAYBE_DEFINE(x)
#else
#   define BOOST_FCPP_MAYBE_NAMESPACE_OPEN namespace {
#   define BOOST_FCPP_MAYBE_NAMESPACE_CLOSE }
#   define BOOST_FCPP_MAYBE_EXTERN 
#   define BOOST_FCPP_MAYBE_DEFINE(x) x
#endif


#endif
