// Copyright Brian McNamara and Yannis Smaragdakis 2000-2003.
// Use, modification and distribution is subject to the
// Boost Software License, Version 1.0.  (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FCPP_REF_HPP
#define BOOST_FCPP_REF_HPP

#include "config.hpp"
#include "boost/intrusive_ptr.hpp"
#include "boost/shared_ptr.hpp"

namespace boost {
namespace fcpp {
   typedef unsigned int RefCountType;
} // end namespace fcpp 
} // end namespace boost 

#endif
