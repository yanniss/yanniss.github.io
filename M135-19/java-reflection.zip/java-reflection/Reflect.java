import java.lang.reflect.*;
import java.io.*;

class Reflect {
    public static void main(String[] args) {
	System.out.println("Reflection and class loading test.");

	try {
	    // (1) Source of Class object: unknown local object.
	    Object a1 = new A();
	    Class c = a1.getClass();

	    // (2) Source of Class object: class loading.
	    // Class c = ClassLoader.getSystemClassLoader().loadClass("A");

	    System.out.println("name: " + c.getName());
	    System.out.println("methods: ");
	    for (Method m : c.getDeclaredMethods())
	    	System.out.println("  " + m.getGenericReturnType() + " " + m.getName());

	    System.out.println("Creating a new instance of the loaded class.");
	    Object obj = c.newInstance();
	    
	    Field obj_x = c.getDeclaredField("x");
	    System.out.println("Reading instance field x (via reflection): " + obj_x.get(obj));
	    System.out.println("Updating instance field x (via reflection)...");
	    obj_x.set(obj, 10);

	    A a = (A)obj;
	    System.out.println("Updated instance field x: " + a.x);
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }
}
