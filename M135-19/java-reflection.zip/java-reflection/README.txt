Java reflection and class-loading example, compile and run with:

  javac A.java Reflect.java
  java Reflect

