public class A {
    public int x = 42;
    public void test() {
	System.out.println("Method test of A.");
    }
    public int f() { return 0; }
    private int g() { return 1; }
}
