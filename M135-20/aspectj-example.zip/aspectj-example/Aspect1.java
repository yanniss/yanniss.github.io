import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.JoinPoint;

@Aspect
public class Aspect1 {
    @Before("execution (* Point.getX(..))")
    public void advice(JoinPoint joinPoint) {
	System.out.printf("Aspect1.advice() called on '%s'%n", joinPoint);
    }
}
