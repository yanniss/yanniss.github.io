AspectJ example, to run it:

1. Set variable ASPECTJRT in the Makefile to point to the installed AspectJ.

2. Run:

     make aspectJRun

