public class Main {
    public static void main(String[] args) {
	Point p1 = new Point(10, 20);
	System.out.println("p1.x = " + p1.getX());
	p1.setX(30);
    }
}
