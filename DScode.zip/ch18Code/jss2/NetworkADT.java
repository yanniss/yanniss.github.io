//********************************************************************

//  NetworkADT.java       Authors: Lewis/Chase

//

//  Defines the interface to a network.

//********************************************************************



package jss2;



import java.util.Iterator;



public interface NetworkADT<T> extends GraphADT<T>

{

   public void addEdge (T vertex1, T vertex2, double weight);



   public double shortestPathWeight(T vertex1, T vertex2);

}

