//********************************************************************
//  Graph.java       Authors: Lewis/Chase
//
//  Represents an adjacency matrix implementation of a graph.
//********************************************************************

package jss2;

import jss2.exceptions.*;
import java.util.*;

public class Graph<T> implements GraphADT<T>
{
   protected final int DEFAULT_CAPACITY = 10;
   protected int numVertices;         // number of vertices in the graph
   protected boolean[][] adjMatrix;   // adjacency matrix
   protected T[] vertices;       // values of vertices

   //-----------------------------------------------------------------
   //  Creates an empty graph.
   //-----------------------------------------------------------------
   public Graph()
   {
      numVertices = 0;
      this.adjMatrix = new boolean[DEFAULT_CAPACITY][DEFAULT_CAPACITY];
      this.vertices = (T[])(new Object[DEFAULT_CAPACITY]);
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of the adjacency matrix. 
   //-----------------------------------------------------------------
   public String toString()
   {
}

   //-----------------------------------------------------------------
   //  Inserts an edge between two vertices of the graph.
   //-----------------------------------------------------------------
   public void addEdge (int index1, int index2)
   {
}

   //-----------------------------------------------------------------
   //  Removes an edge between two vertices of the graph.
   //-----------------------------------------------------------------
   public void removeEdge (int index1, int index2)
   {
}

   //-----------------------------------------------------------------
   //  Inserts an edge between two vertices of the graph.
   //-----------------------------------------------------------------
   public void addEdge (T vertex1, T vertex2)
   {
}

   //-----------------------------------------------------------------
   //  Removes an edge between two vertices of the graph.
   //-----------------------------------------------------------------
   public void removeEdge (T vertex1, T vertex2)
   {
}

   //-----------------------------------------------------------------
   //  Adds a vertex to the graph, expanding the capacity of the graph
   //  if necessary.
   //-----------------------------------------------------------------
   public void addVertex ()
   {
}

   //-----------------------------------------------------------------
   //  Adds a vertex to the graph, expanding the capacity of the graph
   //  if necessary.  It also associates an object with the vertex.
   //-----------------------------------------------------------------
   public void addVertex (T vertex)
   {
}

   //-----------------------------------------------------------------
   //  Removes a vertex at the given index from the graph.  Note that 
   //  this may affect the index values of other vertices.
   //-----------------------------------------------------------------
   public void removeVertex (int index)
   {
}

   //-----------------------------------------------------------------
   //  Removes a single vertex with the given value from the graph.  
   //-----------------------------------------------------------------
   public void removeVertex (T vertex)
   {
}

   //-----------------------------------------------------------------
   //  Returns an iterator that performs a depth first search 
   //  traversal starting at the given index.
   //-----------------------------------------------------------------
   public Iterator<T> iteratorDFS(int startIndex)
   {
      Integer x;
      boolean found;
      LinkedStack<Integer> traversalStack = new LinkedStack<Integer>();
      ArrayUnorderedList<T> resultList = new ArrayUnorderedList<T>();
      boolean[] visited = new boolean[numVertices];

      if (!indexIsValid(startIndex))
         return resultList.iterator();

      for (int i = 0; i < numVertices; i++)
         visited[i] = false;
      
      traversalStack.push(new Integer(startIndex));
      resultList.addToRear(vertices[startIndex]);
      visited[startIndex] = true;
      
      while (!traversalStack.isEmpty())
      {
         x = traversalStack.peek();
         found = false;

         // Find a vertex adjacent to x that has not been visited
         // and push it on the stack
         for (int i = 0; (i < numVertices) && !found; i++)
         {
            if (adjMatrix[x.intValue()][i] && !visited[i])
            {
               traversalStack.push(new Integer(i));
               resultList.addToRear(vertices[i]);
               visited[i] = true;
               found = true;
            }
         }
         if (!found && !traversalStack.isEmpty())
            traversalStack.pop();
      }
      return resultList.iterator();
   }

   //-----------------------------------------------------------------
   //  Returns an iterator that performs a depth first search 
   //  traversal starting at the given vertex.
   //-----------------------------------------------------------------
   public Iterator<T> iteratorDFS(T startVertex)
   {      
      return iteratorDFS(getIndex(startVertex));
   }

   //-----------------------------------------------------------------
   //  Returns an iterator that performs a breadth first search 
   //  traversal starting at the given index.
   //-----------------------------------------------------------------
   public Iterator<T> iteratorBFS(int startIndex)
   {
      Integer x;
      LinkedQueue<Integer> traversalQueue = new LinkedQueue<Integer>();
      ArrayUnorderedList<T> resultList = new ArrayUnorderedList<T>();

      if (!indexIsValid(startIndex))
         return resultList.iterator();

      boolean[] visited = new boolean[numVertices];
      for (int i = 0; i < numVertices; i++)
         visited[i] = false;
      
      
      traversalQueue.enqueue(new Integer(startIndex));
      visited[startIndex] = true;
      
      while (!traversalQueue.isEmpty())
      {
         x = traversalQueue.dequeue();
         resultList.addToRear(vertices[x.intValue()]);

         // Find all vertices adjacent to x that have not been visited
         // and queue them up
         for (int i = 0; i < numVertices; i++)
         {
            if (adjMatrix[x.intValue()][i] && !visited[i])
            {
               traversalQueue.enqueue(new Integer(i));
               visited[i] = true;
            }
         }
      }
      return resultList.iterator();
   }

   //-----------------------------------------------------------------
   //  Returns an iterator that performs a breadth first search 
   //  traversal starting at the given vertex.
   //-----------------------------------------------------------------
   public Iterator<T> iteratorBFS(T startVertex)
   {      
      return iteratorBFS(getIndex(startVertex));
   }

   //-----------------------------------------------------------------
   //  Returns an iterator that contains the indices of the vertices 
   //  that are in the shortest path between the two given vertices.
   //-----------------------------------------------------------------
   protected Iterator<Integer> iteratorShortestPathIndices(int startIndex, int targetIndex)
   {
}

   //-----------------------------------------------------------------
   //  Returns an iterator that contains the shortest path between
   //  the two vertices.
   //-----------------------------------------------------------------
   public Iterator<T> iteratorShortestPath(int startIndex, int targetIndex)
   {
}

   //-----------------------------------------------------------------
   //  Returns an iterator that contains the shortest path between
   //  the two vertices.
   //-----------------------------------------------------------------
   public Iterator<T> iteratorShortestPath(T startVertex, T targetVertex)
   {
}

   //-----------------------------------------------------------------
   //  Returns the weight of the least weight path in the network.  
   //  Returns positive infinity if no path is found.
   //-----------------------------------------------------------------
   public int shortestPathLength(int startIndex, int targetIndex)
   {
}

   //-----------------------------------------------------------------
   //  Returns the weight of the least weight path in the network.  
   //  Returns positive infinity if no path is found.
   //-----------------------------------------------------------------
   public int shortestPathLength(T startVertex, T targetVertex)
   {
}

   //-----------------------------------------------------------------
   //  Returns a minimum spanning tree of the graph.
   //-----------------------------------------------------------------
   public Graph getMST()
   {
      int x, y;
      int[] edge = new int[2];
      LinkedStack<int[]> vertexStack = new LinkedStack<int[]>();
      Graph<T> resultGraph = new Graph<T>();

      if (isEmpty() || !isConnected())
         return resultGraph;
      
      resultGraph.adjMatrix = new boolean[numVertices][numVertices];
      for (int i = 0; i < numVertices; i++)
         for (int j = 0; j < numVertices; j++)
            resultGraph.adjMatrix[i][j] = false;
      resultGraph.vertices = (T[])(new Object[numVertices]);
      
      boolean[] visited = new boolean[numVertices];
      for (int i = 0; i < numVertices; i++)
         visited[i] = false;      
      
      edge[0] = 0;
      resultGraph.vertices[0] = this.vertices[0];
      resultGraph.numVertices++;
      visited[0] = true;

      // Add all edges that are adjacent to vertex 0
      // to the stack
      for (int i = 0; i < numVertices; i++)
      {
         if (!visited[i] && this.adjMatrix[0][i])
         {
            edge[1] = i;
            vertexStack.push(edge.clone());
            visited[i] = true;
         }//if
      }//for

      while ((resultGraph.size() < this.size()) && !vertexStack.isEmpty())
      {
         // Pop an edge off the stack and add it to the resultGraph.
         edge = vertexStack.pop();
         x = edge[0];
         y = edge[1];
         resultGraph.vertices[y] = this.vertices[y];
         resultGraph.numVertices++;
         resultGraph.adjMatrix[x][y] = true;
         resultGraph.adjMatrix[y][x] = true;
         visited[y] = true;

         // Add all unvisited edges that are adjacent to vertex y
         // to the stack
         for (int i = 0; i < numVertices; i++)
         {
            if (!visited[i] && this.adjMatrix[i][y])
            {
               edge[0] = y;
               edge[1] = i;
               vertexStack.push(edge.clone());
               visited[i] = true;
            }//if
         }//for
      }//while

      return resultGraph;
   }

   //-----------------------------------------------------------------
   //  Creates new arrays to store the contents of the graph with
   //  twice the capacity.
   //-----------------------------------------------------------------
   protected void expandCapacity()
   {
}

   //-----------------------------------------------------------------
   //  Returns the number of vertices in the graph.
   //-----------------------------------------------------------------
   public int size()
   {
}

   //-----------------------------------------------------------------
   //  Returns true if the graph is empty and false otherwise. 
   //-----------------------------------------------------------------
   public boolean isEmpty()
   {
}

   //-----------------------------------------------------------------
   //  Returns true if the graph is connected and false otherwise. 
   //-----------------------------------------------------------------
   public boolean isConnected()
   {
}

   //-----------------------------------------------------------------
   //  Returns the index value of the first occurrence of the vertex.
   //  Returns -1 if the key is not found.
   //-----------------------------------------------------------------
   public int getIndex(T vertex)
   {
}

   //-----------------------------------------------------------------
   //  Returns true if the given index is valid. 
   //-----------------------------------------------------------------
   protected boolean indexIsValid(int index)
   {
}

   //-----------------------------------------------------------------
   //  Returns a copy of the vertices array.
   //-----------------------------------------------------------------
   public Object[] getVertices()
   {
}
}
