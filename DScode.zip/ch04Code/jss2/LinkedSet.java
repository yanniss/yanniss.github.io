//********************************************************************
//  LinkedSet.java       Authors: Lewis/Chase
//
//  Represents a linked implementation of a set.
//********************************************************************

package jss2;

import jss2.exceptions.*;
import java.util.*;

public class LinkedSet<T> implements SetADT<T>
{
   private static Random rand = new Random();

   private int count;  // the current number of elements in the set 

   private LinearNode<T> contents; 

   //-----------------------------------------------------------------
   //  Creates an empty set.
   //-----------------------------------------------------------------
   public LinkedSet()
   {
      count = 0;
      contents = null;
   }

   //-----------------------------------------------------------------
   //  Adds the specified element to the set if it's not already
   //  present.
   //-----------------------------------------------------------------
   public void add (T element)
   {
      if (!(contains(element)))
      {
         LinearNode<T> node = new LinearNode<T> (element);
         node.setNext(contents);
         contents = node;
         count++;
      }
   }

   //-----------------------------------------------------------------
   //  Adds the contents of the parameter to this set.
   //-----------------------------------------------------------------
   public void addAll (SetADT<T> set)
   {
      
   }

   //-----------------------------------------------------------------
   //  Removes a random element from the set and returns it. Throws
   //  an EmptySetException if the set is empty.
   //-----------------------------------------------------------------
   public T removeRandom() throws EmptySetException
   {
      LinearNode<T> previous, current;
      T result = null;

      if (isEmpty())
         throw new EmptySetException();

      int choice = rand.nextInt(count) + 1;

      if (choice == 1)
      {
         result = contents.getElement();
         contents = contents.getNext();
      }
      else
      {
         previous = contents;
         for (int skip=2; skip < choice; skip++)
            previous = previous.getNext();
         current = previous.getNext();
         result = current.getElement();
         previous.setNext(current.getNext());
      }
      
      count--;
 
      return result;
   }

   //-----------------------------------------------------------------
   //  Removes the specified element from the set and returns it.
   //  Throws an EmptySetException if the set is empty and a
   //  NoSuchElemetnException if the target is not in the set.
   //-----------------------------------------------------------------
   public T remove (T target) throws EmptySetException,
                                     NoSuchElementException
   {
      boolean found = false;
      LinearNode<T> previous, current;
      T result = null;

      if (isEmpty())
         throw new EmptySetException();

      if (contents.getElement().equals(target))
      {
         result = contents.getElement();
         contents = contents.getNext();
      }
      else
      {
         previous = contents;
         current = contents.getNext();
         for (int look=0; look < count && !found; look++)
            if (current.getElement().equals(target))
               found = true;
            else
            {
               previous = current;
               current = current.getNext();
            }

         if (!found)
            throw new NoSuchElementException();

         result = current.getElement();
         previous.setNext(current.getNext());
      }
         
      count--;
 
      return result;
   }
   
   //-----------------------------------------------------------------
   //  Returns a new set that is the union of this set and the
   //  parameter.
   //-----------------------------------------------------------------
   public SetADT<T> union (SetADT<T> set)
   {
}

   //-----------------------------------------------------------------
   //  Returns true if this set contains the specified target
   //  element.
   //-----------------------------------------------------------------
   public boolean contains (T target)
   {
}

   //-----------------------------------------------------------------
   //  Returns true if this set contains exactly the same elements
   //  as the parameter.
   //-----------------------------------------------------------------
   public boolean equals (SetADT<T> set)
   {
}

   //-----------------------------------------------------------------
   //  Returns true if this set is empty and false otherwise. 
   //-----------------------------------------------------------------
   public boolean isEmpty()
   {
      
   }
 
   //-----------------------------------------------------------------
   //  Returns the number of elements currently in this set.
   //-----------------------------------------------------------------
   public int size()
   {
      
   }

   //-----------------------------------------------------------------
   //  Returns an iterator for the elements currently in this set.
   //-----------------------------------------------------------------
   public Iterator<T> iterator()
   {
      return new LinkedIterator<T> (contents, count);
   }

   //-----------------------------------------------------------------
   //  Returns a string representation of this set. 
   //-----------------------------------------------------------------
   public String toString()
   {
}
}

