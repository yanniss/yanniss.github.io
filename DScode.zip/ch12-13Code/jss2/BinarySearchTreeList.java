//*******************************************************************
//
// BinarySearchTreeList.java		Authors: Lewis/Chase
//
// Represents an ordered list implemented using a binary search tree.
//*******************************************************************

package jss2;
import jss2.exceptions.*;
import java.util.Iterator;

public class BinarySearchTreeList<t> extends BinarySearchTree<t> implements ListADT<t>, OrderedListADT<t>
{

   //================================================================
   //  Creates an empty BinarySearchTreeList.
   //================================================================
   public BinarySearchTreeList() 
   {
      super();
   }  // constructor BinarSearchTreeList


   //================================================================
   //  adds the given element to the BinarySearchTreeList
   //================================================================
public void add (T element)
   {
      addElement(element);
   }  // method add

//================================================================
//  Removes and returns the first element from this list
//================================================================

   public T removeFirst ()
   {
      return removeMin();
   }

//================================================================
//  Removes and returns the last element from this list
//================================================================
   public T removeLast ()
   {
      return removeMax();
   }

//================================================================
//  Removes and returns the specified element from this list
//================================================================
   public T remove (T element)
   {
      return removeElement(element);
   }

//================================================================
//  Returns a reference to the first element on this list
//================================================================
   public T first ()
   {
      return findMin();
   }

//================================================================
//  Returns a reference to the last element on this list
//================================================================
   public T last ()
   {
      return findMax();
   }

//================================================================
//  Returns an iterator for the list
//================================================================
   public Iterator<T> iterator()
   {
      return iteratorInOrder();
   }



}  // class BinarySearchTreeList

