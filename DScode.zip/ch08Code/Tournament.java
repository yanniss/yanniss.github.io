//===================================================================
//  Tournament.java       Authors: Lewis/Chase
//===================================================================

import java.io.*;

public class Tournament    
{
   //----------------------------------------------------------------
   //  Determines and prints the tournament organization.
   //----------------------------------------------------------------
   public static void main (String[] args ) throws IOException
   {
	   TournamentMaker temp = new TournamentMaker();
	   temp.make();
   } 
}

