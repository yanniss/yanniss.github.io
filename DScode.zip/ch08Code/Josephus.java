//===================================================================
//   JosephusLists.java       Authors: Lewis/Chase
//===================================================================

import java.util.ArrayList;
import java.util.Scanner;

public class Josephus    
{

//==============================================================
//=     Continue around the circle eliminating every nth soldier 
//=     until all of the soldiers have been eliminated 
//==============================================================
    public static void main ( String[] args) 
    {
       int numpeople, gap, newgap, counter;
       ArrayList<Integer> list = new ArrayList<Integer>();
       Scanner in = new Scanner(System.in);

       // get the initial number of soldiers
       System.out.println("Enter the number of soldiers: ");
       numpeople = in.nextInt();
       in.nextLine();

       // get the gap between soldiers
       System.out.println("Enter the gap between soldiers: ");
       gap = in.nextInt();

       // load the initial list of soldiers
       for (int count=1; count <= numpeople; count++)
       {
         list.add(new Integer(count));
       }
       counter = gap - 1; 
       newgap = gap;

       //  Treating the list as circular, remove every nth element
       //  until the list is empty 

       System.out.println("The order is: ");


       while (!(list.isEmpty())) 
       {
          System.out.println(list.remove(counter));
          numpeople = numpeople - 1;
          if (numpeople > 0)
             counter = (counter + gap - 1) % numpeople;
       }
   }
}


