//********************************************************************
//  ArrayUnorderedList.java       Authors: Lewis/Chase
//                                   Mods: JCD
//  Represents an array implementation of an unordered list.
//********************************************************************

package jss2;
import jss2.exceptions.*;

public class ArrayUnorderedList<T> extends ArrayList<T> implements UnorderedListADT<T>
{
   //-----------------------------------------------------------------
   //  Creates an empty list using the default capacity.
   //-----------------------------------------------------------------
   public ArrayUnorderedList()
   {
      super();
   }

   //-----------------------------------------------------------------
   //  Creates an empty list using the specified capacity.
   //-----------------------------------------------------------------
   public ArrayUnorderedList (int initialCapacity)
   {
      super(initialCapacity);
   }

   //-----------------------------------------------------------------
   //  Adds the specified element to the front of the list.
   //-----------------------------------------------------------------
   public void addToFront (T element)
   {
}

   //-----------------------------------------------------------------
   //  Adds the specified element to the rear of the list.
   //-----------------------------------------------------------------
   public void addToRear (T element)
   {
}

   //-----------------------------------------------------------------
   //  Adds the specified element after the specified target element.
   //  Throws a ElementNotFoundException if the target is not found.
   //-----------------------------------------------------------------
   public void addAfter (T element, T target)
   {
}
}


