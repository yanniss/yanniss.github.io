
//********************************************************************
//  DoubleOrderedList.java       Authors: Lewis/Chase
//                                   Mods : Davis
//  Represents a doubly linked implementation of an ordered list.
//********************************************************************

package jss2;
import jss2.exceptions.*;

public class DoubleOrderedList<T> extends DoubleList<T> implements OrderedListADT<T>
{
   //-----------------------------------------------------------------
   //  Creates an empty list using the default capacity.
   //-----------------------------------------------------------------
   public DoubleOrderedList()
   {
      super();
   }



   //-----------------------------------------------------------------
   //  Adds the specified element after the specified target element.
   //  Throws a ElementNotFoundException if the target is not found.
   //-----------------------------------------------------------------
   public void add (T element)
   {
}
}



