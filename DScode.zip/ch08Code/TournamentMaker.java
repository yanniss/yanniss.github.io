//===================================================================
//  TournamentMaker.java       Authors: Lewis/Chase
//===================================================================


import jss2.*;
import jss2.exceptions.*;
import java.util.Scanner;
import java.io.*;

public class TournamentMaker    
{

   //----------------------------------------------------------------
   //  Determines and prints the tournament organization.
   //----------------------------------------------------------------
   public void make ( ) throws IOException
   {
      ArrayOrderedList<Team> tournament = new ArrayOrderedList<Team>();
      String team1, team2, teamname;
      int numwins, numteams = 0;

      Scanner in = new Scanner(System.in);

      System.out.println("Tournament Maker");

      while (((numteams % 2) != 0) || (numteams == 0))
      {
         System.out.println ("Enter the number of teams (must be even):");
         numteams = in.nextInt();
         in.nextLine();
      }

      System.out.println ("Enter " + numteams + " team names and number of wins:");
      System.out.println("Teams may be entered in any order ");

      for (int count=1; count <= numteams; count++) 
      {
         System.out.println("Enter team name: ");
         teamname = in.nextLine();
         System.out.println("Enter number of wins: ");
         numwins = in.nextInt();
         in.nextLine();
         tournament.add(new Team(teamname, numwins));
       }

       System.out.println("The first round mathchups are: ");
       
       for (int count=1; count <=(numteams/2); count++)
       {
          team1 = (tournament.removeFirst()).getname();
          team2 = (tournament.removeLast()).getname();
          System.out.println ("Game " + count + " is " + team1 +
             " against " + team2);
          System.out.println ("with the winner to play the winner of game "
             + (((numteams/2)+1) - count));
       }

    }
} 


