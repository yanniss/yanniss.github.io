#ifndef _RANDOM_H
#define _RANDOM_H

unsigned long Random(unsigned long*);

#endif
