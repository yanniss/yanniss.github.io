Simple dynamic libraries for file operations. Accompanying code for
ICSR submission. Tested on Linux 2.4.3-12smp kernel and on 
SunOS 5.7 (Solaris).

Makefiles are crude--may need some editing for your compilation
environment.
