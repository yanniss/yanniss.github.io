/* Primitive locking by interposition on system calls */

#include <assert.h>
#include <stdio.h>
#include <dlfcn.h>
#include <strings.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>

#include "lock.h"


#define PATH_PREFIX ".lock/"
// has to end in a slash

#define LOCK_SUFFIX ".lock"
#define DATA_SUFFIX ".data"

#define MAX_OPEN_FILES 64

#define NUM_SUFFIXES 2
static char *interesting_suffix[NUM_SUFFIXES] = {".doc", ".txt"};


// REVIEW: Yes, I know this is not the clean way to do a linked list,
// but it will have to do.
typedef struct OFD {
  int open_fd;
  char *lock_path;
  char *data_path;
  struct OFD *next;
} open_file_data;


static open_file_data *open_files = NULL;


// The "superclass" handles to overridden functions.
static Openfn super_open;
static Closefn super_close;
static Creatfn super_creat;


static int has_interesting_suffix(const char *pathname) {
  int i;
  int len = strlen(pathname);
  for (i = 0; i < NUM_SUFFIXES; i++) {
    int suffix_len = strlen(interesting_suffix[i]);
    if (suffix_len > len)
      continue;
    if (!strcmp(pathname+len-suffix_len, interesting_suffix[i]))
      return 1;
  }
  return 0;
}


// REVIEW: The use of shared data (the open_files list) makes
// these calls non-MT-safe. Locking should be used.
static int register_open_file(char *lock_path,
			      char *data_path, int fd) {
  open_file_data *data = (open_file_data *) malloc(sizeof(open_file_data));
  data->lock_path = lock_path;
  data->data_path = data_path;
  data->open_fd = fd;
  data->next = open_files;
  open_files = data;
  return fd;
}


static open_file_data * get_open_file(int fd) {
  open_file_data *p = open_files;
  while (p != NULL) {
    if (p->open_fd == fd)
      break;
    p = p->next;
  }
  return p;
}


static void unregister_open_file(int fd) {
  if (open_files == NULL)
    return;
  if (open_files->open_fd == fd) {
    open_file_data *p = open_files->next;
    free (open_files);
    open_files = p;
  }
  else {
    open_file_data *prev = open_files;
    open_file_data *cur = open_files->next;
    while (cur != NULL) {
      if (cur->open_fd == fd)
	break;
      prev = cur;
      cur = cur->next;
    }
    prev->next = cur->next;
    free(cur);
  }
}


// Add the PATH_PREFIX after the last slash in the pathname
// and the "suffix" in the end
static char *get_extended_path(const char* pathname, const char* suffix) {
  char *extended_path = 
    (char *) malloc((strlen(pathname) + strlen(PATH_PREFIX) + 
		     strlen(suffix) + 1) * sizeof(char));
  char *last_slash = strrchr(pathname, '/');
  int slash_index = (last_slash == NULL) ? -1 : last_slash - pathname;
  strcpy(extended_path, pathname);
  strcpy(extended_path + slash_index + 1, PATH_PREFIX);
  strcpy(extended_path + strlen(extended_path) * sizeof(char),
	 pathname + slash_index + 1);
  strcpy(extended_path + strlen(extended_path) * sizeof(char), suffix);  
  return extended_path;
}
    

static int file_exists(char *pathname) {
  int result = super_open (pathname, O_RDONLY);
  if ((result == -1) && (errno == ENOENT))
    return 0;
  else if (result == -1) {
    // REVIEW: handling for failure but not because the file does not exist
    return 0;
  }
  else {
    super_close(result);
    return 1;
  }
}


#define LOCK_HELD 0
#define LOCK_FAILED -1
#define LOCK_ACQUIRED 1

// returns:
// LOCK_FAILED if the lock failed, but for system reasons (i.e., not
//  because it's held)
// LOCK_HELD  if the lock could not be acquired because it's held
// LOCK_ACQUIRED id the lock was acquired successfully
static int get_lock(char *extended_path) {
  char *last_slash = strrchr(extended_path, '/');
  int slash_index = last_slash - extended_path;
  int lock_fd;
  // a hack: we truncate the path to get the dir prefix, then fix it
  // up again
  extended_path[slash_index] = '\0';
  if (!file_exists(extended_path)) {
    // directory does not exist--create it
    int res = mkdir(extended_path, S_IRUSR | S_IWUSR | S_IXUSR);
    // REVIEW: are the above permissions enough? what if the file
    // accessed has group permissions?
    if (res == -1)
      return LOCK_FAILED;
  }
  extended_path[slash_index] = '/';

  lock_fd = super_open(extended_path, O_WRONLY | O_CREAT | O_EXCL,
		       S_IRUSR | S_IWUSR | S_IXUSR);
  // now get the lock itself
  if ( lock_fd == -1)
    if (errno != EEXIST)
      return LOCK_FAILED;
    else
      return LOCK_HELD;
  else {
    super_close(lock_fd);
    return LOCK_ACQUIRED;
  }
}


static int release_lock(char *path) {
  return unlink(path);
}
  

static void init_super() {
  super_open = (Openfn) dlsym(RTLD_NEXT, "open");
  super_close = (Closefn) dlsym(RTLD_NEXT, "close");
  super_creat = (Creatfn) dlsym(RTLD_NEXT, "creat");
}


// REVIEW: This is just a hack but I *think* it's correct.
int open64(const char* pathname, int flags, ...) { 
  mode_t mode;

  Openfn virt_open = (Openfn) dlsym(RTLD_DEFAULT, "open");
  init_super();
  // Variable arguments treatment: hopefully correct.
  if (flags & O_CREAT) {
    va_list arg;
    va_start(arg, flags);
    mode = va_arg(arg, mode_t);
    va_end(arg);
    return virt_open(pathname, flags, mode);
  } else {
    return virt_open(pathname, flags);
  }
}


int creat(const char *pathname, mode_t mode) {
  return open(pathname, O_WRONLY | O_CREAT | O_TRUNC, mode);
}


int open(const char* pathname, int flags, ...) { 
  mode_t mode;

  init_super();

  // Variable arguments treatment: hopefully correct.
  if (flags & O_CREAT) {
    va_list arg;
    va_start(arg, flags);
    mode = va_arg(arg, mode_t);
    va_end(arg);
  }

  if (has_interesting_suffix(pathname)) {
    char * lock_path = get_extended_path(pathname, LOCK_SUFFIX);
    char * data_path = get_extended_path(pathname, DATA_SUFFIX);
    // REVIEW: string operations could be more efficient (reuse
    // of prefixes, etc. but it hardly matters for overall performance

    int lock_acquired = 0;

    // The strategy is: first grab a lock that protects the shared
    // data file. Then we open the shared data file, check the number
    // of readers, writers, see if it's legal to go on, update, etc.
    while (!lock_acquired) {
      int res = get_lock(lock_path);
      switch(res) {
      case LOCK_FAILED: 
	free (lock_path);
	free (data_path);
	printf("Could not acquire lock, but not because it was held: %d\n", 
	       errno);
	goto do_default;
      case LOCK_HELD:
	// lock failed because it's held. Wait and re-try.
	sleep(1);
	break;
      default:
	assert (res == LOCK_ACQUIRED);
	lock_acquired = 1;
	break;
      }
    }
    // lock is now acquired
    {
      int data_fd = super_open(data_path, O_RDWR | O_CREAT, 
			       S_IRUSR | S_IWUSR | S_IXUSR);
      if (data_fd == -1) {
	// failed to use data file: bail out and just allow
	// uncontrolled access to file
	release_lock(lock_path);
	free (lock_path);
	free (data_path);
	printf ("Failed to use locking data file!\n");
	goto do_default;
      }
      else {   // lock acquired, data file opened
	// A hack: we read/write two ints from the file: the #readers
	// and #writers
	int buffer[2];
#define readers (buffer[0])
#define writers (buffer[1])
	int bytes_read = read(data_fd, &buffer, 2*sizeof(int));
	if (bytes_read != 2*sizeof(int))
	  readers = writers = 0;

	if (((flags & O_WRONLY) == O_WRONLY) || 
	    ((flags & O_RDWR) == O_RDWR)) {
	  // this process is a writer
	  if (readers > 0 || writers > 0) {
	    super_close(data_fd);
	    release_lock(lock_path);
	    goto file_is_being_accessed;
	  }
	  // else increment writers
	  writers++;
	}
	else {
	  // this process is a reader
	  if (writers > 0) {
	    super_close(data_fd);
	    release_lock(lock_path);
	    goto file_is_being_accessed;
	  }
	  // else we just increment readers
	  readers++;
	}
#undef readers
#undef writers

	lseek(data_fd, 0, SEEK_SET);
	write(data_fd, &buffer, 2*sizeof(int));
	// REVIEW: check for failure
	super_close(data_fd);
	release_lock(lock_path);
	if (flags & O_CREAT) {
	  return register_open_file(lock_path, data_path, 
				    super_open(pathname, flags, mode));
	}
	else
	  return register_open_file(lock_path, data_path, 
				    super_open(pathname, flags));
      }
      
      assert(0); // not reached

      // Lack of nested functions breeds gotos (or code redundancy)...
    file_is_being_accessed:
      // some other process is accessing this file--we should back off
      free (lock_path);
      free (data_path);
      // Return an error value saying that the file is inacessible
      errno = EACCES;
      printf("File cannot be accessed because it's in use.\n");
      return -1;  

    }
  }
  
 do_default:
  if (flags & O_CREAT)
    return super_open(pathname, flags, mode);
  else
    return super_open(pathname, flags);
}

	  
int close(int fd) {
  init_super();

  {  
    open_file_data *file_data = get_open_file(fd);
    if (file_data != NULL) {
      char * lock_path = file_data->lock_path;
      char * data_path = file_data->data_path;
      
      int lock_acquired = 0;
      
      // The strategy is: first grab a lock that protects the shared
      // data file. Then we open the shared data file, check the number
      // of readers, writers, see if it's legal to go on, update, etc.
      while (!lock_acquired) {
	int res = get_lock(lock_path);
	switch(res) {
	case LOCK_FAILED: 
	  free (lock_path);
	  free (data_path);
	  printf("Could not acquire lock, but not because it was held: %d\n", 
		 errno);
	  goto do_default;
	case LOCK_HELD:
	  // lock failed because it's held. Wait and re-try.
	  sleep(1);
	  break;
	default:
	  assert (res == LOCK_ACQUIRED);
	  lock_acquired = 1;
	  break;
	}
      }
      // lock is now acquired
      {
	int data_fd = super_open(data_path, O_RDWR | O_CREAT, 
				 S_IRUSR | S_IWUSR | S_IXUSR);
	if (data_fd == -1) {
	  // failed to use data file: bail out and just allow
	  // uncontrolled access to file
	  release_lock(lock_path);
	  free (lock_path);
	  free (data_path);
	  printf ("Failed to use locking data file!\n");
	  goto do_default;
	}
	else {   // lock acquired, data file opened
	  // A hack: we read/write two ints from the file: the #readers
	  // and #writers
	  int buffer[2];
#define readers (buffer[0])
#define writers (buffer[1])
	  int bytes_read = read(data_fd, &buffer, 2*sizeof(int));
	  if (bytes_read != 2*sizeof(int)) {
	    // error : there should at least be valid data, if the 
	  // file is there
	    goto do_default;
	  }
	  if (writers > 0) {
	    // this process must be a writer
	    writers--;
	  }
	  else {
	    // this process must be a reader
	    readers--;
	  }	  
#undef readers
#undef writers
	  
	  lseek(data_fd, 0, SEEK_SET);
	  write(data_fd, &buffer, 2*sizeof(int));
	  // REVIEW: check for failure
	  super_close(data_fd);
	  release_lock(lock_path);
	  free (lock_path);
	  free (data_path);
	  unregister_open_file(fd);
	}
      }
    }
  do_default:
    return super_close(fd);
  }
}


void property1() { }


// Do finalization: close all files, don't worry about allocated mem.
void _fini() {
  Closefn virt_close = (Closefn) dlsym(RTLD_DEFAULT, "close");

  //  printf("Global finalizer called!\n");

  while (open_files != NULL) {
    open_file_data *next = open_files->next;
    // "virtual" call
    virt_close(open_files->open_fd);
    open_files = next;
  }
}



#ifdef DEBUG
// regression testing for the auxiliary routines in this file. The tests
// are kept simple: they are dependent on constants that may become obsolete.
void test_it() {
  assert(has_interesting_suffix("test.doc"));
  assert(!has_interesting_suffix("te.out"));
  assert(!has_interesting_suffix("l"));
  
  assert(!strcmp(get_extended_path("/u/temp/kl", ".lock"),
		 "/u/temp/.lock/kl.lock"));

  assert(file_exists("/dev/null"));
  assert(!file_exists("/tmp/improbable.adsf"));
}
#endif

