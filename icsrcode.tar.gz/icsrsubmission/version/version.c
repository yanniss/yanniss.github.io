/* Primitive versioning by interposition on system calls */

#include <dlfcn.h>
#include <assert.h>
#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>

#include "version.h"


#define PATH_PREFIX ".version/"
// has to end in a slash

#define LOCK_SUFFIX ".lock"
#define DATA_SUFFIX ".backup"

#define MAX_OPEN_FILES 64

#define NUM_SUFFIXES 2
static char *interesting_suffix[NUM_SUFFIXES] = {".doc", ".txt"};

// The "superclass" handles to overridden functions.
static Openfn super_open;
static Creatfn super_creat;
static Unlinkfn super_unlink;
static Removefn super_remove;


static int has_interesting_suffix(const char *pathname) {
  int i;
  int len = strlen(pathname);
  for (i = 0; i < NUM_SUFFIXES; i++) {
    int suffix_len = strlen(interesting_suffix[i]);
    if (suffix_len > len)
      continue;
    if (!strcmp(pathname+len-suffix_len, interesting_suffix[i]))
      return 1;
  }
  return 0;
}


// Add the PATH_PREFIX after the last slash in the pathname
// and the "suffix" in the end
static char *get_extended_path(const char* pathname, const char* suffix) {
  char *extended_path = 
    (char *) malloc((strlen(pathname) + strlen(PATH_PREFIX) + 
		     strlen(suffix) + 1) * sizeof(char));
  char *last_slash = strrchr(pathname, '/');
  int slash_index = (last_slash == NULL) ? -1 : last_slash - pathname;
  strcpy(extended_path, pathname);
  strcpy(extended_path + slash_index + 1, PATH_PREFIX);
  strcpy(extended_path + strlen(extended_path) * sizeof(char),
	 pathname + slash_index + 1);
  strcpy(extended_path + strlen(extended_path) * sizeof(char), suffix);  
  return extended_path;
}
    

static int file_exists(char *pathname) {
  int result = super_open (pathname, O_RDONLY);
  if ((result == -1) && (errno == ENOENT))
    return 0;
  else if (result == -1) {
    // REVIEW: handling for failure but not because the file does not exist
    return 0;
  }
  else {
    // REVIEW: is just "close" correct? Should it be virtual close or
    // super close, perhaps?
    close(result);
    return 1;
  }
}


#define LOCK_HELD 0
#define LOCK_FAILED -1
#define LOCK_ACQUIRED 1

// returns:
// LOCK_FAILED if the lock failed, but for system reasons (i.e., not
//  because it's held)
// LOCK_HELD  if the lock could not be acquired because it's held
// LOCK_ACQUIRED id the lock was acquired successfully
static int get_lock(char *extended_path) {
  char *last_slash = strrchr(extended_path, '/');
  int slash_index = last_slash - extended_path;
  int lock_fd;
  // a hack: we truncate the path to get the dir prefix, then fix it
  // up again
  extended_path[slash_index] = '\0';
  if (!file_exists(extended_path)) {
    // directory does not exist--create it
    int res = mkdir(extended_path, S_IRUSR | S_IWUSR | S_IXUSR);
    // REVIEW: are the above permissions enough? what if the file
    // accessed has group permissions?
    if (res == -1)
      return LOCK_FAILED;
  }
  extended_path[slash_index] = '/';

  lock_fd = super_open(extended_path, O_WRONLY | O_CREAT | O_EXCL,
		       S_IRUSR | S_IWUSR | S_IXUSR);
  // now get the lock itself
  if ( lock_fd == -1)
    if (errno != EEXIST)
      return LOCK_FAILED;
    else
      return LOCK_HELD;
  else {
    // REVIEW: is just "close" correct? Should it be virtual close or
    // super close, perhaps?
    close(lock_fd);
    return LOCK_ACQUIRED;
  }
}


static int release_lock(char *path) {
  return unlink(path);
}
  

static void init_super() {
  super_open = (Openfn) dlsym(RTLD_NEXT, "open");
  super_creat = (Creatfn) dlsym(RTLD_NEXT, "creat");
  super_unlink = (Unlinkfn) dlsym(RTLD_NEXT, "unlink");
  super_remove = (Removefn) dlsym(RTLD_NEXT, "remove");
}


// REVIEW: This is just a hack but I *think* it's correct.
int open64(const char* pathname, int flags, ...) { 
  mode_t mode;

  Openfn virt_open = (Openfn) dlsym(RTLD_DEFAULT, "open");
  init_super();
  // Variable arguments treatment: hopefully correct.
  if (flags & O_CREAT) {
    va_list arg;
    va_start(arg, flags);
    mode = va_arg(arg, mode_t);
    va_end(arg);
    return virt_open(pathname, flags, mode);
  } else {
    return virt_open(pathname, flags);
  }
}


int creat(const char *pathname, mode_t mode) {
  return open(pathname, O_WRONLY | O_CREAT | O_TRUNC, mode);
}


static void create_consistent_copy(const char *pathname) {
  char * lock_path = get_extended_path(pathname, LOCK_SUFFIX);
  char * data_path = get_extended_path(pathname, DATA_SUFFIX);
  // REVIEW: string operations could be more efficient (reuse
  // of prefixes, etc. but it hardly matters for overall performance
  
  int lock_acquired = 0;
  
  // The strategy is: first grab a lock that protects the shared
  // data file. Then we open the shared data file, check the number
  // of readers, writers, see if it's legal to go on, update, etc.
  while (!lock_acquired) {
    int res = get_lock(lock_path);
    switch(res) {
    case LOCK_FAILED: 
      free (lock_path);
      free (data_path);
      printf("Could not acquire lock, but not because it was held: %d\n", 
	     errno);
      return;
    case LOCK_HELD:
      // lock failed because it's held. Wait and re-try.
	sleep(1);
	break;
    default:
      assert (res == LOCK_ACQUIRED);
      lock_acquired = 1;
      break;
    }
  }
  // lock is now acquired
  {
    int data_fd = super_open(data_path, O_RDWR | O_CREAT, 
			     S_IRUSR | S_IWUSR | S_IXUSR);
    if (data_fd == -1) {
      // failed to use data file: bail out and just allow
      // uncontrolled access to file
      release_lock(lock_path);
      free (lock_path);
      free (data_path);
      printf ("Failed to use versioning data file!\n");
      return;
    }
    else {   // lock acquired, data file opened
      int source_fd = super_open(pathname, O_RDONLY);
      // copy file.
      // REVIEW: more general/efficient code can be used as a drop-in
      // replacement.
#define BUFSIZE 4096
      char buf[BUFSIZE];
      int bytes_read = 0;
      do {
	bytes_read = read(source_fd, buf, BUFSIZE);
	if (bytes_read > 0)
	  write(data_fd, buf, bytes_read);
      } 
      while (bytes_read == BUFSIZE);
      // REVIEW: is just "close" correct? Should it be virtual close or
      // super close, perhaps?
      close(data_fd);
      close(source_fd);
#undef BUFSIZE
      release_lock(lock_path);
    }
  }
}


int open(const char* pathname, int flags, ...) { 
  mode_t mode;

  init_super();
  // Variable arguments treatment: hopefully correct.
  if (flags & O_CREAT) {
    va_list arg;
    va_start(arg, flags);
    mode = va_arg(arg, mode_t);
    va_end(arg);
  }

  // To do anything, the file must have an interesting suffix and must be
  // opened for write
  if (has_interesting_suffix(pathname) &&
      (((flags & O_WRONLY) == O_WRONLY) || 
       ((flags & O_RDWR) == O_RDWR)))
    create_consistent_copy(pathname);
  
  if (flags & O_CREAT)
    return super_open(pathname, flags, mode);
  else
    return super_open(pathname, flags);
}


int remove(const char *pathname) {
  // REVIEW: this is not always correct!!! It should first check that
  // the path refers to a regular file and not a directory.
  return unlink(pathname);
}


int unlink(const char *pathname) {
  init_super();
  if (has_interesting_suffix(pathname))
    create_consistent_copy(pathname);
  return super_unlink(pathname);
}

/* A test of restrictions 
void _init() {
  assert(dlsym(RTLD_NEXT, "property1"));
}
*/
