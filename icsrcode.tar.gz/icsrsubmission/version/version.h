/* Header file for primitive dynamic library */

/* I don't know exactly what the deal with open64 is, but it
   seems that currently it's the same as open. */
int open(const char *, int, ...);
int open64(const char *, int, ...);
int creat(const char *, mode_t);
int unlink(const char *);
int remove(const char *);


typedef int (*Openfn)(const char *, int, ...);
typedef int (*Open64fn)(const char *, int, ...);
typedef int (*Creatfn)(const char *, mode_t);
typedef int (*Unlinkfn)(const char *);
typedef int (*Removefn)(const char *);
