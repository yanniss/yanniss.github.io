import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import plates.APlate;
import plates.OPlate;
import plates.Plate;
import plates.oPlate.DLatticePoint;
import plates.oPlate.FLatticePoint;
import simulations.SimpleSimulation;
import simulations.Simulation;
import tools.Observer;
import view.PlateRenderer2D;


/**
 * Client
 *
 *
 * @ejb:client name="test/SSim"
 *             interface-name="simulations.SimpleSimulationInterface"
 *             home-name="simulations.SimpleSimulationHome" 
 *             type="Stateful"
 *             transaction-type="Container"
 *             jndi-name="ejb/test/SSim"
 *             original-name="simulations.SimpleSimulation" 
 *
 **/
public class GuiPlate extends JFrame implements ChangeListener, ActionListener, Observer
{
	
	private JPanel canvas_panel;
	private PlateRenderer2D hvc;
	private JPanel top_panel;
	private JPanel main_panel;
	private JSlider left_slider, right_slider, top_slider, bottom_slider;
	private JButton simulate_button;
	private JProgressBar progress_status;
	
	private JMenuItem mDblArr;
	private JMenuItem mFltArr;
	private JMenuItem mDblObj;
	private JMenuItem mFltObj;
	private JMenuItem mFileExit;
	private JMenuItem mFileNew;
	private JMenuItem mFileSteps;
	
	private JLabel label_plate_size;
	private JLabel label_steps;
	private JLabel label_type;
	private JLabel label_top;
	private JLabel label_bottom;
	private JLabel label_right;
	private JLabel label_left;

	private int backend_program = 1;
	private String backend = "Double Array";

	private final int SLIDER_MAX = 100;
	private final int SLIDER_MIN = 0;
	private final int SLIDER_INIT = 0;
	private final int SLIDER_EXTENT = 0;
	private final int SLIDER_TICK_SPACING = 20;
	private final int SIZE_MAX = 400;
	private final int SIZE_INIT = 50;
	private final int HOR_SEPARATION = 55;
	private final double CELL_NOT_USED = -1;
	
	private float top_slider_value = 0;
	private float bottom_slider_value = 0;
	private float left_slider_value = 0;
	private float right_slider_value = 0;
	private int plate_size = 50;
	private int steps = 1000;
	private long startExecTime = 0L;
	private long stopExecTime = 0L;
	private long execTime;
		
	public GuiPlate()
	{
		getContentPane().setLayout(new BorderLayout());
		setSize(700,700);
		setTitle("Plate Heat Diffusion Simulator");
		buildMenu();
		add_components();
		setVisible(true);
		this.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});
	}
	
	
	/**
	 *	Should be called in simulate() before running simulation.
	 */
	protected void startSimulationTimer()
	{
  		startExecTime = System.currentTimeMillis();
	}

	/**
	 *	Should be called in simulate() after running simulation.
	 */
	protected void stopSimulationTimer()
	{
		this.stopExecTime = System.currentTimeMillis();
		this.execTime = stopExecTime - startExecTime;
	}

	private void add_components()
	{
		/*
		 * Initialize the main panel containing the sliders
		 * 		Initialize sliders
		 *		Add sliders to panel
		 *		Add the panel
		 */
		 
		
		main_panel = new JPanel();
		left_slider = new JSlider(JSlider.VERTICAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		right_slider = new JSlider(JSlider.VERTICAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		top_slider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		bottom_slider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		setSliderProperties(left_slider);
		setSliderProperties(right_slider);
		setSliderProperties(top_slider);
		setSliderProperties(bottom_slider);
		main_panel.setLayout(new BorderLayout());
		main_panel.add(left_slider, BorderLayout.WEST);
		main_panel.add(right_slider, BorderLayout.EAST);
		main_panel.add(top_slider, BorderLayout.NORTH);
		main_panel.add(bottom_slider, BorderLayout.SOUTH);
		
		hvc = new PlateRenderer2D();
		main_panel.add(hvc, BorderLayout.CENTER);
		this.getContentPane().add(main_panel, BorderLayout.CENTER);
		
		/*
		 * Initialize the top panel containing the simulate button
		 * 		Initialize button
		 *		Add button to panel
		 *		Add panel to frame
		 */
		
		top_panel = new JPanel();
		top_panel.setLayout(new BorderLayout());
		/*Action action = new AbstractAction("Simulate"){
			public void actionPerformed(ActionEvent ae){
				/* Run The Simulation with new values 
				call_simulator();	
			}
		};*/
		
		simulate_button = new JButton("Simulate");
		simulate_button.addActionListener(this);
		progress_status = new JProgressBar();
		progress_status.setVisible(false);
		progress_status.setStringPainted(true);
		
		/*
		 * Create a panel and add the two labels
		 * Add this panel to the top panel
		 */
		
		JPanel label_panel = new JPanel();
		int align = FlowLayout.CENTER;
		label_panel.setLayout(new FlowLayout(align));
		label_type = new JLabel("Backend Type: " + backend);
		label_type.setForeground(Color.blue);
		label_plate_size = new JLabel("Plate Size: " + plate_size);
		label_plate_size.setForeground(Color.blue);
		label_steps = new JLabel("Iterations: " + steps);
		label_steps.setForeground(Color.blue);
		
		label_top = new JLabel("Top Edge Temp: " + top_slider_value);
		label_top.setForeground(Color.red);
		label_bottom = new JLabel("Bottom Edge Temp: " + bottom_slider_value);
		label_bottom.setForeground(Color.red);
		label_right = new JLabel("Right Edge Temp: " + right_slider_value);
		label_right.setForeground(Color.red);
		label_left = new JLabel("Left Edge Temp: " + left_slider_value);
		label_left.setForeground(Color.red);
		
		
		label_panel.add(label_type);
		label_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		label_panel.add(label_plate_size);
		label_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		label_panel.add(label_steps);
		label_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		label_panel.add(simulate_button);
		label_panel.add(progress_status);
		
		LineBorder lineBorder = (LineBorder)BorderFactory.createLineBorder(Color.darkGray);
		label_panel.setBorder(lineBorder);
		
		
		top_panel.add(label_panel, BorderLayout.CENTER);
		
		JPanel temp_panel = new JPanel();
		temp_panel.setLayout(new FlowLayout(align));
		temp_panel.add(label_top);
		temp_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		temp_panel.add(label_bottom);
		temp_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		temp_panel.add(label_left);
		temp_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		temp_panel.add(label_right);
		temp_panel.add(Box.createHorizontalStrut(HOR_SEPARATION));
		
		temp_panel.setBorder(lineBorder);
		
		top_panel.add(temp_panel, BorderLayout.SOUTH);
		this.getContentPane().add(top_panel, BorderLayout.NORTH);
		
		
		top_panel.setVisible(true);
		main_panel.setVisible(true);
	
		
	}
	
	public void call_simulator()
	{
		/*depending on the choice of backend
			call the backend
		*/
		final Plate plate;
		this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		this.simulate_button.setVisible(false);
		if (backend_program==1)
			plate = new APlate(plate_size, new Double(0));
		else if (backend_program==2)
			plate = new APlate(plate_size, new Float(0));
		else if (backend_program==3)
			plate = new OPlate(plate_size, new DLatticePoint());
		else
			plate = new OPlate(plate_size, new FLatticePoint());
		plate.applyTemperature(new Double(left_slider_value), new Double(right_slider_value), new Double(top_slider_value), new Double(bottom_slider_value));
		this.progress_status.setMaximum(steps);
		this.progress_status.setVisible(true);
		this.hvc.setPlate(plate);
		this.hvc.setUpdateFrequency(10);
				
		Thread nt = new Thread() {
			public void run () {
				Simulation sim = new SimpleSimulation();
				for (int i = 0; i < steps; ++i)	{
					sim.diffuse (plate);
					update(i);
					hvc.update(i);
				} //for	
			}	
		};
		nt.start ();		
		
	}
	
	/*
	 * Sets the common properties for all sliders
	 */
	 
	private void setSliderProperties(JSlider slider)
	{
		
		slider.setExtent(SLIDER_EXTENT);
		slider.setPaintTicks(true);
		slider.setMajorTickSpacing(SLIDER_TICK_SPACING);
		slider.setPaintLabels(true);
			
		// Register a change listener
    	slider.addChangeListener(this);
        	
	}
	
	/*
	 * This method is called whenever the slider's value is changed
	 */
	 
    public void stateChanged(ChangeEvent evt) {
    	JSlider slider = (JSlider)evt.getSource();
    	
      	if (!slider.getValueIsAdjusting()) {
      	    // Get new value
   			int value = slider.getValue();
            set_slider_value(slider, value);
        }
    }


	/*
	 * This method assigns the right values to the right sliders
	 */
	 
	public void set_slider_value(JSlider slider, int value)
	{
		if(slider.equals(top_slider))
		{
			top_slider_value = value;
			label_top.setText("Top Edge Temp: " + value);
		}
		else if(slider.equals(bottom_slider))
		{
			bottom_slider_value = value;
			label_bottom.setText("Bottom Edge Temp: " + value);
		}
		else if(slider.equals(left_slider))
		{
			left_slider_value = value;
			label_left.setText("Left Edge Temp: " + value);
		}
		else if(slider.equals(right_slider))
		{
			right_slider_value = value;
			label_right.setText("Right Edge Temp: " + value);
		}
	}
	

	private void buildMenu(){
		
		JMenuBar mb = new JMenuBar();
		JMenu mFile = new JMenu("File");
		JMenu mHelp = new JMenu("Help");
		JMenu mBackend = new JMenu("Backend");
		
		mDblArr = new JMenuItem("Double Array");
		mFltArr = new JMenuItem("Float Array");
		mDblObj = new JMenuItem("Double Object");
		mFltObj = new JMenuItem("Float Object");
		
		
		mFileExit = new JMenuItem("Exit");
		mFileNew = new JMenuItem("Plate size");
		mFileSteps = new JMenuItem("Number of Steps");
		
		mBackend.add(mDblArr);
		mBackend.add(mFltArr);
		mBackend.add(mDblObj);
		mBackend.add(mFltObj);
		
		mFile.add(mFileNew);
		mFile.add(mFileSteps);
		mFile.addSeparator();
		mFile.add(mFileExit);
		
		mb.add(mFile);
		mb.add(mBackend);
		
		/*
		 * Add listeners
		 */
		 
		mDblArr.addActionListener(this);
		mFltArr.addActionListener(this);
		mDblObj.addActionListener(this);
		mFltObj.addActionListener(this);
		mFileExit.addActionListener(this);
		mFileNew.addActionListener(this);
		mFileSteps.addActionListener(this);
		
		this.setJMenuBar(mb);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		Object action_widget = ae.getSource();
		if(action_widget.equals(mDblArr))
		{
			/* set backend flag to 1 */
			backend_program = 1;
			backend = "Double Array";
		}
		else if(action_widget.equals(mFltArr))
		{
			/* set backend flag to 2 */
			backend_program = 2;
			backend = "Float Array";
		}
		else if(action_widget.equals(mDblObj))
		{
			/* set backend flag to 3 */
			backend_program = 3;
			backend = "Double Object";
		}
		else if(action_widget.equals(mFltObj))
		{
			/* set backend flag to 4*/
			backend_program = 4;
			backend = "Float Object";
		}
		else if(action_widget.equals(mFileExit))
		{
			/* quit the application */
			System.exit(0);
		}
		else if(action_widget.equals(mFileSteps))
		{
			String text = JOptionPane.showInputDialog(this, "Please enter a new number of iteration steps (1-100000)");
   			if (text == null) {
        		// User clicked cancel
    		}
    		else
    		{
    			try
    			{
    				int size = Integer.parseInt(text);
    				if(size < 1 || size > 100000)
    				{	
    					JOptionPane.showMessageDialog(this, "Invalid number of iterations, Please try again!");
    				}
    				else
    				{
    					steps = size;
    					label_steps.setText("Iterations: "+steps);
    				}
    			}
    			catch(NumberFormatException ne)
    			{
    				JOptionPane.showMessageDialog(this, "Please enter a number!");
    			}
    				
    		}
		}
		else if(action_widget.equals(mFileNew))
		{
			/* get a new plate dimension */
		    String text = JOptionPane.showInputDialog(this, "Please enter a new plate size (1-150)");
   			if (text == null) {
        		// User clicked cancel
    		}
    		else
    		{
    			try
    			{
    				int size = Integer.parseInt(text);
    				if(size < 1 || size > 150)
    				{	
    					JOptionPane.showMessageDialog(this, "Invalid Plate Size, Please try again!");
    				}
    				else
    				{
    					plate_size = size;
    					label_plate_size.setText("Plate Size: "+plate_size);
    				}
    			}
    			catch(NumberFormatException ne)
    			{
    				JOptionPane.showMessageDialog(this, "Please enter a number!");
    			}
    				
    		}
		}
		else if(action_widget.equals(simulate_button))
		{
			call_simulator();
		}
		label_type.setText("Backend Type: " + backend);
	}
	

	public static void main(String args[])
	{
	
		GuiPlate gp = new GuiPlate();
		
	}

	/**
	 * @see cs4330.project1.tools.Observer#update(int)
	 */
	public void update(int iteration) {
		progress_status.setValue(iteration);
		if (iteration == steps - 1) {
			this.simulate_button.setVisible(true);
			this.setCursor(Cursor.getDefaultCursor());
			this.progress_status.setVisible(false);
		}
	}

}