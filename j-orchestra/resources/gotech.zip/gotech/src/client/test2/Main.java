package test2;

public class Main {
    
    public static void main(String[] args) {
        StringBuffer buf = new StringBuffer("Hello ");
        System.out.println("Initial Buffer: " + buf);
        Changer change = new Changer(); 
        change.change(buf);
        change.changeCBC(buf);
        System.out.println("Appended Buffer: " + buf);
        change.translate(buf);
        System.out.println("Translated Buffer: " + buf);
        change.reverse(buf);
        System.out.println("Reversed Buffer: " + buf);
    }
}
