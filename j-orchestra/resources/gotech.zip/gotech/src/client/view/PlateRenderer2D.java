package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;

import plates.Plate;
import tools.Observer;
/**
 * @author Stephan
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PlateRenderer2D extends JComponent implements Observer {

	class ObserverRunner implements Runnable {
		public PlateRenderer2D p;
		public void run() {
			p.revalidate();
			p.repaint();
		}
	}
	
	/**
	 * This class provides a component to visualize heat using
	 * different colors.
	 */
	/// initial width of component
	final static private int COMPONENT_WIDTH = 250;
	/// initial height of component
	final static private int COMPONENT_HEIGHT = 250;

	private Plate plate;
	private int updateFrequency;

	/**
	 * Constructor for HeatVisualization.
	 */
	public PlateRenderer2D() {
		super();
		final Dimension SIZE = new Dimension(COMPONENT_WIDTH, COMPONENT_HEIGHT);
		setSize(SIZE);
	}

	/**
	 * Inherited method to paint the component.
	 * @param g the Graphics object to draw on
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		if (plate == null) {
			// the array is not set: fill the complete
			// component in black
			g2.setColor(getBackground());
			g2.fillRect(0, 0, getWidth(), getHeight());
		} else {
			// array is set: fill each cell with appropriate color
			double cellHeight = (double) getHeight() / plate.getDimension();
			for (int y = 0; y < plate.getDimension(); y++) {
				double cellWidth = (double) getWidth() / plate.getDimension();
				for (int x = 0; x < plate.getDimension(); x++) {
					if (plate.getValue(x, y) >= 0.0) {
						g2.setColor(getColorForHeatValue(plate.getValue(x, y)));
					} else {
						g2.setColor(getBackground());
					}
					g2.fillRect(
						(int) (x * cellWidth),
						(int) (y * cellHeight),
						(int) cellWidth + 1,
						(int) cellHeight + 1);
				}
			}
		}
	}

	/**
	 * Converts a value to a color similar to those used
	 * in visualizations of infrared images.
	 * @param heatValue the value to convert
	 * @return the color
	 */
	public Color getColorForHeatValue(double heatValue) {
		// only values between 0 and 100 are valid
		if (heatValue > 100.0) {
			heatValue = 100.0;
		}
		if (heatValue < 0.0) {
			heatValue = 0.0;
		}
		// use the HSB color model to do the calculation
		double hue = (95.0 - heatValue) * 3.0 / 400.0;
		double saturation = 1.0;
		double brightness = 1.0;
		if (heatValue <= 5.0) {
			// get black as the coldest value
			brightness = heatValue / 5.0;
		} else if (heatValue >= 95.0) {
			// get white as the hottest
			saturation = (100.0 - heatValue) / 5.0;
		}
		return Color.getHSBColor(
			(float) hue,
			(float) saturation,
			(float) brightness);
	}

	/**
	 * @see cs4330.project1.tools.Observer#update()
	 */
	public void update(int iteration) {
		if (iteration % updateFrequency == 0) {
			ObserverRunner run = new ObserverRunner();
			run.p = this;
			try {
				SwingUtilities.invokeAndWait(run);
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Returns the plate.
	 * @return Plate
	 */
	public Plate getPlate() {
		return plate;
	}

	/**
	 * Sets the plate.
	 * @param plate The plate to set
	 */
	public void setPlate(Plate plate) {
		this.plate = plate;
	}
	
	/**
	 * Returns the updateFrequency.
	 * @return int
	 */
	public int getUpdateFrequency() {
		return updateFrequency;
	}

	/**
	 * Sets the updateFrequency.
	 * @param updateFrequency The updateFrequency to set
	 */
	public void setUpdateFrequency(int updateFrequency) {
		this.updateFrequency = updateFrequency;
	}

}
