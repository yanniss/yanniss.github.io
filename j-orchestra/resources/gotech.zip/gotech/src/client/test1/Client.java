package test1;
import java.util.*;

public class Client
{

public static void main (String args[]) {

Info info1 = new Info ("A", 1);
Info info2 = new Info ("B", 2);
Info info3 = new Info ("C", 3);
Info info4 = new Info ("D", 4);
Info info5 = new Info ("E", 5);
Info info6 = new Info ("F", 6);

RestorableSet set = new RestorableSet ();
set.add (info1);
set.add (info2);
set.add (info3);
set.add (info4);
set.add (info5);
set.add (info6);

Server server = new ServerImpl ();

System.out.println ("Before calling makeSomeChanges ()");
System.out.println ("info1 is " + info1);
System.out.println ("info2 is " + info2);
System.out.println ("info3 is " + info3);
System.out.println ("info4 is " + info4);
System.out.println ("info5 is " + info5);
System.out.println ("info6 is " + info6);
System.out.println ("set is " + set);

System.out.println ("");

server.makeSomeChanges (set);

System.out.println ("After calling makeSomeChanges ()");
System.out.println ("info1 is " + info1);
System.out.println ("info2 is " + info2);
System.out.println ("info3 is " + info3);
System.out.println ("info4 is " + info4);
System.out.println ("info5 is " + info5);
System.out.println ("info6 is " + info6);
System.out.println ("set is " + set);


}


}
