
package simulations;

import plates.Plate;


public interface Simulation
{		                                 


	/**
	 *	Call after simulate() to get the time the simulation took to run.
	 */
	public void diffuse(Plate plate);

}

