
package simulations;



public abstract class AbstractSimulation implements Simulation 
{		

	private double threshold;


	// PUBLIC METHODS ----------------------------------------------------------

	public AbstractSimulation() {
	}
	
	/**
	 * Returns the threshold.
	 * @return double
	 */
	public double getThreshold() {
		return threshold;
	}

	/**
	 * Sets the threshold.
	 * @param threshold The threshold to set
	 */
	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}

}

