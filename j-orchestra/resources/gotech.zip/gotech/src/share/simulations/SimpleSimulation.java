package simulations;

import plates.Plate;

/**
 * SimpleSimulation
 *
 * @ejb:bean name="GOTECH_SimpleSimulationBean"
 *           display-name="SimpleSimulation Bean"
 *           type="Stateful"
 *           view-type="remote"
 *           jndi-name="ejb/test/SSim"
 *
 **/
 public class SimpleSimulation extends simulations.AbstractSimulation {
	
	public SimpleSimulation() {
	}
	
	/**
	 * @ejb:interface-method view-type="remote"
         * @jboss:method-attributes copy-restore="true"        
	 */
	public void diffuse(Plate plate) {
		plate.diffuse();
	}
	
}
