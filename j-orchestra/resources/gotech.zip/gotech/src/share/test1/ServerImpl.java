package test1;

import java.util.*;
import java.rmi.server.*;
import java.rmi.RemoteException;

/**
 * ServerImpl
 *
 * @ejb:bean name="GOTECH_ServerImplBean"
 *           display-name="ServerImpl Bean"
 *           type="Stateless"
 *           view-type="remote"
 *           jndi-name="ejb/test/simpl"
**/
public class ServerImpl implements Server
{

/**
 * @ejb:interface-method view-type="remote"
 * @jboss:method-attributes copy-restore="true"            
 */
public void makeSomeChanges (RestorableSet set) {

Set toDelete = new HashSet ();
Iterator it = set.iterator ();
while (it.hasNext ()) {
	Info info = (Info)it.next ();
	if (info.getName ().equals ("D") ||	
	    info.getName ().equals ("E"))
	    toDelete.add (info);
	
	info.setName (info.getName () + info.getName ());
	info.setId (1 << info.getId ());
} //while

it = toDelete.iterator ();
while (it.hasNext ())
	set.remove (it.next ());

set.add (new Info ("GG", 128));

System.out.println ("on Server " + set);
}//makeSomeChanges


}
