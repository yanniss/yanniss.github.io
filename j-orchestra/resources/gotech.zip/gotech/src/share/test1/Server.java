package test1;

public interface Server
{

public void makeSomeChanges (RestorableSet set);

}
