package test1;

public class Info implements Comparable, java.io.Serializable
{
private String _name;
private int _id;

public Info (String name, int id) {
_name = name;
_id   = id;
}

public String toString () {
return "<" + _name + ", " + _id + ">";
}

public int compareTo (Object o) {
	return _name.compareTo (((Info)o)._name);

} 

public String getName () { return _name; }
public void setName (String name) { _name = name; }
public int getId () { return _id; }
public void setId (int id) { _id = id; }

}
