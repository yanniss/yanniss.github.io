package test1;

import java.util.*;

public class RestorableSet extends TreeSet 
{
  public RestorableSet () {
 	super (); 
  } 
  
  public RestorableSet (Collection c) {
 	super (c); 
  } 
  
  public RestorableSet (Comparator c)  {
 	super (c); 
  }
  
  public RestorableSet (SortedSet s) {
 	super (s); 
  }
			                 

}
