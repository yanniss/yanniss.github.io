package test2; 

/**
 * Changer
 *
 * @ejb:bean name="GOTECH_ChangerBean"
 *           display-name="Changer Bean"
 *           type="Stateless"
 *           view-type="remote"
 *           jndi-name="ejb/test/change"
**/
public class Changer {
    
    /**
     * @ejb:interface-method view-type="remote"
     * @jboss:method-attributes copy-restore="true"
     */
    public void change(StringBuffer s) {
        s.append("GoTech!");
    }
    
    /**
     * @ejb:interface-method view-type="remote"
     */
    public void changeCBC(StringBuffer s) {
        s.append("GoTech!");
    }
  /** 
   * @ejb:interface-method view-type="remote" 
   * @jboss:method-attributes copy-restore="true" 
   */ 
    public void translate (StringBuffer s) { 
       s.delete (0, s.length()); 
       s.append ("Hallo Welt!"); 
    } 
 
  /** 
   * @ejb:interface-method view-type="remote" 
   * @jboss:method-attributes copy-restore="true" 
   */ 
    public void reverse (StringBuffer s) { 
       s.reverse(); 
    }     
} 
