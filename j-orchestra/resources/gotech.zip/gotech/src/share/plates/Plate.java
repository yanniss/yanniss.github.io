package plates;

/**
 * @author Stephan
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Plate {
	
	public double diffuse();
	
	public void reset();
	
	public void applyTemperature(Number left, Number right, Number top, Number bottom);
	
	public double getValue(int x, int y);
	
	public int getDimension();

}
