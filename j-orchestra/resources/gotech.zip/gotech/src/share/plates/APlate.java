package plates;


/**
 * @author Stephan
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class APlate implements Plate {

	private boolean dbl;
	private int dimension;
	private float fArray[][];
	private double dArray[][];
	
	public APlate(int dimension, Number type) {
		this.dbl = type.getClass().equals(Double.class);
		this.setDimension(dimension);
		if (dbl)
			dArray = new double[dimension+2][dimension+2];
		else
			fArray = new float[dimension+2][dimension+2];
		reset();
	}

	/**
	 * @see cs4330.project1.plates.Plate#diffuse()
	 */
	public double diffuse() {
		double delta = 0;
		double oldval = 0;
		if (dbl)
			for (int i = 1; i < this.getDimension() + 1; i++)
				for (int j = 1; j < this.getDimension() + 1; j++) {
					oldval = dArray[i][j];
					dArray[i][j] = (dArray[i - 1][j] + dArray[i + 1][j] + dArray[i][j - 1] + dArray[i][j + 1]) / 4;
					delta += Math.abs(dArray[i][j] - oldval);
				}
		else
			for (int i = 1; i < this.getDimension() + 1; i++)
				for (int j = 1; j < this.getDimension() + 1; j++) {
					oldval = fArray[i][j];
					fArray[i][j] = (fArray[i - 1][j] + fArray[i + 1][j] + fArray[i][j - 1] + fArray[i][j + 1]) / 4;
					delta += Math.abs(fArray[i][j] - oldval);
				}
		return delta;
	}

	/**
	 * @see cs4330.project1.plates.Plate#reset()
	 */
	public void reset() {
		for (int i = 0; i < dimension + 2; i++)
			for (int j = 0; j < dimension + 2; j++) 
				if (dbl)
					dArray[i][j] = 0;
				else
					fArray[i][j] = 0;
	}

	/**
	 * @see cs4330.project1.plates.Plate#applyTemperature(double, double, double, double)
	 */
	public void applyTemperature(
		Number left,
		Number right,
		Number top,
		Number bottom) {
		if (dbl)
			for (int i = 1; i < dimension + 1; i++) {
				dArray[0][i] = top.doubleValue();
				dArray[dimension + 1][i] = bottom.doubleValue();
				dArray[i][0] = left.doubleValue();
				dArray[i][dimension + 1] = right.doubleValue();
			}
		else
			for (int i = 1; i < dimension + 1; i++) {
				fArray[0][i] = top.floatValue();
				fArray[dimension + 1][i] = bottom.floatValue();
				fArray[i][0] = left.floatValue();
				fArray[i][dimension + 1] = right.floatValue();
			}
	}

	/**
	 * @see cs4330.project1.plates.Plate#getValue(int, int)
	 */
	public double getValue(int x, int y) {
		return (dbl) ? dArray[y + 1][x + 1] : fArray[y + 1][x + 1];
	}

	/**
	 * @see cs4330.project1.plates.Plate#getDimension()
	 */
	public int getDimension() {
		return this.dimension;
	}

	/**
	 * Sets the dimension.
	 * @param dimension The dimension to set
	 */
	protected void setDimension(int dimension) {
		this.dimension = dimension;
	}
	

}
