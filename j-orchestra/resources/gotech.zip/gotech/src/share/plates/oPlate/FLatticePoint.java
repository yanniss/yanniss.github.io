package plates.oPlate;



public class FLatticePoint implements LatticePoint {

	private FLatticePoint left;
	private FLatticePoint right;
	private FLatticePoint top;
	private FLatticePoint bottom;

	private float value;

    /**
     * @see cs4330.project1.LatticePoint#setNeighbots(LatticePoint left,
     * LatticePoint right, LatticePoint top, LatticePoint bottom)
     */
	public void setNeighbors(
		LatticePoint left,
		LatticePoint right,
		LatticePoint top,
		LatticePoint bottom) {
		this.left = (FLatticePoint) left;
		this.right = (FLatticePoint) right;
		this.top = (FLatticePoint) top;
		this.bottom = (FLatticePoint) bottom;
	}

    /**
     * @see cs4330.project1.LatticePoint#setValue(Number value)
     */
    public final void setValue(Number value) {
        this.value = value.floatValue();
    }

    /**
     * @see cs4330.project1.LatticePoint#getValue()
     */
	public final Number getValue() {
		return new Float(value);
	}

    /**
     * @see cs4330.project1.LatticePoint#newInstance()
     */
	public LatticePoint newInstance() {
		return new FLatticePoint();
	}

    /**
     * @see cs4330.project1.LatticePoint#recompute()
     */
	public final double recompute() {
		float oldvalue = value;
		value = (left.value + right.value + top.value + bottom.value) / 4;
		return (Math.abs(oldvalue - value));
	}

}
