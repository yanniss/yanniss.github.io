package plates.oPlate;

public interface LatticePoint {
    
    /**
     *  Computes the new value of the LatticePoint.
     */
    public double recompute();

    /**
     *  Returns the current temperature of the LatticePoint.
     */
    public Number getValue();

    /**
     *  Creates a new instance with the same class as the current one.
     */
    public LatticePoint newInstance();

    /**
     *  Sets the temperature of the LatticePoint to value.
     */
    public void setValue(Number value);
    
    /**
     *  Connects the LatticePoint to neighbors
     */
    public void setNeighbors(LatticePoint left, LatticePoint right, LatticePoint top, LatticePoint bottom);

}
