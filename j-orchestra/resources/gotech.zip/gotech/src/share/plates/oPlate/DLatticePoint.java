package plates.oPlate;



public class DLatticePoint implements LatticePoint {

    private DLatticePoint left;
    private DLatticePoint right;
    private DLatticePoint top;
    private DLatticePoint bottom;

    private double value;

    /**
     * @see cs4330.project1.LatticePoint#setNeighbots(LatticePoint left,
     * LatticePoint right, LatticePoint top, LatticePoint bottom)
     */
    public void setNeighbors(
        LatticePoint left,
        LatticePoint right,
        LatticePoint top,
        LatticePoint bottom) {
        this.left = (DLatticePoint) left;
        this.right = (DLatticePoint) right;
        this.top = (DLatticePoint) top;
        this.bottom = (DLatticePoint) bottom;
    }

    /**
     * @see cs4330.project1.LatticePoint#setValue(Number value)
     */
    public final void setValue(Number value) {
        this.value = value.doubleValue();
    }

    /**
     * @see cs4330.project1.LatticePoint#getValue()
     */
    public final Number getValue() {
        return new Double(value);
    }

    /**
     * @see cs4330.project1.LatticePoint#newInstance()
     */
    public LatticePoint newInstance() {
        return new FLatticePoint();
    }

    /**
     * @see cs4330.project1.LatticePoint#recompute()
     */
    public final double recompute() {
        double oldvalue = value;
        value = (left.value + right.value + top.value + bottom.value) / 4;
        return (Math.abs(oldvalue - value));
    }

}