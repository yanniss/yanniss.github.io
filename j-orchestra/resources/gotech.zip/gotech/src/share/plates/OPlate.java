package plates;

import plates.oPlate.LatticePoint;

/**
 * @author Stephan
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class OPlate implements Plate {

	private LatticePoint type;
	private LatticePoint left;
	private LatticePoint right;
	private LatticePoint top;
	private LatticePoint bottom;
	private LatticePoint lattices[][];
	private int dimension;
	
	public OPlate(int dimension, LatticePoint type) {
		this.type = type;
		this.setDimension(dimension);
        lattices = new LatticePoint[this.getDimension()][this.getDimension()];
		this.left = type.newInstance();
		this.right = type.newInstance();
		this.top = type.newInstance();
		this.bottom = type.newInstance();
		for (int i = 0; i < this.getDimension(); i++)
			for (int j = 0; j < this.getDimension(); j++)
				lattices[j][i] = type.newInstance();
        int range = this.getDimension() - 1;
		lattices[0][0].setNeighbors(left, lattices[1][0], top, lattices[0][1]);
		lattices[range][0].setNeighbors(lattices[range - 1][0], right, top, lattices[range][1]);
		lattices[0][range].setNeighbors(left, lattices[1][range], lattices[0][range], bottom);
		lattices[range][range].setNeighbors(lattices[range - 1][range], right, lattices[range][range - 1], bottom);
		for (int i = 1; i < this.getDimension() - 1; i++) {
			lattices[i][0].setNeighbors(lattices[i - 1][0], lattices[i + 1][0], top, lattices[i][1]);
			lattices[i][range].setNeighbors(lattices[i - 1][range], lattices[i + 1][range], lattices[i][range - 1], bottom);
		}
		for (int i = 1; i < this.getDimension() - 1; i++) {
			lattices[0][i].setNeighbors(left, lattices[1][i], lattices[0][i - 1], lattices[0][i + 1]);
			lattices[range][i].setNeighbors(lattices[range - 1][i], right, lattices[range][i - 1], lattices[range][i + 1]);
			for (int j = 1; j < this.getDimension() - 1; j++)
				lattices[j][i].setNeighbors(lattices[j - 1][i], lattices[j + 1][i], lattices[j][i - 1], lattices[j][i + 1]);
		}
		this.reset();
	}

	/**
	 * @see cs4330.project1.plates.Plate#diffuse()
	 */
	public double diffuse() {
		double delta = 0;
		for (int i = 0; i < this.getDimension(); i++)
			for (int j = 0; j < this.getDimension(); j++)
				delta += lattices[j][i].recompute();
		return delta;
	}

	/**
	 * @see cs4330.project1.plates.Plate#reset()
	 */
	public void reset() {
		this.left.setValue(new Integer(0));
		this.right.setValue(new Integer(0));
		this.top.setValue(new Integer(0));
		this.bottom.setValue(new Integer(0));
        Number zero = new Integer(0);
        for (int i = 0; i < this.getDimension(); i++)
            for (int j = 0; j < this.getDimension(); j++)
                lattices[j][i].setValue(zero);
	}

	/**
	 * @see cs4330.project1.plates.Plate#applyTemperature(double, double, double, double)
	 */
	public void applyTemperature(
		Number left,
		Number right,
		Number top,
		Number bottom) {
		this.left.setValue(left);
		this.right.setValue(right);
		this.top.setValue(top);
		this.bottom.setValue(bottom);
	}

	/**
	 * @see cs4330.project1.plates.Plate#getValue(int, int)
	 */
	public double getValue(int x, int y) {
		return lattices[x][y].getValue().doubleValue();
	}

	/**
	 * @see cs4330.project1.plates.Plate#getDimension()
	 */
	public int getDimension() {
		return this.dimension;
	}

	/**
	 * Sets the dimension.
	 * @param dimension The dimension to set
	 */
	protected void setDimension(int dimension) {
		this.dimension = dimension;
	}

}
