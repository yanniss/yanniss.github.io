package org.apache.commons.pool.impl;
public class TestGenericObjectPoolThread extends Thread {
  public static int size = 42;
  protected TestGenericObjectPool tester;
  protected int option;
  public TestGenericObjectPoolThread(TestGenericObjectPool tester, int option) {
    this.tester = tester;
    this.option = option;
  }
  public void run() {
    switch (option) {
    case 0:
      System.out.println("testWhenExhaustedGrow test started.");
      try {
        tester.testWhenExhaustedGrow();
      } catch (Exception e) {
        System.out.println("Exception occured in testWhenExhaustedGrow:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWhenExhaustedGrow:" +  e.getMessage());
      }
      System.out.println("testWhenExhaustedGrow test ended.");
      break;
    case 1:
      System.out.println("testWhenExhaustedFail test started.");
      try {
        tester.testWhenExhaustedFail();
      } catch (Exception e) {
        System.out.println("Exception occured in testWhenExhaustedFail:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWhenExhaustedFail:" +  e.getMessage());
      }
      System.out.println("testWhenExhaustedFail test ended.");
      break;
    case 2:
      System.out.println("testWhenExhaustedBlock test started.");
      try {
        tester.testWhenExhaustedBlock();
      } catch (Exception e) {
        System.out.println("Exception occured in testWhenExhaustedBlock:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWhenExhaustedBlock:" +  e.getMessage());
      }
      System.out.println("testWhenExhaustedBlock test ended.");
      break;
    case 3:
      System.out.println("testEvictWhileEmpty test started.");
      try {
        tester.testEvictWhileEmpty();
      } catch (Exception e) {
        System.out.println("Exception occured in testEvictWhileEmpty:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEvictWhileEmpty:" +  e.getMessage());
      }
      System.out.println("testEvictWhileEmpty test ended.");
      break;
    case 4:
      System.out.println("testEvict test started.");
      try {
        tester.testEvict();
      } catch (Exception e) {
        System.out.println("Exception occured in testEvict:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEvict:" +  e.getMessage());
      }
      System.out.println("testEvict test ended.");
      break;
    case 5:
      System.out.println("testExceptionOnPassivateDuringReturn test started.");
      try {
        tester.testExceptionOnPassivateDuringReturn();
      } catch (Exception e) {
        System.out.println("Exception occured in testExceptionOnPassivateDuringReturn:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testExceptionOnPassivateDuringReturn:" +  e.getMessage());
      }
      System.out.println("testExceptionOnPassivateDuringReturn test ended.");
      break;
    case 6:
      System.out.println("testSetFactoryWithActiveObjects test started.");
      try {
        tester.testSetFactoryWithActiveObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetFactoryWithActiveObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetFactoryWithActiveObjects:" +  e.getMessage());
      }
      System.out.println("testSetFactoryWithActiveObjects test ended.");
      break;
    case 7:
      System.out.println("testSetFactoryWithNoActiveObjects test started.");
      try {
        tester.testSetFactoryWithNoActiveObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetFactoryWithNoActiveObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetFactoryWithNoActiveObjects:" +  e.getMessage());
      }
      System.out.println("testSetFactoryWithNoActiveObjects test ended.");
      break;
    case 8:
      System.out.println("testNegativeMaxActive test started.");
      try {
        tester.testNegativeMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testNegativeMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testNegativeMaxActive:" +  e.getMessage());
      }
      System.out.println("testNegativeMaxActive test ended.");
      break;
    case 9:
      System.out.println("testMaxIdle test started.");
      try {
        tester.testMaxIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testMaxIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMaxIdle:" +  e.getMessage());
      }
      System.out.println("testMaxIdle test ended.");
      break;
    case 10:
      System.out.println("testMaxIdleZero test started.");
      try {
        tester.testMaxIdleZero();
      } catch (Exception e) {
        System.out.println("Exception occured in testMaxIdleZero:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMaxIdleZero:" +  e.getMessage());
      }
      System.out.println("testMaxIdleZero test ended.");
      break;
    case 11:
      System.out.println("testMaxActive test started.");
      try {
        tester.testMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMaxActive:" +  e.getMessage());
      }
      System.out.println("testMaxActive test ended.");
      break;
    case 12:
      System.out.println("testMaxActiveZero test started.");
      try {
        tester.testMaxActiveZero();
      } catch (Exception e) {
        System.out.println("Exception occured in testMaxActiveZero:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMaxActiveZero:" +  e.getMessage());
      }
      System.out.println("testMaxActiveZero test ended.");
      break;
    case 13:
      System.out.println("testInvalidWhenExhaustedAction test started.");
      try {
        tester.testInvalidWhenExhaustedAction();
      } catch (Exception e) {
        System.out.println("Exception occured in testInvalidWhenExhaustedAction:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testInvalidWhenExhaustedAction:" +  e.getMessage());
      }
      System.out.println("testInvalidWhenExhaustedAction test ended.");
      break;
    case 14:
      System.out.println("testSettersAndGetters test started.");
      try {
        tester.testSettersAndGetters();
      } catch (Exception e) {
        System.out.println("Exception occured in testSettersAndGetters:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSettersAndGetters:" +  e.getMessage());
      }
      System.out.println("testSettersAndGetters test ended.");
      break;
    case 15:
      System.out.println("testDebugInfo test started.");
      try {
        tester.testDebugInfo();
      } catch (Exception e) {
        System.out.println("Exception occured in testDebugInfo:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testDebugInfo:" +  e.getMessage());
      }
      System.out.println("testDebugInfo test ended.");
      break;
    case 16:
      System.out.println("testStartAndStopEvictor test started.");
      try {
        tester.testStartAndStopEvictor();
      } catch (Exception e) {
        System.out.println("Exception occured in testStartAndStopEvictor:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testStartAndStopEvictor:" +  e.getMessage());
      }
      System.out.println("testStartAndStopEvictor test ended.");
      break;
    case 17:
      System.out.println("testEvictionWithNegativeNumTests test started.");
      try {
        tester.testEvictionWithNegativeNumTests();
      } catch (Exception e) {
        System.out.println("Exception occured in testEvictionWithNegativeNumTests:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEvictionWithNegativeNumTests:" +  e.getMessage());
      }
      System.out.println("testEvictionWithNegativeNumTests test ended.");
      break;
    case 18:
      System.out.println("testEviction test started.");
      try {
        tester.testEviction();
      } catch (Exception e) {
        System.out.println("Exception occured in testEviction:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEviction:" +  e.getMessage());
      }
      System.out.println("testEviction test ended.");
      break;
    case 19:
      System.out.println("testMinIdle test started.");
      try {
        tester.testMinIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testMinIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMinIdle:" +  e.getMessage());
      }
      System.out.println("testMinIdle test ended.");
      break;
    case 20:
      System.out.println("testMinIdleMaxActive test started.");
      try {
        tester.testMinIdleMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testMinIdleMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMinIdleMaxActive:" +  e.getMessage());
      }
      System.out.println("testMinIdleMaxActive test ended.");
      break;
    case 21:
      System.out.println("testThreaded1 test started.");
      try {
        tester.testThreaded1();
      } catch (Exception e) {
        System.out.println("Exception occured in testThreaded1:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testThreaded1:" +  e.getMessage());
      }
      System.out.println("testThreaded1 test ended.");
      break;
    case 22:
      System.out.println("testFIFO test started.");
      try {
        tester.testFIFO();
      } catch (Exception e) {
        System.out.println("Exception occured in testFIFO:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testFIFO:" +  e.getMessage());
      }
      System.out.println("testFIFO test ended.");
      break;
    case 23:
      System.out.println("testAddObject test started.");
      try {
        tester.testAddObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testAddObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testAddObject:" +  e.getMessage());
      }
      System.out.println("testAddObject test ended.");
      break;
    case 24:
      System.out.println("testUnsupportedOperations test started.");
      try {
        tester.testUnsupportedOperations();
      } catch (Exception e) {
        System.out.println("Exception occured in testUnsupportedOperations:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testUnsupportedOperations:" +  e.getMessage());
      }
      System.out.println("testUnsupportedOperations test ended.");
      break;
    case 25:
      System.out.println("testClose test started.");
      try {
        tester.testClose();
      } catch (Exception e) {
        System.out.println("Exception occured in testClose:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testClose:" +  e.getMessage());
      }
      System.out.println("testClose test ended.");
      break;
    case 26:
      System.out.println("testBaseBorrow test started.");
      try {
        tester.testBaseBorrow();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseBorrow:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseBorrow:" +  e.getMessage());
      }
      System.out.println("testBaseBorrow test ended.");
      break;
    case 27:
      System.out.println("testBaseAddObject test started.");
      try {
        tester.testBaseAddObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseAddObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseAddObject:" +  e.getMessage());
      }
      System.out.println("testBaseAddObject test ended.");
      break;
    case 28:
      System.out.println("testBaseBorrowReturn test started.");
      try {
        tester.testBaseBorrowReturn();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseBorrowReturn:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseBorrowReturn:" +  e.getMessage());
      }
      System.out.println("testBaseBorrowReturn test ended.");
      break;
    case 29:
      System.out.println("testBaseNumActiveNumIdle test started.");
      try {
        tester.testBaseNumActiveNumIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseNumActiveNumIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseNumActiveNumIdle:" +  e.getMessage());
      }
      System.out.println("testBaseNumActiveNumIdle test ended.");
      break;
    case 30:
      System.out.println("testBaseClear test started.");
      try {
        tester.testBaseClear();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseClear:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseClear:" +  e.getMessage());
      }
      System.out.println("testBaseClear test ended.");
      break;
    case 31:
      System.out.println("testBaseInvalidateObject test started.");
      try {
        tester.testBaseInvalidateObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseInvalidateObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseInvalidateObject:" +  e.getMessage());
      }
      System.out.println("testBaseInvalidateObject test ended.");
      break;
    case 32:
      System.out.println("testBaseClosePool test started.");
      try {
        tester.testBaseClosePool();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseClosePool:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseClosePool:" +  e.getMessage());
      }
      System.out.println("testBaseClosePool test ended.");
      break;
    case 33:
      System.out.println("testClosedPoolBehavior test started.");
      try {
        tester.testClosedPoolBehavior();
      } catch (Exception e) {
        System.out.println("Exception occured in testClosedPoolBehavior:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testClosedPoolBehavior:" +  e.getMessage());
      }
      System.out.println("testClosedPoolBehavior test ended.");
      break;
    case 34:
      System.out.println("testPOFAddObjectUsage test started.");
      try {
        tester.testPOFAddObjectUsage();
      } catch (Exception e) {
        System.out.println("Exception occured in testPOFAddObjectUsage:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPOFAddObjectUsage:" +  e.getMessage());
      }
      System.out.println("testPOFAddObjectUsage test ended.");
      break;
    case 35:
      System.out.println("testPOFBorrowObjectUsages test started.");
      try {
        tester.testPOFBorrowObjectUsages();
      } catch (Exception e) {
        System.out.println("Exception occured in testPOFBorrowObjectUsages:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPOFBorrowObjectUsages:" +  e.getMessage());
      }
      System.out.println("testPOFBorrowObjectUsages test ended.");
      break;
    case 36:
      System.out.println("testPOFReturnObjectUsages test started.");
      try {
        tester.testPOFReturnObjectUsages();
      } catch (Exception e) {
        System.out.println("Exception occured in testPOFReturnObjectUsages:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPOFReturnObjectUsages:" +  e.getMessage());
      }
      System.out.println("testPOFReturnObjectUsages test ended.");
      break;
    case 37:
      System.out.println("testPOFInvalidateObjectUsages test started.");
      try {
        tester.testPOFInvalidateObjectUsages();
      } catch (Exception e) {
        System.out.println("Exception occured in testPOFInvalidateObjectUsages:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPOFInvalidateObjectUsages:" +  e.getMessage());
      }
      System.out.println("testPOFInvalidateObjectUsages test ended.");
      break;
    case 38:
      System.out.println("testPOFClearUsages test started.");
      try {
        tester.testPOFClearUsages();
      } catch (Exception e) {
        System.out.println("Exception occured in testPOFClearUsages:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPOFClearUsages:" +  e.getMessage());
      }
      System.out.println("testPOFClearUsages test ended.");
      break;
    case 39:
      System.out.println("testPOFCloseUsages test started.");
      try {
        tester.testPOFCloseUsages();
      } catch (Exception e) {
        System.out.println("Exception occured in testPOFCloseUsages:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPOFCloseUsages:" +  e.getMessage());
      }
      System.out.println("testPOFCloseUsages test ended.");
      break;
    case 40:
      System.out.println("testSetFactory test started.");
      try {
        tester.testSetFactory();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetFactory:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetFactory:" +  e.getMessage());
      }
      System.out.println("testSetFactory test ended.");
      break;
    case 41:
      System.out.println("testToString test started.");
      try {
        tester.testToString();
      } catch (Exception e) {
        System.out.println("Exception occured in testToString:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testToString:" +  e.getMessage());
      }
      System.out.println("testToString test ended.");
      break;
    default:
      System.out.println("close() test started.");
      try {
        Thread.sleep(500);
        tester.close();
      } catch (Exception e) {
        System.out.println("Exception occured in close:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in close:" +  e.getMessage());
      }
      System.out.println("close() test ended.");
    }
  }
}
