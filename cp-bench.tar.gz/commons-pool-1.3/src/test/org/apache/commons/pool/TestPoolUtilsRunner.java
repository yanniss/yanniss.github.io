package org.apache.commons.pool;
public class TestPoolUtilsRunner {
    public static void main(String[] args) {
    System.out.println(" test started.");
    TestPoolUtils tester = new TestPoolUtils();
    try {
      tester.testCheckMinIdleKeyedObjectPoolKeys();
    } catch (Exception e) {
      System.out.println("Exception occured in testCheckMinIdleKeyedObjectPoolKeys:" +  e.getMessage());
    }
    try {
      tester.testCheckedPoolKeyedObjectPool();
    } catch (Exception e) {
      System.out.println("Exception occured in testCheckedPoolKeyedObjectPool:" +  e.getMessage());
    }
    try {
      tester.testErodingPoolObjectPool();
    } catch (Exception e) {
      System.out.println("Exception occured in testErodingPoolObjectPool:" +  e.getMessage());
    }
    try {
      tester.testSynchronizedPoolableFactoryKeyedPoolableObjectFactory();
    } catch (Exception e) {
      System.out.println("Exception occured in testSynchronizedPoolableFactoryKeyedPoolableObjectFactory:" +  e.getMessage());
    }
    try {
      tester.testCheckedPoolKeyedObjectPool();
    } catch (Exception e) {
      System.out.println("Exception occured in testCheckedPoolKeyedObjectPool:" +  e.getMessage());
    }
    try {
      tester.testPrefillKeyedObjectPool();
    } catch (Exception e) {
      System.out.println("Exception occured in testPrefillKeyedObjectPool:" +  e.getMessage());
    }
    try {
      tester.testAdaptKeyedPoolableObjectFactory();
    } catch (Exception e) {
      System.out.println("Exception occured in testAdaptKeyedPoolableObjectFactory:" +  e.getMessage());
    }
    try {
      tester.testAdaptKeyedPoolableObjectFactoryKey();
    } catch (Exception e) {
      System.out.println("Exception occured in testAdaptKeyedPoolableObjectFactoryKey:" +  e.getMessage());
    }
    try {
      tester.testAdaptObjectPool();
    } catch (Exception e) {
      System.out.println("Exception occured in testAdaptObjectPool:" +  e.getMessage());
    }
    try {
      tester.testSynchronizedPoolableFactoryPoolableObjectFactory();
    } catch (Exception e) {
      System.out.println("Exception occured in testSynchronizedPoolableFactoryPoolableObjectFactory:" +  e.getMessage());
    }
    System.out.println("test ended.");
  }
}
