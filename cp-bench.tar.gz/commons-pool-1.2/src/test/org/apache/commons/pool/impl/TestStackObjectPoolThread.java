package org.apache.commons.pool.impl;
public class TestStackObjectPoolThread extends Thread {
  public static int size = 16;
  protected TestStackObjectPool tester;
  protected int option;
  public TestStackObjectPoolThread(TestStackObjectPool tester, int option) {
    this.tester = tester;
    this.option = option;
  }
  public void run() {
    switch (option) {
    case 0:
      System.out.println("testIdleCap test started.");
      try {
        tester.testIdleCap();
      } catch (Exception e) {
        System.out.println("Exception occured in testIdleCap:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testIdleCap:" +  e.getMessage());
      }
      System.out.println("testIdleCap test ended.");
      break;
    case 1:
      System.out.println("testPoolWithNullFactory test started.");
      try {
        tester.testPoolWithNullFactory();
      } catch (Exception e) {
        System.out.println("Exception occured in testPoolWithNullFactory:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testPoolWithNullFactory:" +  e.getMessage());
      }
      System.out.println("testPoolWithNullFactory test ended.");
      break;
    case 2:
      System.out.println("testBorrowFromEmptyPoolWithNullFactory test started.");
      try {
        tester.testBorrowFromEmptyPoolWithNullFactory();
      } catch (Exception e) {
        System.out.println("Exception occured in testBorrowFromEmptyPoolWithNullFactory:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBorrowFromEmptyPoolWithNullFactory:" +  e.getMessage());
      }
      System.out.println("testBorrowFromEmptyPoolWithNullFactory test ended.");
      break;
    case 3:
      System.out.println("testSetFactory test started.");
      try {
        tester.testSetFactory();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetFactory:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetFactory:" +  e.getMessage());
      }
      System.out.println("testSetFactory test ended.");
      break;
    case 4:
      System.out.println("testCantResetFactoryWithActiveObjects test started.");
      try {
        tester.testCantResetFactoryWithActiveObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testCantResetFactoryWithActiveObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testCantResetFactoryWithActiveObjects:" +  e.getMessage());
      }
      System.out.println("testCantResetFactoryWithActiveObjects test ended.");
      break;
    case 5:
      System.out.println("testCanResetFactoryWithoutActiveObjects test started.");
      try {
        tester.testCanResetFactoryWithoutActiveObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testCanResetFactoryWithoutActiveObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testCanResetFactoryWithoutActiveObjects:" +  e.getMessage());
      }
      System.out.println("testCanResetFactoryWithoutActiveObjects test ended.");
      break;
    case 6:
      System.out.println("testBorrowReturnWithSometimesInvalidObjects test started.");
      try {
        tester.testBorrowReturnWithSometimesInvalidObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testBorrowReturnWithSometimesInvalidObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBorrowReturnWithSometimesInvalidObjects:" +  e.getMessage());
      }
      System.out.println("testBorrowReturnWithSometimesInvalidObjects test ended.");
      break;
    case 7:
      System.out.println("testVariousConstructors test started.");
      try {
        tester.testVariousConstructors();
      } catch (Exception e) {
        System.out.println("Exception occured in testVariousConstructors:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testVariousConstructors:" +  e.getMessage());
      }
      System.out.println("testVariousConstructors test ended.");
      break;
    case 8:
      System.out.println("testBaseBorrow test started.");
      try {
        tester.testBaseBorrow();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseBorrow:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseBorrow:" +  e.getMessage());
      }
      System.out.println("testBaseBorrow test ended.");
      break;
    case 9:
      System.out.println("testBaseAddObject test started.");
      try {
        tester.testBaseAddObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseAddObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseAddObject:" +  e.getMessage());
      }
      System.out.println("testBaseAddObject test ended.");
      break;
    case 10:
      System.out.println("testBaseBorrowReturn test started.");
      try {
        tester.testBaseBorrowReturn();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseBorrowReturn:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseBorrowReturn:" +  e.getMessage());
      }
      System.out.println("testBaseBorrowReturn test ended.");
      break;
    case 11:
      System.out.println("testBaseNumActiveNumIdle test started.");
      try {
        tester.testBaseNumActiveNumIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseNumActiveNumIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseNumActiveNumIdle:" +  e.getMessage());
      }
      System.out.println("testBaseNumActiveNumIdle test ended.");
      break;
    case 12:
      System.out.println("testBaseClear test started.");
      try {
        tester.testBaseClear();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseClear:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseClear:" +  e.getMessage());
      }
      System.out.println("testBaseClear test ended.");
      break;
    case 13:
      System.out.println("testBaseInvalidateObject test started.");
      try {
        tester.testBaseInvalidateObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseInvalidateObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseInvalidateObject:" +  e.getMessage());
      }
      System.out.println("testBaseInvalidateObject test ended.");
      break;
    case 14:
      System.out.println("testBaseClosePool test started.");
      try {
        tester.testBaseClosePool();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseClosePool:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseClosePool:" +  e.getMessage());
      }
      System.out.println("testBaseClosePool test ended.");
      break;
    case 15:
      System.out.println("testBaseCantCloseTwice test started.");
      try {
        tester.testBaseCantCloseTwice();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseCantCloseTwice:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseCantCloseTwice:" +  e.getMessage());
      }
      System.out.println("testBaseCantCloseTwice test ended.");
      break;
    default:
      System.out.println("close() test started.");
      try {
        Thread.sleep(500);
        tester.close();
      } catch (Exception e) {
        System.out.println("Exception occured in close:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in close:" +  e.getMessage());
      }
      System.out.println("close() test ended.");
    }
  }
}
