package org.apache.commons.pool.impl;
public class TestGenericObjectPoolThread extends Thread {
  public static int size = 34;
  protected TestGenericObjectPool tester;
  protected int option;
  public TestGenericObjectPoolThread(TestGenericObjectPool tester, int option) {
    this.tester = tester;
    this.option = option;
  }
  public void run() {
    switch (option) {
    case 0:
      System.out.println("testActivationException test started.");
      try {
        tester.testActivationException();
      } catch (Exception e) {
        System.out.println("Exception occured in testActivationException:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testActivationException:" +  e.getMessage());
      }
      System.out.println("testActivationException test ended.");
      break;
    case 1:
      System.out.println("testActivationExceptionOnNewObject test started.");
      try {
        tester.testActivationExceptionOnNewObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testActivationExceptionOnNewObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testActivationExceptionOnNewObject:" +  e.getMessage());
      }
      System.out.println("testActivationExceptionOnNewObject test ended.");
      break;
    case 2:
      System.out.println("testWhenExhaustedGrow test started.");
      try {
        tester.testWhenExhaustedGrow();
      } catch (Exception e) {
        System.out.println("Exception occured in testWhenExhaustedGrow:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWhenExhaustedGrow:" +  e.getMessage());
      }
      System.out.println("testWhenExhaustedGrow test ended.");
      break;
    case 3:
      System.out.println("testWhenExhaustedFail test started.");
      try {
        tester.testWhenExhaustedFail();
      } catch (Exception e) {
        System.out.println("Exception occured in testWhenExhaustedFail:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWhenExhaustedFail:" +  e.getMessage());
      }
      System.out.println("testWhenExhaustedFail test ended.");
      break;
    case 4:
      System.out.println("testWhenExhaustedBlock test started.");
      try {
        tester.testWhenExhaustedBlock();
      } catch (Exception e) {
        System.out.println("Exception occured in testWhenExhaustedBlock:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWhenExhaustedBlock:" +  e.getMessage());
      }
      System.out.println("testWhenExhaustedBlock test ended.");
      break;
    case 5:
      System.out.println("testEvictWhileEmpty test started.");
      try {
        tester.testEvictWhileEmpty();
      } catch (Exception e) {
        System.out.println("Exception occured in testEvictWhileEmpty:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEvictWhileEmpty:" +  e.getMessage());
      }
      System.out.println("testEvictWhileEmpty test ended.");
      break;
    case 6:
      System.out.println("testExceptionOnPassivateDuringReturn test started.");
      try {
        tester.testExceptionOnPassivateDuringReturn();
      } catch (Exception e) {
        System.out.println("Exception occured in testExceptionOnPassivateDuringReturn:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testExceptionOnPassivateDuringReturn:" +  e.getMessage());
      }
      System.out.println("testExceptionOnPassivateDuringReturn test ended.");
      break;
    case 7:
      System.out.println("testWithInitiallyInvalid test started.");
      try {
        tester.testWithInitiallyInvalid();
      } catch (Exception e) {
        System.out.println("Exception occured in testWithInitiallyInvalid:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWithInitiallyInvalid:" +  e.getMessage());
      }
      System.out.println("testWithInitiallyInvalid test ended.");
      break;
    case 8:
      System.out.println("testWithSometimesInvalid test started.");
      try {
        tester.testWithSometimesInvalid();
      } catch (Exception e) {
        System.out.println("Exception occured in testWithSometimesInvalid:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testWithSometimesInvalid:" +  e.getMessage());
      }
      System.out.println("testWithSometimesInvalid test ended.");
      break;
    case 9:
      System.out.println("testSetFactoryWithActiveObjects test started.");
      try {
        tester.testSetFactoryWithActiveObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetFactoryWithActiveObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetFactoryWithActiveObjects:" +  e.getMessage());
      }
      System.out.println("testSetFactoryWithActiveObjects test ended.");
      break;
    case 10:
      System.out.println("testSetFactoryWithNoActiveObjects test started.");
      try {
        tester.testSetFactoryWithNoActiveObjects();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetFactoryWithNoActiveObjects:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetFactoryWithNoActiveObjects:" +  e.getMessage());
      }
      System.out.println("testSetFactoryWithNoActiveObjects test ended.");
      break;
    case 11:
      System.out.println("testZeroMaxActive test started.");
      try {
        tester.testZeroMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testZeroMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testZeroMaxActive:" +  e.getMessage());
      }
      System.out.println("testZeroMaxActive test ended.");
      break;
    case 12:
      System.out.println("testNegativeMaxActive test started.");
      try {
        tester.testNegativeMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testNegativeMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testNegativeMaxActive:" +  e.getMessage());
      }
      System.out.println("testNegativeMaxActive test ended.");
      break;
    case 13:
      System.out.println("testMaxIdle test started.");
      try {
        tester.testMaxIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testMaxIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMaxIdle:" +  e.getMessage());
      }
      System.out.println("testMaxIdle test ended.");
      break;
    case 14:
      System.out.println("testMaxActive test started.");
      try {
        tester.testMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMaxActive:" +  e.getMessage());
      }
      System.out.println("testMaxActive test ended.");
      break;
    case 15:
      System.out.println("testInvalidWhenExhaustedAction test started.");
      try {
        tester.testInvalidWhenExhaustedAction();
      } catch (Exception e) {
        System.out.println("Exception occured in testInvalidWhenExhaustedAction:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testInvalidWhenExhaustedAction:" +  e.getMessage());
      }
      System.out.println("testInvalidWhenExhaustedAction test ended.");
      break;
    case 16:
      System.out.println("testSettersAndGetters test started.");
      try {
        tester.testSettersAndGetters();
      } catch (Exception e) {
        System.out.println("Exception occured in testSettersAndGetters:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSettersAndGetters:" +  e.getMessage());
      }
      System.out.println("testSettersAndGetters test ended.");
      break;
    case 17:
      System.out.println("testSetConfig test started.");
      try {
        tester.testSetConfig();
      } catch (Exception e) {
        System.out.println("Exception occured in testSetConfig:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testSetConfig:" +  e.getMessage());
      }
      System.out.println("testSetConfig test ended.");
      break;
    case 18:
      System.out.println("testDebugInfo test started.");
      try {
        tester.testDebugInfo();
      } catch (Exception e) {
        System.out.println("Exception occured in testDebugInfo:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testDebugInfo:" +  e.getMessage());
      }
      System.out.println("testDebugInfo test ended.");
      break;
    case 19:
      System.out.println("testStartAndStopEvictor test started.");
      try {
        tester.testStartAndStopEvictor();
      } catch (Exception e) {
        System.out.println("Exception occured in testStartAndStopEvictor:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testStartAndStopEvictor:" +  e.getMessage());
      }
      System.out.println("testStartAndStopEvictor test ended.");
      break;
    case 20:
      System.out.println("testEvictionWithNegativeNumTests test started.");
      try {
        tester.testEvictionWithNegativeNumTests();
      } catch (Exception e) {
        System.out.println("Exception occured in testEvictionWithNegativeNumTests:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEvictionWithNegativeNumTests:" +  e.getMessage());
      }
      System.out.println("testEvictionWithNegativeNumTests test ended.");
      break;
    case 21:
      System.out.println("testEviction test started.");
      try {
        tester.testEviction();
      } catch (Exception e) {
        System.out.println("Exception occured in testEviction:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testEviction:" +  e.getMessage());
      }
      System.out.println("testEviction test ended.");
      break;
    case 22:
      System.out.println("testMinIdle test started.");
      try {
        tester.testMinIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testMinIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMinIdle:" +  e.getMessage());
      }
      System.out.println("testMinIdle test ended.");
      break;
    case 23:
      System.out.println("testMinIdleMaxActive test started.");
      try {
        tester.testMinIdleMaxActive();
      } catch (Exception e) {
        System.out.println("Exception occured in testMinIdleMaxActive:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testMinIdleMaxActive:" +  e.getMessage());
      }
      System.out.println("testMinIdleMaxActive test ended.");
      break;
    case 24:
      System.out.println("testThreaded1 test started.");
      try {
        tester.testThreaded1();
      } catch (Exception e) {
        System.out.println("Exception occured in testThreaded1:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testThreaded1:" +  e.getMessage());
      }
      System.out.println("testThreaded1 test ended.");
      break;
    case 25:
      System.out.println("testAddObject test started.");
      try {
        tester.testAddObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testAddObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testAddObject:" +  e.getMessage());
      }
      System.out.println("testAddObject test ended.");
      break;
    case 26:
      System.out.println("testBaseBorrow test started.");
      try {
        tester.testBaseBorrow();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseBorrow:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseBorrow:" +  e.getMessage());
      }
      System.out.println("testBaseBorrow test ended.");
      break;
    case 27:
      System.out.println("testBaseAddObject test started.");
      try {
        tester.testBaseAddObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseAddObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseAddObject:" +  e.getMessage());
      }
      System.out.println("testBaseAddObject test ended.");
      break;
    case 28:
      System.out.println("testBaseBorrowReturn test started.");
      try {
        tester.testBaseBorrowReturn();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseBorrowReturn:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseBorrowReturn:" +  e.getMessage());
      }
      System.out.println("testBaseBorrowReturn test ended.");
      break;
    case 29:
      System.out.println("testBaseNumActiveNumIdle test started.");
      try {
        tester.testBaseNumActiveNumIdle();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseNumActiveNumIdle:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseNumActiveNumIdle:" +  e.getMessage());
      }
      System.out.println("testBaseNumActiveNumIdle test ended.");
      break;
    case 30:
      System.out.println("testBaseClear test started.");
      try {
        tester.testBaseClear();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseClear:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseClear:" +  e.getMessage());
      }
      System.out.println("testBaseClear test ended.");
      break;
    case 31:
      System.out.println("testBaseInvalidateObject test started.");
      try {
        tester.testBaseInvalidateObject();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseInvalidateObject:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseInvalidateObject:" +  e.getMessage());
      }
      System.out.println("testBaseInvalidateObject test ended.");
      break;
    case 32:
      System.out.println("testBaseClosePool test started.");
      try {
        tester.testBaseClosePool();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseClosePool:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseClosePool:" +  e.getMessage());
      }
      System.out.println("testBaseClosePool test ended.");
      break;
    case 33:
      System.out.println("testBaseCantCloseTwice test started.");
      try {
        tester.testBaseCantCloseTwice();
      } catch (Exception e) {
        System.out.println("Exception occured in testBaseCantCloseTwice:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in testBaseCantCloseTwice:" +  e.getMessage());
      }
      System.out.println("testBaseCantCloseTwice test ended.");
      break;
    default:
      System.out.println("close() test started.");
      try {
        Thread.sleep(500);
        tester.close();
      } catch (Exception e) {
        System.out.println("Exception occured in close:" +  e.getMessage());
      } catch (Error e) {
        System.out.println("Error occured in close:" +  e.getMessage());
      }
      System.out.println("close() test ended.");
    }
  }
}
