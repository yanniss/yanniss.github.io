package org.apache.commons.pool.impl;
public class TestStackObjectPoolRunner{
  public static void main(String[] args) {
    System.out.println("main thread started");
    TestStackObjectPool tester = new TestStackObjectPool("test");
    try {
      tester.init();
    } catch (Exception e) {
      System.out.println("Exception occured in init:" +  e.getMessage());
      return;
    } catch (Error e) {
      System.out.println("Error occured in init:" +  e.getMessage());
      return;
    }
    for (int i =0; i < args.length; i++) {
      int testMethod = Integer.parseInt(args[i]);
      TestStackObjectPoolThread thread = new TestStackObjectPoolThread(tester, testMethod);
      thread.start();
    }
    System.out.println("main thread ended");
  }
}
