/home/software/jPredictor/instr.sh ../bin:../../collections/bin org.apache.commons.pool.impl.TestStackObjectPoolRunner -i org. $1
