/home/software/jPredictor/sfilter.sh ../bin:../../collections/bin org.apache.commons.pool.impl.TestGenericObjectPoolRunner .GenericObjectPool -i org. $1
