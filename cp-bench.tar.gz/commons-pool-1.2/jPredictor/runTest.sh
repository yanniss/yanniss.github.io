cd output
time java -cp . $2 $4 $5 >/dev/null
cd ..
time java -cp $1:../../TestCaseGenerator/bin $2 $4 $5 >/dev/null
rm output/trace*
rm output/log.txt
