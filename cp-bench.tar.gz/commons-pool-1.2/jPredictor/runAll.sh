#!/bin/bash
for i in `seq $5 $4`;
do
   for j in `seq $i $4`;
   do
      echo $i $j
     ./runTest.sh $1 $2 $3 $i $j
   done
done    
