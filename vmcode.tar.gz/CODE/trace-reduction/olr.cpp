// OLR is a class implementing the optimal LRU reduction algorithm. 
// Given the behavior (sequence of pages fetched and evicted) of a memory
// of size k, OLR produces the shortest trace that exhibits the same behavior
// for an LRU memory of size k. If the original behavior was derived from
// a trace, then the output of OLR will also exhibit the same behavior as that
// trace for all LRU memories larger than k.

// For a stand-alone utility applying OLR, see the "main" routine at
// the end of this file.

#include <iostream.h>
#include <strstream.h>
#include <list.h>
#include "lruobj.h"
#include "input.h"

#define NOFETCH -1

struct FetchEvictEvent {
  BlockNumber fetched;
  BlockNumber evicted;
};


// A very simple class that implements input lookahead (reads FetchEvictEvents
// from input). Lookahead is rather a misnomer here. What happens is that we
// have two separate input pointers. The first (lookahead) always reads ahead
// of the second. The lookahead pointer also has limited "un-read" capability
// (can only go one step back).

// To signal an end of input, a FetchEvictEvent object with a fetch field of
// NOFETCH is returned. To handle the beginning of a reference trace uniformly,
// all events with no evictions (i.e., the first k ones) are treated as
// events that evict a block beyond the end of the queue.
class InputLookahead {
  Input input_obj;
  list<FetchEvictEvent> lookahead_buffer;
  list<FetchEvictEvent>::iterator lookahead_pointer;
  // Which location in the buffer are we reading from? 

  // Doesn't check for end of input -- may return invalid data
  FetchEvictEvent read_from_input() {
    FetchEvictEvent event;
    event.fetched = input_obj.get_next();
    event.evicted = input_obj.get_next();
    if (event.evicted == NOEVICT)
      event.evicted = LOWER_LIMIT;
    /* Make events with no eviction equivalent to events that evict something
       beyond the end of the queue. This enables the k initial references to
       be treated the same as later references */
    return event;
  }
    
public:
  InputLookahead(Input input_object) : 
    input_obj(input_object), lookahead_buffer() {
      lookahead_pointer = lookahead_buffer.end();
  }

  FetchEvictEvent get_next_lookahead() {
    FetchEvictEvent event;
    if (lookahead_pointer != lookahead_buffer.end()) 
      event = *lookahead_pointer++;
    else {
      event = read_from_input();
      if (input_obj.end_of_input())
	event.fetched = NOFETCH;
      lookahead_buffer.push_back(event);
      lookahead_pointer = lookahead_buffer.end();
    }
    return event;
  }

  // should only be called once between calls to "get_next_lookahead"
  void unget_lookahead() {
    lookahead_pointer--;
  }
    
  FetchEvictEvent get_next() {
    FetchEvictEvent event;
    if (!lookahead_buffer.empty()) {
      event = *(lookahead_buffer.begin());
      lookahead_buffer.pop_front();
    } else {
	event = read_from_input();
	if (input_obj.end_of_input())
	  event.fetched = NOFETCH;
      }
    return event;
  }
};



class OLR {
  LruQueue lru_queue; // The LRU queue used as our filter
  InputLookahead input_obj;
  
  void produce_reference(BlockNumber block) {
    lru_queue.touch(block);
    // Currently the reduced trace is just output in stdout
    cout << hex << block << " ";
  }

public:
  OLR(int queue_size, Input input_object) : lru_queue(queue_size), 
    input_obj(input_object) { }

  void filter();
};

void OLR::filter() {
  FetchEvictEvent lookahead_event = input_obj.get_next_lookahead();
  FetchEvictEvent event = input_obj.get_next();
  SetOfBlocks fetched_in_future;
  BlockNumber previous_evicted = LOWER_LIMIT;
  // The algorithm works by looking at the sequence of future evictions
  // expected by applying the trace to an LRU memory. According to those
  // evictions, extra references are output so that the queue is optimally
  // reorganized. For details, see one of the papers describing OLR.
  while (event.fetched != NOFETCH) {
    // Find all blocks that are less recently touched than the one that is
    // to be evicted next. All these blocks need to be referenced before the
    // given eviction in the final trace.
    SetOfBlocks& must_touch = lru_queue.blocks_after(event.evicted);
    while (lookahead_event.fetched != NOFETCH) {
      if (fetched_in_future.find(lookahead_event.evicted) == 
	  fetched_in_future.end()) {
	// Not among those fetched at or after the current reference. 
	// Hence, must be a block already in the queue.
	if (lru_queue.more_recent(previous_evicted,lookahead_event.evicted)) {
	  SetOfBlocks::iterator must_touch_pos = 
	    must_touch.find(lookahead_event.evicted);
	  produce_reference(lookahead_event.evicted);
	  // If it's in the "must_touch" set, make sure to remove it since
	  // it has now been touched.
	  if (must_touch_pos != must_touch.end()) 
	    must_touch.erase(must_touch_pos);
	}
	previous_evicted = lookahead_event.evicted;
      }
      else
	break;
      fetched_in_future.insert(lookahead_event.fetched);
      lookahead_event = input_obj.get_next_lookahead();
    }
    // Produce references to the rest of the blocks in the "must_touch"
    // set. These references must occur before the next time a page is
    // fetched in memory--otherwise the eviction order in the original
    // trace is not preserved.
    for (SetOfBlocks::iterator i = must_touch.begin(); 
	 i != must_touch.end();
	 i++) 
      produce_reference(*i);
    
    delete (&must_touch);
    // Finally, produce the reference causing the next fetch. Update other
    // variable accordingly.
    produce_reference(event.fetched);
    fetched_in_future.erase(event.fetched);
    event = input_obj.get_next();
  }
}

#ifdef STANDALONE_OLR
// This produces a trivial standalone executable, applying OLR to an input
// consisting of fetch-evict behavior pairs. The input format is determined
// by the Input class (e.g., could be hex or decimal according to the definition
// of "Input").

// Read input data from the standard input!
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 2) {
    cerr << "usage: " << argv[0] << " <LRU queue size>" << endl;
    exit(1);
  }
  int queue_size;
  istrstream ist(argv[1]);
  ist >> queue_size;
  OLR olr(queue_size, my_in);
  olr.filter();
}

#endif
