// The MAD trace reduction algorithm. It removes references to pages not in
// memory, if all references until the next reference to the same page are to
// pages already in memory. If MAD is used in conjunction with SAD, 
// the algorithms could alternate (one being applied to the output of the
// other) until no more compaction is achievable. 
#include <iostream.h>
#include <strstream.h>
#include <list.h>
#include "lruobj.h"
#include "input.h"

class MAD {
  LruQueue lru_queue; // The LRU queue used as our filter
  Input input_obj;
  list <BlockNumber> current_run;

  void empty_run() {
    list <BlockNumber>::iterator i = current_run.begin();
    while (i != current_run.end()) {
      cout << hex << *i << " ";
      current_run.pop_front();
      i = current_run.begin();
    }
  }

public:
  MAD(int queue_size, Input input_object) : lru_queue(queue_size), 
    input_obj(input_object) { }
  void filter() {
    if (!input_obj.end_of_input()) {
      BlockNumber next_block = input_obj.get_next();
      if (!input_obj.end_of_input()) {
	lru_queue.touch(next_block);
	current_run.push_back(next_block);
      }
      // The above makes sure we have a first reference causing a fetch at the 
      // beginning of the current run
      do {
	BlockNumber next_block = input_obj.get_next();
	if (!input_obj.end_of_input()) {
	  LruEvent event = lru_queue.touch(next_block);
	  if (event.queue_position() == 0)     
	    // It's a "fetch"! No suitable pair in the current run.
	    empty_run();
	  else if (next_block == *(current_run.begin())) {
	    // Bingo! We found a pair of references such that the first one can
	    // be dropped
	    current_run.pop_front();
	    empty_run();
	  }
	  current_run.push_back(next_block);
	}
	else break;
      } while(1);
      empty_run();
    }
  }
};

#ifdef STANDALONE_MAD
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 2) {
    cerr << "usage: " << argv[0] << " <LRU queue size>" << endl;
    exit(1);
  }
  int queue_size;
  istrstream ist(argv[1]);
  ist >> queue_size;
  MAD mad(queue_size, my_in);
  mad.filter();
}

#endif
