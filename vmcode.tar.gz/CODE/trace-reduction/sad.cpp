// The SAD trace compaction algorithm. Removes references to a page
// if they are between other references whose LRU distance is less than
// the given reduction size. The reduction results are exact for LRU and OPT
// simulations with memories at least as big as the reduction memory.
#include <iostream.h>
#include <strstream.h>
#include <list.h>
#include <map.h>

// This algorithm will be applied to traces with good locality: a linked
// list implementation of an LRU queue is expected to be faster.
#include "lruobj-list.h"
#include "input.h"

class SAD {
  LruQueue lru_queue; // The LRU queue used as our filter
  Input input_obj;
  list <BlockNumber> current_run;
  // The following map should have been a hash_map. Unfortunately not all
  // implementations of the STL support hash_maps.
  typedef map <BlockNumber, int, less < BlockNumber > > MyMap;
  MyMap number_of_references;
  // Data structure to associate a block number with the number of references
  // to this block in the current run


  // Only called at the end of a trace to flush the queue.
  void empty_run() {
    list <BlockNumber>::iterator i = current_run.begin();
    while (i != current_run.end()) {
      /* The following optimization is invalid for OPT but would work for LRU
      int& references = number_of_references[*i];
      // Are there two references to this page already in the run? (only two
      // are needed to be sure that we can eliminate the second since we know
      // that the run ends at the end of the trace)
      if (references == 2)
	erase_middle_reference(*i);
	*/
      cout << hex << *i << " ";
      current_run.pop_front();
      i = current_run.begin();
    }
  }

public:
  SAD(int queue_size, Input input_object) : lru_queue(queue_size), 
    input_obj(input_object) { }
  void filter() {
    if (!input_obj.end_of_input()) {
      do {
	BlockNumber next_block = input_obj.get_next();
	if (!input_obj.end_of_input()) {
	  LruEvent event = lru_queue.touch(next_block);
	  BlockNumber evicted = event.evicted_block();
	  if (evicted != NOEVICT)
	    move_forward(evicted);
	  else {
	    int& references = number_of_references[next_block];
	    // Are there two references to this page already in the run? (for 
	    // a total of three together with the current one)
	    if (references == 2) {
	      references = 1;
	      erase_middle_reference(next_block);
	    }
	  }
	  number_of_references[next_block]++;
	  current_run.push_back(next_block);
	}
	else break;
      } while(1);
      empty_run();
    }
  }


private:
  // If an eviction occurs, the window representing all blocks in an LRU
  // window of size less than queue_size needs to be adjusted
  void move_forward(BlockNumber evicted) {
    list<BlockNumber>::iterator last_ref_to_evicted = (current_run.end())--;
    do {
      if (*last_ref_to_evicted == evicted)
	break;
      last_ref_to_evicted--;
    } while (1);
    list<BlockNumber>::iterator one_after_last_ref = ++last_ref_to_evicted,
      i = current_run.begin();
    while (i != one_after_last_ref) {
      int& references = number_of_references[*i];
      references--;
      if (references == 0)
	number_of_references.erase(*i);
      // The code below would have worked better but g++ won't accept it
      // (incompatibilities in STL implementations, as usual)
      /*
	MyMap::iterator mi = number_of_references.find(*i);
	(*mi)--;
	// If zero references, erase from map to conserve space
	if (*mi == 0)
	number_of_references.erase(mi);
	*/
      cout << hex << *i << " ";
      current_run.pop_front();
      i = current_run.begin();
    }
  }

  // Whe we recognize a triple of the correct form we drop the middle reference
  void erase_middle_reference(BlockNumber block_number) {
    list<BlockNumber>::iterator i = (current_run.end())--;
    do {
      if (*i == block_number) {
	current_run.erase(i);
	break;
      }
      i--;
    } while (1);
  }

}; // End of SAD class

#ifdef STANDALONE_SAD
// For testing

int main(int argc, char** argv) {
  Input my_in(&cin);
  if (argc != 2) {
    cerr << "usage: " << argv[0] << " <LRU queue size>" << endl;
    exit(1);
  }
  int queue_size;
  istrstream ist(argv[1]);
  ist >> queue_size;
  SAD sad(queue_size, my_in);
  sad.filter();
}

#endif
