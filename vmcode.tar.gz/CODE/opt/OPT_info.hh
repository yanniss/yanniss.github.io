#ifndef OPT_INFO_HH
#define OPT_INFO_HH

#include <ostream.h>

class OPT_info
{
public:
  OPT_info()
  {
    next_reference = -1;
  }
  int page_number;
  int next_reference;

  friend bool operator<(const OPT_info& left, const OPT_info& right);
  friend bool operator==(const OPT_info& left, const OPT_info& right);
  friend bool operator!=(const OPT_info& left, const OPT_info& right);

  friend ostream& operator<<(ostream& output_stream,
			     const OPT_info& info_item);
  
};  

#endif
