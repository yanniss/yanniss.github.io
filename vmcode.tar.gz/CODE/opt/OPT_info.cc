#include "OPT_info.hh"
bool operator<(const OPT_info& left, const OPT_info& right)
{
  if(left.next_reference< right.next_reference)
    return true;
  return false;
}
    

bool operator==(const OPT_info& left, const OPT_info& right)
{
  if(left.page_number == right.page_number)
    return true;
  return false;
}    

bool operator!=(const OPT_info& left, const OPT_info& right)
{
  return (!(left == right));
}

ostream& operator<<(ostream& output_stream,
		    const OPT_info& info_item)
{

  output_stream << '<'
		<< info_item.page_number
		<< ','
		<< info_item.next_reference
		<< '>';

  return output_stream;

}
