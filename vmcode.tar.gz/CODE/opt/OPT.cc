#include <iostream.h>
#include <vector.h>
#include <set.h>
#include <assert.h>
#include "OPT_info.hh"
#include "opt_queue.hh"
#include "OPT_set.hh"
class OPT_sim
{
public:
  
  // OPT_sim constructor takes the size of memory(in pages) for the 
  // simulation to run on.
  OPT_sim(int queue_size);
  

  // backward_pass reads the big_vector from the rear and sets the time information
  void backward_pass();
  
  // forward_pass uses an OPT_set  
  void forward_pass();

  // initialize reads in the trace and sets up the vector.
  void simulate();

private:
  
  // Vector Holds the trace
  vector<OPT_info> trace;

  // SFK: xxx Clean up the code that is meaningful only for
  // simulations that are for a specific memory size.
  // size of the OPT memory
  int max_pages_in_queue;
  
  // capacity_miss is initialized to 0 in the constructor then incremented every
  // time you bring a page that has been evicted back into memory.
  int capacity_miss;
  
  // compulsory_faults counts the number of compulsory faults in the simulation.
  // compulsory_faults is initialized to 0 in the constructor.
  int compulsory_faults;
  
};


OPT_sim::OPT_sim(int queue_size)
{
  max_pages_in_queue = queue_size;
  compulsory_faults = 0;
  capacity_miss = 0;
}


void OPT_sim::simulate()
{
  OPT_info temp_info;
  int temp_page;
  // SFK: Small change for cleaner loop structure.
  while (cin >> hex >> temp_page)
    {
      temp_info.page_number = temp_page;
      trace.push_back(temp_info);
    }
  backward_pass();
  forward_pass();

  // SFK: These lines of output are commented out because the
  // opt_queue class outputs an entire histogram of hits at each stack
  // position accumulated throughout the simulation.
  // cout << "The Number of Compulsory Hits " << compulsory_faults << endl;
  // cout << "The Number of Demand Fetches " << capacity_miss << endl;

}


void OPT_sim::backward_pass()
{
  unsigned int counter = 0;
  OPT_info temp_info;
  OPT_set distance_set;
  list<OPT_info>::iterator set_iterator;

  // SFK: Debugging.
  // cerr << "Backward pass..." << endl;

  // SFK: Assume a non-empty trace.  If it is, there is no simulation
  // to perform anyway, so its failure isn't consequential.
  assert(trace.begin() != trace.end());
  vector<OPT_info>::iterator trace_iterator = trace.end();
  
  do
    {

      trace_iterator--;
      counter++;

      // SFK: Debugging.
      // cerr << "\tCounter = " << counter << ": ";

      set_iterator = distance_set.find(*trace_iterator);
      if(set_iterator == distance_set.end())
	{

	  // SFK: Debugging.
	  // cerr << (*trace_iterator).page_number
	  // << " not in distance set."
	  // << endl;

	  (*trace_iterator).next_reference = 0;
	  temp_info.next_reference = counter;
	  temp_info.page_number = (*trace_iterator).page_number;
	  distance_set.insert(temp_info);
	}
      else
	{

	  // SFK: Debugging.
	  // cerr << (*trace_iterator).page_number
	  //  << " found with next reference at "
	  //  << (*set_iterator).next_reference
	  //  << endl;
	  (*trace_iterator).next_reference =
	    (*set_iterator).next_reference;
	  (*set_iterator).next_reference = counter;
	}
    }
  while(trace_iterator != trace.begin());

}


void OPT_sim::forward_pass()
{

  opt_queue queue;
  vector<OPT_info>::iterator trace_iterator = trace.begin();

  // SFK: Debugging.
  // cerr << "Forward pass..." << endl;

  while(trace_iterator != trace.end())
    {
      queue.touch(*trace_iterator);
      trace_iterator++;
    }
  queue.print_histogram();

}




int main()
{
  OPT_sim bob(1);
  bob.simulate();
}
