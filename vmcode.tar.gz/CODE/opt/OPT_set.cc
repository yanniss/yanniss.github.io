#include "OPT_set.hh"
#include <iostream.h>

void OPT_set::insert(OPT_info element)
{
  big_list.push_back(element);
}

list<OPT_info>::iterator OPT_set::find(OPT_info key)
{
  list<OPT_info>::iterator search_iterator = big_list.begin();

  while ((search_iterator != big_list.end()) &&
	 (*(search_iterator) != key))
    {
      search_iterator++;
    }
  return search_iterator;
}

void OPT_set::erase(list<OPT_info>::iterator erase_me)
{
  big_list.erase(erase_me);
}

list<OPT_info>::iterator OPT_set::end()
{
  return big_list.end();
}

int OPT_set::get_size()
{
  return big_list.size();
}

list<OPT_info>::iterator OPT_set::find_min()
{
  list<OPT_info>::iterator compare = big_list.begin();
  list<OPT_info>::iterator min_it = big_list.begin();
  while(compare != big_list.end())
    {
      if(*min_it < *compare)
	min_it = compare;
      compare++;
    }
  return min_it;
}

