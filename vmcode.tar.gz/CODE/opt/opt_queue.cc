#include "opt_queue.hh"
#include "OPT_info.hh"
#include <iostream.h>


void opt_queue::touch(OPT_info key_element)
{
  int found_at_pos;
  OPT_info temp_info;
  
  found_at_pos = find(key_element);

  // SFK: Debugging.
  // cerr << '\t'
  // << key_element
  // << " found at "
  // << found_at_pos
  // << endl;

  if(found_at_pos != -1)
    {

      // cerr << "\tHit:" << endl;

      // Hit.  Place the referenced page in the first stack position.
      temp_info = memory[1].info;
      memory[1].info = key_element;
      // cerr << "\t\tAt 1 SWAPPED in "
      // << memory[1].info
      // << " for "
      // << temp_info
      // << endl;

      // Trickle down each displaced element based on OPT priority, up
      // until position preceeding the position left empty by the
      // referenced position.
      for(int j = 2; j < found_at_pos;j++)
	{

	  // cerr << "\t\tAt " << j;

	  if(!(temp_info < memory[j].info))
	    {
	      swap_nodes(temp_info, memory[j].info);
	      //cerr << " SWAPPED in "
	      // << memory[j].info
	      // << " for "
	      // << temp_info
	      // << endl;
	    }
	  else
	    {
	      // cerr << " KEPT in "
	      // << memory[j].info
	      // << " over "
	      // << temp_info
	      // << endl;
	    }
	}

      // Place the lowest remaining priority item in the empty slot
      // left by the referenced item.
      if (found_at_pos > 1)
	memory[found_at_pos].info = temp_info;

    }
  else
    {

      // cerr << "\tMiss:" << endl;

      // Compulsory miss.  Place the newly referenced page in the
      // first stack position.
      compulsory_faults++;
      // cerr << "Unique page "
      // << dec
      // << compulsory_faults
      // << " = "
      // << hex
      // << key_element.page_number
      // << endl;

      temp_info = memory[1].info;
      memory[1].info = key_element;
      // cerr << "\t\tAt 1 SWAPPED in "
      // << memory[1].info
      // << " for "
      // << temp_info
      // << endl;

      // Trickle down each displaced element based on OPT priority,
      // all the way down the stack.
      for(int j = 2; j < compulsory_faults; j++)
	{

	  // cerr << "\t\tAt " << j;

	  if(!(temp_info < memory[j].info))
	    {
	      swap_nodes(temp_info, memory[j].info);
	      // cerr << " SWAPPED in "
	      // << memory[j].info
	      // << " for "
	      // << temp_info
	      // << endl;
 	    }
	  else
	    {
	      // cerr << " KEPT in "
	      // << memory[j].info
	      // << " over "
	      // << temp_info
	      // << endl;
	    }
	}

      // Place the lowest remaining priority item in the last slot of
      // the newly expanded stack.
      if (compulsory_faults > 1)
	memory[compulsory_faults].info = temp_info;
    }

  // for (int index = 1; index <= compulsory_faults; index++) {
  // cerr << "\t\t" << index << ' ' << memory[index].info << endl;
  // }

  // If the array used to store the stack is now full, expand that
  // array so that the stack can grow.
  if(compulsory_faults == max_stack_size - 1)
    double_length();
}



int opt_queue::find(OPT_info page)
{
  int found_at_position = -1;
  for(int j = 1; j <= compulsory_faults; j++)
    {
      if(page == memory[j].info)
	{
	  found_at_position = j;
	  memory[j].hit_counter++;
	  break;
	}
    }

  return found_at_position;
}



void opt_queue::swap_nodes(OPT_info &x, OPT_info &y)
{
  OPT_info temp = x;
  x = y;
  y = temp;
}



void opt_queue::double_length()
{
  max_stack_size *= 2;
  opt_queue_node* temp = new opt_queue_node[max_stack_size];
  for(int j = 1; j <= compulsory_faults; j++)
    temp[j] = memory[j];
  delete memory;
  memory = temp;
}



void opt_queue::print_histogram()
{
  cout << "0 " << compulsory_faults << endl;
  for(int j = 1; j <= compulsory_faults; j++) {
    int count = 0;
    for (int i = j+1; i <= compulsory_faults; i++) 
      count += memory[i].hit_counter;
    cout << j << " " << count << endl;
  }
}



