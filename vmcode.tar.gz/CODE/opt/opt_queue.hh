#ifndef OPT_QUEUE_HH
#define OPT_QUEUE_HH

#include "OPT_info.hh"

class opt_queue
{
public:

  class opt_queue_node
  {
  public:
    opt_queue_node()
    {
      hit_counter = 0;
    }
    OPT_info info;
    int hit_counter;
  };

  // Constructor
  opt_queue()
  {
    // SFK: This initial size is arbitrary, but should be sufficient
    // in many cases.
    max_stack_size = 5000;
    compulsory_faults = 0;
    memory = new opt_queue_node[5000];
  }
  
  // Touch
  void touch(OPT_info key_element);

  // print histogram, outputs the position number
  // followed by a space and the number of hits at
  // that position.
  void print_histogram();
  
private:
  
  // Double the arrays size.
  void double_length();
  
  // find routine
  int find(OPT_info page);
  
  // swap_info
  void swap_nodes(OPT_info &x, OPT_info &y);
  
  // array represents positions in memory
  opt_queue_node *memory;

  // number of compulsory faults.
  // if this number reaches the size
  // of allocated memory for the array
  // double_length is called to allocate 
  // more space.
  int compulsory_faults;

  // The maximum size of the stack given the current array used to
  // store it.
  int max_stack_size;

};
#endif



