#ifndef OPT_SET_HH
#define OPT_SET_HH

#include <list.h>
#include "OPT_info.hh"

class OPT_set
{
public:
  
  OPT_set(){}
  
  // insert
  void insert(OPT_info element);
  
  // find 
  list<OPT_info>::iterator find(OPT_info key);

  // erase
  void erase(list<OPT_info>::iterator erase_me);
  
  // end
  list<OPT_info>::iterator end();
  
  // returns the cardinality of the set
  int get_size();

  // find_min
  list<OPT_info>::iterator find_min();
  
private:
  
  list<OPT_info> big_list;
};
#endif
