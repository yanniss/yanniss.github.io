// This new version of EELRU does not have a fixed number of early-late
// point combinations. Instead, it receives an input parameter that
// determines the "density" of the histogram maintained. Any boundary of
// a histogram region becomes a potential early or late eviction point from
// the perspective of the simulator.


#include "lruobj.h"
#include <strstream.h>
#include <math.h>
#include <stdlib.h>
#include <set.h>


// REVIEW: maybe move ASSERT to another file. Ok for now: keep file
// number small
#ifdef DEBUG
  void _Assert(char *strFile, unsigned uLine) {
    cerr << "\nAssertion failed: " << strFile << ", line " << uLine << endl;
    abort();
  }

  #define ASSERT(f) \
    if (f)          \
        {}          \
    else            \
        _Assert(__FILE__, __LINE__)
#else
  #define ASSERT(f)
#endif

#define forall(iterator) for (int iterator = 0; \
				iterator <= num_regions; \
				iterator++)
			

// EELRU is a subclass of LruQueue, but LruQueue does *not* strictly
// behave in an LRU fashion. LruQueue is just a way to look at pages
// by recency, but we can evict any page at fault time.

class EELRU : public LruQueue {
protected:
  // The most recently touched pages are always kept in memory and 
  // the following vars show which recency positions are in the eviction region
  QueuePos start_qpos;
  QueuePos end_qpos;
  int num_regions;
  // How many distinct regions does our recency histogram have?
  double *region_fraction; 
  // an array of region starting points, as fractions of the mem size
  QueuePos *region_start_qpos;
  // an array of the recency indexes for region starting points. Regions
  // extend to infinity.
  
  // basic performance stats
  int misses;              // misses this simulated memory suffers
  int compulsory_faults; // Faults caused by referencing a page for the
			// first time.
  int plain_lru_misses; // misses plain lru would suffer, just for comparison


  // adaptivity data
  // Definition: replacement interval (r.i.): the time during which
  // a number of "interesting events" (faults, hits in the interesting region)
  // equal to the cache (memory) size occur

  // Definition: virtual time: time measured in "r.i."s
  double stats_decay_factor;/* double decay factor to multiply stats by per 
			       (approx) replacement interval (lower factor
			       decays FASTER) */
  double far_miss_weight;   /* double fraction of a miss that a far miss counts
			       as for advancing time */
  // parameters computed from input parameters
  // stats are decayed about once every eighth of a replacement interval
  double time_per_fault;    /* virtual time per fault (fraction of replacement
			      interval */
  double decay_per_eighth;  /* decay factor (double between 0 and 1)
			       to multiply stats by per eighth of r.i. */

  // stats maintained for adaptivity
  double time_before_this_eighth;
  /* virtual time in (approx) "replacement intervals", not including time so
     far this 1/8 replacement interval. */
  // These are the stats that get decayed !!!
  double time_this_eighth;   // virtual time since last decay
  double *hits_in_region_lately;  // array holding the histogram 
  int last_used_early_point;


  // Data structures for pages
  LruQueue* lru_stats_sim;  
  /* lru queue used for determining pure lru queue positions for adaptivity 
     stats, and for comparison */

  // A set of the blocks that are known to the simulator, used to
  // determine whether or not a fault is compulsory.
  set<BlockNumber, less<BlockNumber> > knownBlocks;


public:
  EELRU(int msize,
	int n_regions,
	double *r_fraction,
	double lateness,
	double decayf,
	double missweight,
	Input input_object) :
    LruQueue(msize, input_object),
    num_regions(n_regions),
    region_fraction(r_fraction),
    stats_decay_factor(decayf),
    far_miss_weight(missweight),
    misses(0),
    compulsory_faults(0),
    plain_lru_misses(0),
    last_used_early_point(0)
  {
    // We allocate one more entry than needed in the arrays for
    // regions, so that it can serve as a sentinel and simplify
    // operations. In essence, we are creating a "virtual" region for
    // the recency part after the end of our queue. 
    // DESIGN INSIGHT: it is *necessary* to keep hit (or rather, miss)
    // statistics for this virtual region because these affect our
    // probabilities calculations.
    region_start_qpos = new QueuePos[num_regions+1];

    forall(i) {
      if (i != num_regions)
	region_start_qpos[i] = (QueuePos) (max_size * region_fraction[i]);
      else
	region_start_qpos[i] = (QueuePos) (max_size * lateness);
    }
    // PRECONDITION: the numbers in region_fraction are in increasing order,
    // and lateness is greater than all of them.

    start_qpos = region_start_qpos[0];
    end_qpos = region_start_qpos[num_regions];

    time_per_fault = 1.0 / max_size;
    decay_per_eighth = eighth_root(stats_decay_factor);

    time_before_this_eighth = 0.0;
    time_this_eighth = 0.0;
    hits_in_region_lately = new double[num_regions+1];
    forall(i)
      hits_in_region_lately[i] = 0.0;

    lru_stats_sim = new LruQueue(end_qpos);
  }

protected:
  // Find the region of the interesting range that this qpos falls in.
  // PRECONDITION: the qpos is not in the early range (qpos > start_qpos)
  // and is not beyond the end of the recency queue (qpos <= end_qpos).
  int latest_region_for_qpos(QueuePos qpos) {
    // Do linear search until right region found.
    // REVIEW: can make this faster for many regions using binary search.
    // Shouldn't matter for now.
    forall(i)
      if (qpos <= region_start_qpos[i])
	return(i-1);
  }

  // returns the number of all hits in the interesting range
  double all_hits_lately() { return hits_in_region_lately[0]; }

  double hits_in_region_diff(int region) {
    return hits_in_region_lately[region] - hits_in_region_lately[region+1];
  }

  double hits_in_region_diff(int region1, int region2) {
    return hits_in_region_lately[region1] - hits_in_region_lately[region2];
  }
  
  int region_diff_width(int region) {
    return region_start_qpos[region + 1] - region_start_qpos[region];
  }
  
  double normalize_hits(double hits) {
    return hits / all_hits_lately();
  }

private:
  double eighth_root(double number) { return sqrt(sqrt(sqrt(number))); }

protected:
  void maybe_decay_stats() {
    while (time_this_eighth >= 0.125) // more than 1/8 repl. interval?
      decay_stats();
    /* do it again in case there's more than 1/8 repl. interval left
       since after decaying once.  This should only happen for very
       small queue sizes (around 8 or less), where a single fault
       can advance time by more than 1/8 of a replacement interval. */
  }

  void decay_stats() {
    // add 1/8 replacement interval to time before this eighth
    time_before_this_eighth += 0.125;
    // subtract 1/8 replacement interval from time for current eighth
    // (we're really starting a new eighth, but keeping the extra
    // left over from the previous one)
    time_this_eighth -= 0.125;
    
    // decay the counts of hits by the factor
    // appropriate to an eighth of a replacement interval
    forall(i)
      hits_in_region_lately[i] *= decay_per_eighth;
  }

public:

  virtual BlockNumber evict(BlockNumber block_num) {
    return evict_nth_mru_block(pos_of_block_to_evict(block_num));
  }

  // Returns the position to evict from
  int pos_of_block_to_evict(BlockNumber block_num) {
    int mem_size_index = latest_region_for_qpos(max_size) + 1;
    
    // Initial state: how many hits did LRU get?
    double max_hits = hits_in_region_diff(0, mem_size_index);
    int early_index = mem_size_index;
    int late_index = mem_size_index;

    // The valid early points are before the memory size, the valid
    // late points beyond the memory size.
    for (int early = 0; early < mem_size_index; early++)
      for (int late = mem_size_index + 1; late <= num_regions; late++) {
	double late_hits = (late == num_regions) ? 
	  hits_in_region_lately[mem_size_index]: 
	  hits_in_region_diff(mem_size_index, late);
	// APPROXIMATION: far misses are treated as hits in the last
	// interesting region. I.e., we purposely underestimate their
	// recency, to make the algorithm more aggressive for things
	// too far to observe. This shouldn't matter in the vast majority
	// of cases.

	double early_hits = hits_in_region_diff(early, mem_size_index);
	double hits_before_early = hits_in_region_diff(0, early);
	double keep_probability = (double)(max_size - 
					   region_start_qpos[early]) /
	  (region_start_qpos[late] - region_start_qpos[early]);
	  
	double total_expected_hits = hits_before_early + 
	  (late_hits + early_hits) * keep_probability;

	if (total_expected_hits > max_hits) {
	  max_hits = total_expected_hits;
	  early_index = early;
	  late_index = late;
	}
      }

    last_used_early_point = early_index;

    // Part of the APPROXIMATION. If the optimal late eviction point is the
    // beginning of the virtual region, evict early all the time.
    if (late_index == num_regions)
      return region_start_qpos[early_index];


    // Now we have determined the optimal early and late
    // parameters. Choose the eviction point (a function of the
    // recency of the LRU page in memory), according to the (slightly
    // modified) WFL algorithm.

    QueuePos recency_of_last = lru_stats_sim->block_position(lru_block());

    // Somehow something drifted past our current late eviction point.
    // (Due to change of histogram in time.) Evict it before it goes
    // further.
    if (recency_of_last > region_start_qpos[late_index])
      return recency_of_last;
    
    QueuePos recency_of_touched = lru_stats_sim->block_position(block_num);
    if (recency_of_last == region_start_qpos[late_index] &&
	recency_of_touched > recency_of_last)
      return recency_of_last;
    // else evict early:
    return region_start_qpos[early_index];
  }



  /* touch processes a reference and returns an LruEvent record indicating
     its significance for this (non-lru) memory. */
  virtual LruEvent touch(BlockNumber block_num) {
    // Call the "touch" routine of the superclass (which may invoke the
    // right "evict" routine. 
    LruEvent memory_event = LruQueue::touch(block_num);
    bool fault = (memory_event.queue_position() == 0);
    // figure out where the block would be in a pure LRU ordering
    // and update the pure LRU ordering as a side-effect
    LruEvent lru_event = lru_stats_sim->touch(block_num); 
    
    // Use the results of touching the block in the pure LRU order to
    // determine whether this fault is compulsory and to update our
    // statistics.
    bool compulsory_fault = false;
    QueuePos lru_qpos = lru_event.queue_position();
    if (lru_qpos == 0)
      compulsory_fault = check_and_update_compulsory_faults(block_num);
    if (!compulsory_fault)
      record_lru_event(lru_qpos);
    else {  // what should we do for compulsory faults?
      record_compulsory_fault();
    }
    maybe_decay_stats();
    if (fault && !compulsory_fault)
      misses++;
    return memory_event;
  }

protected:
  // Given a block number that was not in the LRU queue, determine
  // whether or not this block has ever been referenced before.  If it
  // has not, update the count of compulsory faults and insert the
  // block into the set of known blocks.  Return whether or not the
  // page has been referenced before.
  bool check_and_update_compulsory_faults (BlockNumber block) {
    bool compulsory_fault;
    if (knownBlocks.find(block) == knownBlocks.end()) {
      // The block has never been referenced before.
      compulsory_fault = true;
      knownBlocks.insert(block);
      compulsory_faults++;
    } else {
      compulsory_fault = false;
    }
    return compulsory_fault;
  }

protected:

  // An interesting question concerns the interpretation of compulsory
  // faults. Should they affect the policy at all? (e.g., by advancing time or
  // counting as misses) 
  void record_compulsory_fault() {
    time_this_eighth += 10 * time_per_fault;
  }

  /* recording an LRU event.  note that this updates virtual time
     as well as recording the significance of the particular event
     in terms of queue position hits in a pure lru queue */
  void record_lru_event(QueuePos qpos) {
    if (qpos == 0)
      record_far_lru_miss(qpos);
    else if (qpos <= start_qpos)
      record_easy_lru_hit(qpos);
    else 
      record_interesting_lru_hit(qpos);
  }

  /* what should this do?  Should it update virtual time? Currently it
     affects it less than a normal hit in the interesting range */
  void record_far_lru_miss(QueuePos qpos) {
    plain_lru_misses++;
    forall(i)
      hits_in_region_lately[i]++;
    time_this_eighth += far_miss_weight * time_per_fault;
  }

  void record_easy_lru_hit(QueuePos qpos) {
  }  // currently does nothing---should it do anything?

  // record a hit in the interesting range 
  void record_interesting_lru_hit(QueuePos qpos) {
    if (qpos > max_size)
      plain_lru_misses++;
    record_lru_hit(qpos);
  }

  void record_lru_hit(QueuePos qpos) {
    // Note that qpos > region_start_qpos[0] (which is equal to start_qpos),
    // because we check for that in record_lru_event.
    for (int i = latest_region_for_qpos(qpos); i >= 0; i--)
      hits_in_region_lately[i]++;
    // TEMPORARY
    if (qpos > region_start_qpos[last_used_early_point])
      time_this_eighth += time_per_fault;
  }
      
public:

  // Output the number of faults incurred by both plain LRU and
  // this algorithm, as well as the number of compulsory faults.
  void output (ostream& LRUStream,
	       ostream& myStream,
	       ostream& compulsoryStream) {

    // Write out the number of faults incurred by LRU.
    LRUStream << plain_lru_misses << endl;

    // Write out the number of faults incurred by this algorithm
    myStream << misses << endl;

    // Write out the number of compulsory faults.
    compulsoryStream << compulsory_faults << endl;

  }  
};



#ifdef STANDALONE_EELRU
// For testing
Input my_in(&cin);

void usage(char* program_name) {
  cerr << 
    "usage: " << program_name << 
    " <memory size>" << 
    " <lru segment size>" <<
    " <number of recency regions>" <<
    " <multiple of memory tracked>" <<
    " <decay factor>" << 
    " <far miss weight>" << endl;
}
  
void main(int argc, char** argv) {
  if (argc != 7) {
    usage(argv[0]);
    exit(1);
  }
  int queue_size, n_regions, lru_size;
  double *r_fraction, lateness, decayf, missweight;
  (istrstream)(argv[1]) >> queue_size;
  (istrstream)(argv[2]) >> lru_size;
  (istrstream)(argv[3]) >> n_regions;
  (istrstream)(argv[4]) >> lateness;
  (istrstream)(argv[5]) >> decayf;
  (istrstream)(argv[6]) >> missweight;

  double lru_fraction = ((double) lru_size) / queue_size;
  double fraction_per_region = (lateness - lru_fraction) / 
    n_regions;
  r_fraction = new double[n_regions];
  for (int i = 0; i < n_regions; i++)
    r_fraction[i] = i * fraction_per_region + lru_fraction;

  EELRU q(queue_size, n_regions, r_fraction,
	  lateness, decayf, missweight, my_in);
  q.simulate();
  q.output(cout, cout, cout);
}

#endif

