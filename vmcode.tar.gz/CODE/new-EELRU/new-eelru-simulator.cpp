// Practically the same as multiple-point-EELRU-simulator.cc

#include "new-eelru.cpp"
#include <iostream.h>
#include <fstream.h>



// Display the usage of this executable.
void usage (char* executablePath) {

  cerr << "Usage: "
       << executablePath
       << " <trace pathname>"
       << " <LRU result pathname>"
       << " <EELRU result pathname>"
       << " <memory size>" 
       << " <lru segment size>"
       << " <number of recency regions>" 
       << " <multiple of memory tracked>" 
       << " <decay factor>" 
       << " <far miss weight>"
       << endl;

}

  
void main(int argc, char** argv) {
  if (argc != 10) {
    usage(argv[0]);
    exit(1);
  }
  int queue_size, n_regions, lru_size;
  double *r_fraction, lateness, decayf, missweight;
  char* tracePathname = argv[1];
  char* LRUOutputPathname = argv[2];
  char* EELRUOutputPathname = argv[3];
  (istrstream)(argv[4]) >> queue_size;
  (istrstream)(argv[5]) >> lru_size;
  (istrstream)(argv[6]) >> n_regions;
  (istrstream)(argv[7]) >> lateness;
  (istrstream)(argv[8]) >> decayf;
  (istrstream)(argv[9]) >> missweight;

  double lru_fraction = ((double) lru_size) / queue_size;
  double ideal_fraction_per_region = (lateness - lru_fraction) / 
    n_regions;

  // Actually, instead of taking all regions to be the same size, we
  // make sure that a region ends at memory size. This way, we can
  // easily distinguish between behavior that is beyond the memory
  // size and behavior that fits in memory.
  int num_early_regions = (int) ((1.0 - lru_fraction) /
				 ideal_fraction_per_region);
  double fraction_per_early_region = (1.0 - lru_fraction) / num_early_regions;
  double fraction_per_late_region = (lateness - 1.0) /
    (n_regions - num_early_regions);

  r_fraction = new double[n_regions];
  for (int i = 0; i < n_regions; i++)
    if (i <= num_early_regions)
      r_fraction[i] = i * fraction_per_early_region + lru_fraction;
    else
      r_fraction[i] = (i - num_early_regions) * fraction_per_late_region +
	1.0;

  // Open the trace file.
  ifstream traceStream(tracePathname);

  EELRU q(queue_size, n_regions, r_fraction,
	 lateness, decayf, missweight, Input(&traceStream));
  q.simulate();

  // Open the result files.
  ofstream LRUStream(LRUOutputPathname);
  ofstream EELRUStream(EELRUOutputPathname);

  // Output the results.
  cout << "Compulsory faults = ";
  q.output(LRUStream, EELRUStream, cout);
}



