// This file defines a simulator for an eviction policy suitable for modem
// pools (i.e., when we treat a set of modems as a cache for user connections--
// the active connections are in the cache).

// The particular policy presented here follows an "inter-reference
// gap" (IRG) approach: we "evict" (i.e., disconnect) the user who has
// the longest expected idle time, given her most recent
// behavior. More specifically, we keep for each user a list that
// tells us how long the user was idle the last time she was idle for
// at least k time units. This way we can estimate something like
// conditional probabilities: how much longer can we expect the user
// to be idle, given that the user has already been idle for k time
// units? The name of the policy (CIRG) is an acronym for "Conditional
// Inter-Reference Gap"

// Actually, we can keep multiple lists reflecting the user behavior
// the last k times. The number of lists kept is determined by a parameter
// passed to the class constructor.

#include "input.h"
#include "algorithm.h"
#include <strstream.h>
#include <hash_map.h>
#include <list.h>
#include <vector.h>
#include <math.h>

class CIRG : public MODEM_ALGORITHM {
protected:
  typedef list<Time> HistoryList;
  typedef vector<HistoryList> *UserHistories;
  typedef hash_map<UserNumberPointer, UserHistories, hash<UserNumberPointer>, 
    equal_usernum > UserHistoriesListsMap;
  UserHistoriesListsMap user_histories;

  int num_histories;

  // Quantize time at 1 min intervals. All statistics kept are quantized.
  Time quantize(Time t) {
    return rint(t / 60) * 60;
  }

public:
  CIRG(int msize,
       Time thold,
       Time dont_care_thold,
       int n_histories,
       Input input_object) :
    MODEM_ALGORITHM(msize, thold, dont_care_thold, input_object),
    num_histories(n_histories)
    { }

protected:
  //Return the user's current idle time (i.e., assume they'll stay
  //idle in total for twice as long as they already are). This is
  //clearly an arbitrary default (REVIEW)
  virtual Time default_future_idle_time(Time idle_time) {
    return idle_time / 2;
  }

public:

  Time expected_future_idle_time(UserNumberPointer user_num) {
    Time idle_time = current_time - last_activity_time[user_num];
    Time expected_idle_time[num_histories];

    UserHistories &histories = user_histories[user_num];
    if (histories == NULL)
      histories = new vector<HistoryList>(num_histories);

    for (int j = 0; j < num_histories; j++) {
      // find the least element in the (ordered) list that is not smaller than
      // the current idle time. This is the total idle time for the user
      // when he/she was last idle for as long as now.
      HistoryList::iterator i;
      for (i = (*histories)[j].begin(); i != (*histories)[j].end();i++)
	if (quantize(idle_time) <= *i) {
	  expected_idle_time[j] = *i - quantize(idle_time);
	  break;
	}
      if (i == (*histories)[j].end())
	// we are in uncharted territory. The user has never been idle for
	// this long. 
	expected_idle_time[j] = default_future_idle_time(idle_time);
    }

    // The expected idle time is the average over all histories. (REVIEW)
    Time sum = 0;
    for (int i = 0; i < num_histories; i++)
      sum += expected_idle_time[i];
    return sum / num_histories;
    
    /*
      // The expected idle time is the median over all histories.
      sort(&expected_idle_time[0], &expected_idle_time[num_histories - 1]);
      return expected_idle_time[(num_histories-1) / 2];
    */
  }

  // Precondition: the connect of user_num did not cause a compulsory fault
  void update_user_statistics(UserNumberPointer user_num) {
    // First check if the user has explicitly disconnected.
    ActivityTimes::iterator i = last_explicit_disconnect_time.find(user_num);
    if (i == last_explicit_disconnect_time.end() ||
	(*i).second < last_activity_time[user_num]) {
      Time idle_time = quantize(current_time - last_activity_time[user_num]);
      // This is just an optimization (i.e., does not affect the
      // correctness of the simulation): if the current idle time is
      // not greater than the threshold value, there is no point in
      // storing statistics (they'll never be used).
      if (idle_time > threshold)
	do_update(user_num, idle_time, 0);
    }
  }

protected:
  // the "depth" parameter shows which history list we are dealing with.
  // That is, are we updating the data for the last user activity, the
  // second last, third last, etc.
  void do_update(UserNumberPointer user_num, Time idle_time, int depth) {
    UserHistories &histories = user_histories[user_num];
    if (histories == NULL)
      histories = new vector<HistoryList>(num_histories);

    HistoryList::iterator i = (*histories)[depth].begin();
    while (i != (*histories)[depth].end()) {
      if (idle_time >= *i) {
	if (depth != num_histories - 1)
	  do_update(user_num, *i, depth + 1);
	(*histories)[depth].erase(i);
      }
      else
	break;
      i = (*histories)[depth].begin();
    }
    (*histories)[depth].push_front(idle_time);
  }
    
};



#ifdef STANDALONE_CIRG
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 5) {
    cerr << 
      "usage: " << argv[0] << 
      " <number of modems>" << 
      " <threshold for disconnection>" << 
      " <idle time after a \"successful\" disconnection>" << 
      " <number of histories>" << endl;
    exit(1);
  }
  int mem_size;
  Time threshold;
  Time dont_care_threshold;
  int n_histories;
  
  (istrstream)(argv[1]) >> mem_size;
  (istrstream)(argv[2]) >> threshold;
  (istrstream)(argv[3]) >> dont_care_threshold;
  (istrstream)(argv[4]) >> n_histories;
  CIRG q(mem_size, threshold, dont_care_threshold, n_histories, my_in);
  q.simulate();
  q.output(cout, cout, cout);
}

#endif

