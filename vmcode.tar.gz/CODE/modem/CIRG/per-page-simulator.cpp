#include "cirg.cpp"
#include <iostream.h>
#include <fstream.h>



// Display the usage of this executable.
void usage (char* executablePath) {

  cerr << "Usage: "
       << executablePath
       << " <trace pathname>"
       << " <faults result pathname>"
       << " <busy result pathname>"
       << " <compulsory faults result pathname>"
       << " <memory size>"
       << endl;

  exit(-1);

}


void
main (int argc, char** argv) {

  // If the correct number of arguments was not passed, display the
  // usage rules.
  if (argc != 7) {
    usage(argv[0]);
  }

  // Extract the arguments into named variables.
  unsigned int argumentNumber = 1;
  char* tracePathname = argv[argumentNumber];
  argumentNumber++;
  char* LRUOutputPathname = argv[argumentNumber];
  argumentNumber++;
  char* EELRUOutputPathname = argv[argumentNumber];
  argumentNumber++;
  unsigned int memorySize = atoi(argv[argumentNumber]);
  argumentNumber++;
  double earliness = atof(argv[argumentNumber]);
  argumentNumber++;
  double lateness = atof(argv[argumentNumber]);

  // Open the trace file.
  ifstream traceStream(tracePathname);

  // Create the simulator.
  PerPage simulator(memorySize,
		    earliness,
                    lateness,
		    Input(&traceStream));
  
  // Perform the simulation.
  simulator.simulate();

  // Open the result files.
  ofstream LRUStream(LRUOutputPathname);
  ofstream EELRUStream(EELRUOutputPathname);

  // Output the results.
  cout << "Compulsory faults = ";
  simulator.output(LRUStream, EELRUStream, cout);

}
