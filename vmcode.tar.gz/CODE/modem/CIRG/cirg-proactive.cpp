// This file defines a simulator for a proactive disconnections policy.
// This policy, CIRG-proactive, uses exactly the same information as CIRG,
// only evicts *all* users who are expected to stay idle beyond the 
// dont_care_threshold.

// CIRG-proactive follows an "inter-reference gap" (IRG) approach. We
// keep for each user a list that tells us how long the user was idle
// the last time she was idle for at least k time units. This way we
// can estimate something like conditional probabilities: how much
// longer can we expect the user to be idle, given that the user has
// already been idle for k time units? The name of the policy (CIRG)
// is an acronym for "Conditional Inter-Reference Gap"

// Actually, we can keep multiple lists reflecting the user behavior
// the last k times. The number of lists kept is determined by a parameter
// passed to the class constructor.

// IMPORTANT: Note that what we are doing in this class is hijacking the
// functionality of a replacement algorithm to turn it into a proactive
// disconnect algorithm.

#include "input.h"
#include "cirg.cpp"
#include <strstream.h>
#include <hash_map.h>
#include <list.h>
#include <vector.h>
#include <math.h>

class CIRG_PROACTIVE : private CIRG {
public:
  CIRG_PROACTIVE(int msize,
		 Time threshold,
		 Time dont_care_thold,
		 int n_histories,
		 Input input_object) :
    CIRG(msize, threshold, dont_care_thold, n_histories, input_object)
    { }

public:
  // Note that this is NOT a virtual method. We just make sure it is
  // never called from a method in the superclass as part of the
  // control flow of this subclass.
  void update_time(Time new_time) {
    // Before we update the time, let's disconnect all the idle users.
    SetOfUsers::iterator next_user;
    for (SetOfUsers::iterator user = connected_users.begin(), next_user = user;
	 user != connected_users.end();
	 user = next_user) {
      next_user++;
      Time actual_idle = current_time - last_activity_time[*user];
      
      if (actual_idle > threshold) {
	Time expected_future_idle = expected_future_idle_time(*user);
	if (expected_future_idle > dont_care_threshold) {
	  last_auto_disconnect_time[*user] = current_time;
	  connected_users.erase(user);
	}
      }
    }
    // Now do the standard time update.
    MODEM_ALGORITHM::update_time(new_time);
  }
    
  void simulate() {
    do {
      input_obj.get_next_entry();
      if (input_obj.end_of_input())
	break;
      if (input_obj.is_time_entry())
	update_time(input_obj.get_time());
      else if (input_obj.is_disconnect_entry())
	disconnect_user(input_obj.get_user_number());
      else if (input_obj.is_active_entry())
	attempt_connect(input_obj.get_user_number());
    } while (1);
  }

  // This is needed because for now we have declared this class
  // to inherit *privately* from CIRG. (REVIEW)
  void output (ostream& missesStream,
	       ostream& busyStream,
	       ostream& minor_faultStream) {
    CIRG::output(missesStream, busyStream, minor_faultStream);
  }
};



#ifdef STANDALONE_CIRG_PROACTIVE
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 5) {
    cerr << 
      "usage: " << argv[0] << 
      " <number of modems>" << 
      " <threshold for disconnection>" << 
      " <idle time after a \"successful\" disconnection>" << 
      " <number of histories>" << endl;
    exit(1);
  }
  int mem_size;
  Time threshold;
  Time dont_care_threshold;
  int n_histories;
  
  (istrstream)(argv[1]) >> mem_size;
  (istrstream)(argv[2]) >> threshold;
  (istrstream)(argv[3]) >> dont_care_threshold;
  (istrstream)(argv[4]) >> n_histories;
  CIRG_PROACTIVE q(mem_size, threshold, dont_care_threshold, n_histories, 
		   my_in);
  q.simulate();
  q.output(cout, cout, cout);
}

#endif

