// This file defines a general skeleton for simulators of eviction
// policies suitable for modem pools (i.e., when we treat a set of
// modems as a cache for user connections-- the active connections are
// in the cache). The skeleton is not perfectly general (currently
// limited to a subclass of stack algorithms that are based on a
// single priority ordering for all pages) but it is sufficient for
// implementing simple versions of common eviction algorithms (e.g.,
// LRU).

// All "modem" eviction policies that we study have some common characteristics
// that differentiate them from standard eviction policies (e.g., for policies
// for virtual memory). First, the new user trying to connect at any point 
// may NOT connect (unlike VM where the most recently referenced page has to
// be brought in RAM) if all existing users are "active". In that case, we say
// that the new user gets a "busy" signal. Whether users are "active" or not
// is determined by the value of a threshold: if a user is idle for less time
// than this threshold, then (and only then) the user is active.

#ifndef ALGORITHM_H

#define ALGORITHM_H

#include "input.h"
#include <stdlib.h>
#include <hash_map.h>

class MODEM_ALGORITHM {
protected:
  Time current_time;
  Time threshold;  
  // The threshold determines how long a user needs to be idle before
  // she is a candidate for disconnection.
  Time dont_care_threshold;
  // The dont_care_threshold determines how long a user needs to be idle
  // after her disconnection, for the system to assume that the disconnection
  // was a good idea (i.e., it did not bother the user).

  Input input_obj;
  int max_size;

  // basic performance stats
  int misses;            // misses (faults) this simulated buffer suffers
  double miss_severity; 
  // miss severity decreases linearly the closer the miss is to the
  // dont_care_threshold. Miss severity is just another metric used in
  // the simulations.
  int compulsory_faults; 
  // Faults caused by a user connecting for the first time or re-connecting
  // after an explicit disconnect.
  int total_users_seen;
  int soft_faults;
  // How long did all users together stay connected? Meaningful for
  // proactive policies only. Maybe we should move from here. (REVIEW)
  Time total_connect_time;
  // Faults considered acceptable because the user did not reconnect
  // within dont_care_threshold units of her disconnection.
  int busy;              // times a user has tried to connect and could not
  
  // A set of the users that are known to the simulator.
  SetOfUsers known_users;
  // A set of users that would have been connected if we had an infinite
  // number of modems (i.e., the users that have connected until this
  // point and have not explicitly disconnected).
  SetOfUsers potentially_connected_users;
  SetOfUsers connected_users;
  typedef hash_map<UserNumberPointer, Time, hash<UserNumberPointer>,
    equal_usernum > ActivityTimes;
  // When was the user last active?
  ActivityTimes last_activity_time;
  // last_auto_disconnect_time refers to *system* disconnections --
  // *not* explicit disconnections!
  ActivityTimes last_auto_disconnect_time;
  // When did the user last disconnect explicitly?
  ActivityTimes last_explicit_disconnect_time;

public:
  MODEM_ALGORITHM(int msize,
		  Time thold,
		  Time dont_care_thold,
		  Input input_object) :
    current_time(0.0), 
    // not valid, but will be initialized correctly upon reading the
    // first timestamp from the trace
    threshold(thold),
    dont_care_threshold(dont_care_thold),
    input_obj(input_object),
    max_size(msize),
    misses(0),
    miss_severity(0.0),
    compulsory_faults(0),
    total_users_seen(0),
    soft_faults(0),
    total_connect_time(0.0),
    busy(0)
    { }

public:
  // This method also works for already connected users (updates their
  // activity data).
  void attempt_connect(UserNumberPointer user_num) {
    bool new_user = known_users.find(user_num) == known_users.end();
    bool connected = true;

    if (connected_users.find(user_num) == connected_users.end()) {
      connected = connect(user_num);

      // The following checks whether the user is reconnected after she
      // explicitly disconnected.
      bool unavoidable_fault = !new_user &&
	potentially_connected_users.find(user_num) == 
	potentially_connected_users.end();
      // The following is important! A fault is "soft" if the user was
      // idle for more than dont_care_threshold time units after her
      // latest disconnection.
      bool soft_fault = 
	last_auto_disconnect_time[user_num] + dont_care_threshold <= 
	current_time;

      // Update statistics (NOT activity data, just statistics!)
      // A user becomes known, or potentially connected, regardless of
      // whether they connected. Hence, these sets are "simulator"
      // data and should not be used for making "policy" decisions.
      if (new_user || unavoidable_fault) {
	if (new_user) {
	  total_users_seen++;
	  known_users.insert(user_num);
	}
	compulsory_faults++;
	potentially_connected_users.insert(user_num);
      }
      // Note that compulsory faults don't count as busy even if the
      // user can't connect (REVIEW)
      else if (!connected)
	busy++;
      else if (soft_fault)
	soft_faults++;
      else {
	misses++;
	miss_severity += 1.0 - 
	  ((double) current_time - last_auto_disconnect_time[user_num]) /  
	  dont_care_threshold;
      }
    }

    // Update the activity data for the user who successfully connected or
    // was already connected.
    if (connected) {
      if (!new_user)
	update_user_statistics(user_num);
      last_activity_time[user_num] = current_time;
    }
  }

protected:
  // user_num is the number of the user trying to connect. Return true if the
  // connection was successful, false if the user got a busy signal.
  bool connect(UserNumberPointer user_num) {
    if (connected_users.size() == max_size)
      // all modems occupied. Find a user to replace (if possible)
      return find_user_to_disconnect(user_num);
    else { // there are free modems
      connected_users.insert(user_num);
      return true;
    }
  }


  bool find_user_to_disconnect(UserNumberPointer user_num) {
    Time max_expected_future_idle_time = 0.0;
    SetOfUsers::iterator eviction_candidate_user = connected_users.end();
    
    for (SetOfUsers::iterator user = connected_users.begin();
	 user != connected_users.end();
	 user++) {
      Time actual_idle = current_time - last_activity_time[*user];

      if (actual_idle > threshold) {
	Time expected_idle = expected_future_idle_time(*user);
	if (expected_idle > max_expected_future_idle_time) {
	  eviction_candidate_user = user;
	  max_expected_future_idle_time = expected_idle;
	}
      }
    }
    if (eviction_candidate_user != connected_users.end()) {
      last_auto_disconnect_time[*eviction_candidate_user] = current_time;
      // Disconnect the old user ...
      connected_users.erase(eviction_candidate_user);
      // ... connnect the new one.
      connected_users.insert(user_num);
      return true;
      // connect succeeded
    }
    else 
      return false;
  }
  

  void disconnect_user(UserNumberPointer user_num) {
    last_explicit_disconnect_time[user_num] = current_time;
    potentially_connected_users.erase(user_num);
    SetOfUsers::iterator i = connected_users.find(user_num);
    if (i != connected_users.end())
      connected_users.erase(i);
  }


  // This is the method that concrete classes implementing eviction
  // algorithms need to override. It provides a general way to order
  // elements in memory so that the one maximizing a metric is the one
  // selected for eviction.
  // Is this general enough to implement all stack algorithms?
  // Probably only a subset.  Of course, the implementation won't be
  // the most efficient possible for each algorithm.
  virtual Time expected_future_idle_time(UserNumberPointer user_num) = 0;


  // This is another pure virtual method that determines how
  // statistics are updated when a user attempts to connect (i.e., a
  // "page" is "touched" in VM terms).

  // Precondition: the connect of user_num did not cause a compulsory fault
  virtual void update_user_statistics(UserNumberPointer user_num) = 0;

  void update_time(Time new_time) {
    if (current_time != 0.0)
      total_connect_time += connected_users.size() * (new_time - current_time);
    current_time = new_time;
  }

public:

  // "simulate" reads from input
  void simulate() {
    do {
      input_obj.get_next_entry();
      if (input_obj.end_of_input())
	break;
      if (input_obj.is_time_entry())
	update_time(input_obj.get_time());
      else if (input_obj.is_disconnect_entry())
	disconnect_user(input_obj.get_user_number());
      else if (input_obj.is_active_entry())
	attempt_connect(input_obj.get_user_number());
    } while (1);
  }

  void output (ostream& missesStream,
	       ostream& busyStream,
	       ostream& minor_faultStream) {

    // Write out the number of faults incurred.
    missesStream << misses << endl;

    // Write out the number of busy signals encountered.
    busyStream << busy << endl;

    // Write out the number of compulsory faults and soft faults.
    minor_faultStream << compulsory_faults << endl;
    minor_faultStream << soft_faults << endl;
    minor_faultStream << total_users_seen << endl;

    // Write out the value of the miss severity metric.
    missesStream << miss_severity << endl;

    // Write out the total connection time (over all users).
    missesStream << total_connect_time << endl;
  }  
};

#endif


