// This file defines a simulator for an eviction policy suitable for modem
// pools (i.e., when we treat a set of modems as a cache for user connections--
// the active connections are in the cache).

// The particular policy presented here is random for all inactive
// users. That is, a random inactive user is disconnected.

#include "input.h"
#include "algorithm.h"
#include <strstream.h>

class RANDOM : public MODEM_ALGORITHM {

public:
  RANDOM(int msize,
	 Time thold,
	 Time dont_care_thold,
	 Input input_object) :
    MODEM_ALGORITHM(msize, thold, dont_care_thold, input_object) {}

public:
  Time expected_future_idle_time(UserNumberPointer user_num) {
    // This is what makes the algorithm RANDOM: the expected idle time in the
    // future is the same for all pages. An arbitrary page is selected
    // (either the lexicographically last, or the last in a hash table,
    // depending on the data structure used in the superclass).
    return 1000;
  }

  // Precondition: the connect of user_num did not cause a compulsory fault
  virtual void update_user_statistics(UserNumberPointer user_num) { 
    /* do nothing */
  }

};




#ifdef STANDALONE_RANDOM
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 4) {
    cerr << 
      "usage: " << argv[0] << 
      " <number of modems>" << 
      " <threshold for disconnection>" << 
      " <idle time after a \"successful\" disconnection>" << endl;
    exit(1);
  }
  int mem_size;
  Time threshold;
  Time dont_care_threshold;
  
  (istrstream)(argv[1]) >> mem_size;
  (istrstream)(argv[2]) >> threshold;
  (istrstream)(argv[3]) >> dont_care_threshold;
  RANDOM q(mem_size, threshold, dont_care_threshold, my_in);
  q.simulate();
  q.output(cout, cout, cout);
}

#endif

