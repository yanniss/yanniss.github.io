// This file provides the baseline calculations for all simulations.
// It does two different simulations. For busy signals it simulates a policy
// that performs no evictions. For faults of all kinds, it simulates a
// policy that evicts every user after a fixed period of inactivity.

#include "input.h"
#include "algorithm.h"
#include <strstream.h>

#define INFINITE_IDLE_TIME 10000000

class BASELINE_BUSY : public MODEM_ALGORITHM {
  friend class BASELINE;
public:
  BASELINE_BUSY(int msize,
		Input input_object) :
    MODEM_ALGORITHM(msize, INFINITE_IDLE_TIME, 0, input_object) {}

public:
  Time expected_future_idle_time(UserNumberPointer user_num) {
    return 1000;
  }

  // Precondition: the connect of user_num did not cause a compulsory fault
  virtual void update_user_statistics(UserNumberPointer user_num) { 
    /* do nothing */
  }
};


class BASELINE_FAULTS : public MODEM_ALGORITHM {
  friend class BASELINE;
public:
  BASELINE_FAULTS(int msize,        
		  Time thold,
		  Time dont_care_thold,
		  Input input_object) :
    MODEM_ALGORITHM(msize, thold, dont_care_thold, input_object) {}

public:
  Time expected_future_idle_time(UserNumberPointer user_num) {
    return 1000;
  }
  
  // Precondition: the connect of user_num did not cause a compulsory fault
  virtual void update_user_statistics(UserNumberPointer user_num) { 
    /* do nothing */
  }


  // Note that this is NOT a virtual method. We just make sure it is
  // never called from a method in the superclass as part of the
  // control flow of this subclass.
  void update_time(Time new_time) {
    // Before we update the time, let's disconnect all the idle users.
    SetOfUsers::iterator next_user;
    for (SetOfUsers::iterator user = connected_users.begin(), next_user = user;
	 user != connected_users.end();
	 user = next_user) {
      next_user++;
      Time actual_idle = current_time - last_activity_time[*user];

      if (actual_idle > threshold) {
	last_auto_disconnect_time[*user] = current_time;
	connected_users.erase(user);
      }
      /* The following prints out the connected users. Useful when I need
	 to detect the workaholics, etc, but otherwise irrelevant.
	else
	      cout << *user << endl;
      */
    }

    // Now do the standard time update.
    MODEM_ALGORITHM::update_time(new_time);

    /*
      if (current_time != 0.0)
      total_connect_time += connected_users.size() * (new_time - current_time);
      // Now update time
      current_time = new_time;
    */
  }

};  



// This is the combined baseline simulator
class BASELINE {
  BASELINE_FAULTS faults_simulator;
  BASELINE_BUSY busy_simulator;

  Input input_obj;

public:
  BASELINE(int msize,        
	   Time thold,
	   Time dont_care_thold,
	   Input input_object) :
    faults_simulator(msize, thold, dont_care_thold, input_object) ,
    busy_simulator(msize, input_object),
    input_obj(input_object)
    {}

  
  // "simulate" reads from input
  void simulate() {
    do {
      input_obj.get_next_entry();
      if (input_obj.end_of_input())
	break;
      if (input_obj.is_time_entry()) {
	faults_simulator.update_time(input_obj.get_time());
	busy_simulator.update_time(input_obj.get_time());
      }
      else if (input_obj.is_disconnect_entry()) {
	faults_simulator.disconnect_user(input_obj.get_user_number());
	busy_simulator.disconnect_user(input_obj.get_user_number());
      }
      else if (input_obj.is_active_entry()) {
	faults_simulator.attempt_connect(input_obj.get_user_number());
	busy_simulator.attempt_connect(input_obj.get_user_number());
      }
    } while (1);
  }


  void output (ostream& missesStream,
	       ostream& busyStream,
	       ostream& minor_faultStream) {
    // Write out the number of faults incurred.
    missesStream << faults_simulator.misses << endl;

    // Write out the number of busy signals encountered.
    busyStream << busy_simulator.busy << endl;

    // Write out the number of compulsory faults and soft faults.
    minor_faultStream << faults_simulator.compulsory_faults << endl;
    minor_faultStream << faults_simulator.soft_faults << endl;
    minor_faultStream << faults_simulator.total_users_seen << endl;

    // Write out the value of the miss severity metric.
    missesStream << faults_simulator.miss_severity << endl;

    // Write out the total connection time (over all users).
    missesStream << faults_simulator.total_connect_time << endl;
  }  

};





#ifdef STANDALONE_BASELINE
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 4) {
    cerr << 
      "usage: " << argv[0] << 
      " <number of modems>" << 
      " <threshold for disconnection>" << 
      " <idle time after a \"successful\" disconnection>" << endl;
    exit(1);
  }
  int mem_size;
  Time threshold;
  Time dont_care_threshold;
  
  (istrstream)(argv[1]) >> mem_size;
  (istrstream)(argv[2]) >> threshold;
  (istrstream)(argv[3]) >> dont_care_threshold;
  BASELINE q(mem_size, threshold, dont_care_threshold, my_in);

  q.simulate();
  q.output(cout, cout, cout);
}

#endif

