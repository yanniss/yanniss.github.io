#ifndef GENERAL_H
#define GENERAL_H

#include <hash_set.h>
#include <iostream.h>

// Users are represented just by strings, but there is no reason for
// clients to know this.
typedef char* UserNumberPointer;


struct equal_usernum : public binary_function<UserNumberPointer, 
		       UserNumberPointer, bool> {
  bool operator()(const UserNumberPointer& x, const UserNumberPointer& y) const
    {
      return !::strcmp(x, y);
    }
};

/* By using pointers and comparing them appropriately, we avoid copying
   strings in multiple data structures. */

typedef hash_set <UserNumberPointer, hash<UserNumberPointer>, equal_usernum> 
  SetOfUsers;
typedef double Time;

/* This function maintains a set of all the users it has produced.
   When a username is examined, the function looks it up in the set.
   If it has been used before, it returns the existing UserNumber
   object. Otherwise, it creates a new one. */
UserNumberPointer get_new_user(char* username) {
  static SetOfUsers past_users;
  SetOfUsers::iterator i = past_users.find(username);
  if (i == past_users.end()) {
    UserNumberPointer temp_user = new char[strlen(username) + 1];
    strcpy(temp_user, username);
    past_users.insert(temp_user);
    return temp_user;
  }
  return *i;
}


#endif GENERAL_H
