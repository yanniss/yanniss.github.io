#ifndef INPUT_H
#define INPUT_H

#define MAXLINE 10000

#include "general.h"
#include <iostream.h>
#include <strstream.h>

// "Input" hides the details of reading the user numbers from input. If we end
// up having more than one methods of input they could all be expressed as
// subclasses of the Input class.
class Input {
  char str[MAXLINE+1];
  istrstream *temp;
  UserNumberPointer current_number;
  Time current_time;

  enum State {
    time_entry, 
    disconnect_entry, 
    active_entry, 
    other_entry,
    last_entry 
  } current_state;

  istream* in_stream;
public:
  Input (istream* input_stream) {
    in_stream = input_stream;
    current_state = other_entry;
  }

  bool end_of_input() { return current_state == last_entry; }
  
  void get_next_entry() {
    in_stream->getline(str, MAXLINE);
    if (!in_stream->good())
      current_state = last_entry;
    else if (str[0] != '+' && str[1] != '+') {
      // If it doesn't start with "++", it's a regular user-id entry.
      char username[11];
      istrstream(str) >> username;
      current_number = get_new_user(username);
    }
    else {
      char first[MAXLINE+1];
      istrstream temp_stream(str);
      temp_stream >> first;
      if (!strcmp(first, "++TIME:")) {
	temp_stream >> current_time;
	current_state = time_entry;
      }
      else if (!strcmp(first, "++DISCONNECTED:")) {
	current_state = disconnect_entry;
	get_next_entry();
	return;
      }
      else if (!strcmp(first, "++ACTIVE:")) {
	current_state = active_entry;
	get_next_entry();
	return;
      }
      else  // Unknown directives are just ignored.
	current_state = other_entry;
    }
  }

  bool is_time_entry() {
    return current_state == time_entry;
  }

  bool is_active_entry() {
    return current_state == active_entry;
  }

  bool is_disconnect_entry() {
    return current_state == disconnect_entry;
  }

  Time get_time() {
    return current_time;
  }

  UserNumberPointer get_user_number() {
    return current_number;
  }
};

#endif

