// HIST is not really a modem algorithm--it is meant for getting a
// histogram of idle times. We are just hijacking the generic
// functionality of a modem algorithm. A quick-and-dirty solution!

#include "input.h"
#include "algorithm.h"
#include <map.h>
#include <math.h>

// More modems than we'll ever need (so no replacing takes place).
// Nevertheless, this shouldn't matter (the histogram computation
// should be the same regardless of repacement. (REVIEW)
#define TOO_MANY_MODEMS 10000

class HIST : public MODEM_ALGORITHM {
  map <int, int> histogram;
  int round_factor;
  int far_end;

public:
  HIST(int rounding, int f_end, Input input_object) :
    round_factor(rounding), far_end(f_end),
    MODEM_ALGORITHM(TOO_MANY_MODEMS, 0, 0, input_object) {}

public:
  Time expected_future_idle_time(UserNumberPointer user_num) {
    return 0;
  }

  // Precondition: the connect of user_num did not cause a compulsory fault
  virtual void update_user_statistics(UserNumberPointer user_num) { 
    // First check if the user has not explicitly disconnected.
    ActivityTimes::iterator i = last_explicit_disconnect_time.find(user_num);
    if (i == last_explicit_disconnect_time.end() ||
	(*i).second < last_activity_time[user_num]) {
      Time idle_time = current_time - last_activity_time[user_num];
      int idle_in_mins = (int) (rint(idle_time / round_factor) *
				round_factor / 60.0);
      // Clip it at 4 hrs.
      if (idle_in_mins <= far_end / 60)
	histogram[idle_in_mins]++;
    }
  }

  void print_histogram() {
    for (map<int, int>::iterator i = histogram.begin(); 
	 i != histogram.end();
	 i++) 
      cout << (*i).first << " " << (*i).second << endl;
  }
};




#ifdef STANDALONE_HIST
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 3) {
    cerr << 
      "usage: " << argv[0] << 
      " <quantum in secs>" << 
      " <far end in secs>" << 
      endl;
    exit(1);
  }
  int quantum;
  int far_end;
  
  (istrstream)(argv[1]) >> quantum;
  (istrstream)(argv[2]) >> far_end;

  HIST q(quantum, far_end, my_in);
  q.simulate();
  q.print_histogram();
}

#endif

