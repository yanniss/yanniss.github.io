// Practically the same as multiple-point-EELRU-simulator.cc

#include "lruadaptive2.cpp"
#include <iostream.h>
#include <fstream.h>



// Display the usage of this executable.
void usage (char* executablePath) {

  cerr << "Usage: "
       << executablePath
       << " <trace pathname>"
       << " <LRU result pathname>"
       << " <EELRU result pathname>"
       << " <memory size>"
       << " <earliness values (" << NUM_EARLY_POINTS << ")>"
       << " <eviction probabilities (" << NUM_EARLY_POINTS << ")>"
       << " <decay factor>"
       << " <far miss weight>"
       << endl;

  exit(-1);

}


void
main (int argc, char** argv) {

  // If the correct number of arguments was not passed, display the
  // usage rules.
  if (argc != 7 + (2 * NUM_EARLY_POINTS)) {
    usage(argv[0]);
  }

  // Extract the arguments into named variables.
  unsigned int argumentNumber = 1;
  char* tracePathname = argv[argumentNumber];
  argumentNumber++;
  char* LRUOutputPathname = argv[argumentNumber];
  argumentNumber++;
  char* EELRUOutputPathname = argv[argumentNumber];
  argumentNumber++;
  unsigned int memorySize = atoi(argv[argumentNumber]);
  double evictionEarliness[NUM_EARLY_POINTS];
  forall(i) {
    argumentNumber++;
    evictionEarliness[i] = atof(argv[argumentNumber]);
  }
  double earlyEvictionProbability[NUM_EARLY_POINTS];
  forall(i) {
    argumentNumber++;
    earlyEvictionProbability[i] = atof(argv[argumentNumber]);
  }
  argumentNumber++;
  double decayFactor = atof(argv[argumentNumber]);
  argumentNumber++;
  double farMissWeight = atof(argv[argumentNumber]);

  // Open the trace file.
  ifstream traceStream(tracePathname);

  // Create the simulator.
  RlyMultiple2 simulator(memorySize,
			 evictionEarliness,
			 earlyEvictionProbability,
			 decayFactor,
			 farMissWeight,
			 Input(&traceStream));

  // Perform the simulation.
  simulator.simulate();

  // Open the result files.
  ofstream LRUStream(LRUOutputPathname);
  ofstream EELRUStream(EELRUOutputPathname);

  // Output the results.
  cout << "Compulsory faults = ";
  simulator.output(LRUStream, EELRUStream, cout);

}
