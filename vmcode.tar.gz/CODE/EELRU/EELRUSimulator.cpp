// main.cc
// Scott F. Kaplan -- sfkaplan@cs.utexas.edu
// April 1998

// Use the lruearly (and, indirectly lruobj) modules which contain the
// capablility to simulate an LRU queue and an probabilistic LRU
// early-eviction queue.  Read in a trace and create an STL list of
// the references in that trace.  Accept a range of physical memory
// sizes, early eviction positions, early eviction probabilities,
// decay factors, and miss weights.  Simulate over those ranges and
// record the results.



#include "lruearly.cpp"
#include <iostream.h>
#include <fstream.h>



// Display the usage of this executable.
void usage (char* executablePath) {

  cerr << "Usage: "
       << executablePath
       << " <trace pathname>"
       << " <LRU output pathname>"
       << " <EE-LRU output pathname>"
       << " <memory size>"
       << " <eviction earliness>"
       << " <early eviction probability>"
       << " <decay factor>"
       << " <far-miss weight>"
       << endl;

  exit(-1);

}


void
main (int argc, char** argv) {

  // If the correct number of arguments was not passed, display the
  // usage rules.
  if (argc != 9) {
    usage(argv[0]);
  }

  // Extract the arguments into named variables.
  char* tracePathname = argv[1];
  char* LRUOutputPathname = argv[2];
  char* EELRUOutputPathname = argv[3];
  unsigned int memorySize = atoi(argv[4]);
  double evictionEarliness = atof(argv[5]);
  double earlyEvictionProbability = atof(argv[6]);
  double decayFactor = atof(argv[7]);
  double farMissWeight = atof(argv[8]);

  // Open the trace file.
  ifstream traceStream(tracePathname);

  // Create the simulator.
  RlySim simulator(memorySize,
		   evictionEarliness,
		   earlyEvictionProbability,
		   decayFactor,
		   farMissWeight,
		   Input(&traceStream));

  // Perform the simulation.
  simulator.simulate();

  // Open the result files.
  ofstream LRUStream(LRUOutputPathname);
  ofstream EELRUStream(EELRUOutputPathname);

  // Output the results.
  cout << "Compulsory faults = ";
  simulator.output(LRUStream, EELRUStream, cout);

}
