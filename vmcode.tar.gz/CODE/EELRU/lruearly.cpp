// lruearly.cpp --- a simulator for a totalitarian variant of LRU in
//                  which pages are evicted early if it looks worthwhile
//                  to do so, so that other pages can stay in longer

// An lru-early simulator (i.e., an instance of RlySim) simulates a 
// given size of memory and may evict early from a particular lru 
// position.
// 
// RlySim inherits from LruQueue, even though it doesn't behave
// quite like an LRU queue.  It's mostly LRU with early eviction.
//
// It also maintains a "history" LRU queue which it uses to tell how often
// pages have been touched at different LRU queue positions.  This is
// different from the queue used to actually simulate what pages are
// in memory.

#include <strstream.h>
#include <math.h>
#include <set.h>
#include <stdlib.h>
#include "lruobj.h"

class RlySim : public LruQueue {
  // Definition: replacement interval (r.i.): the time during which
  // a number of faults equal to the cache (memory) size occur
  // Definition: virtual time: time measured in "r.i."s
  double earliness;         // double fraction of mem sz to evict early from
  double early_probability; /* double percentage of evictions to do early when
			      evicting early */
  double stats_decay_factor;/* double decay factor to multiply stats by per 
			      (approx) replacement interval (lower factor
			      decays FASTER) */
  double far_miss_weight;   /* double fraction of a miss that a far miss counts
			      as for advancing time */
  // parameters computed from input parameters
  // stats are decayed about once every eighth of a replacement interval
  QueuePos early_qpos;     // queue position to evict early from
  QueuePos late_qpos;      // corresponding late queue position
  double time_per_fault;    /* virtual time per fault (fraction of replacement
			      interval */
  double decay_per_eighth;  /* decay factor (double between 0 and 1) to multiply
			      stats by per eighth of r.i. */
  
  // basic performance stats
  int misses;              // misses this simulated memory suffers
  int early_evicts;
  int normal_evicts;
  int compulsory_faults; // Faults caused by referencing a page for the
			// first time.
  int plain_lru_misses; // misses plain lru would suffer, just for comparison
  
  // stats maintained for adaptivity
  double time_before_this_eighth; /* virtual time in (approx)
				     "replacement intervals", not
				     including time so far this 1/8
				     replacement interval. */
  // These are the stats that get decayed !!!
  double time_this_eighth;        // virtual time since last decay
  double early_hits_lately;
  double late_hits_lately;
  LruQueue* lru_stats_sim;  /* lru queue used for determining pure lru queue 
			      positions for adaptivity stats, and for 
			      comparison */
  // A set of the blocks that are known to the simulator, used to
  // determine whether or not a fault is compulsory.
  set<BlockNumber, less<BlockNumber> >* knownBlocks;

public:
  RlySim(int msize,
	 double eness,
	 double eprob,
	 double decayf,
	 double missweight,
	 Input input_object) :
    LruQueue(msize, input_object), 
    earliness(eness),
    early_probability(eprob),
    stats_decay_factor(decayf),
    far_miss_weight(missweight),
    misses(0),
    early_evicts(0),
    normal_evicts(0), 
    compulsory_faults(0),
    plain_lru_misses(0),
    time_before_this_eighth(0.0),
    time_this_eighth(0.0),
    early_hits_lately(0.0),
    late_hits_lately(0.0)
  {
      QueuePos num_qpos_early = (QueuePos) (max_size * earliness);
      double prob_keep = 1.0 - early_probability;
      QueuePos eff_qpos_range = (QueuePos) (num_qpos_early / prob_keep);

      early_qpos = max_size - num_qpos_early;
      late_qpos = early_qpos + eff_qpos_range;

      time_per_fault = 1.0 / max_size;
      lru_stats_sim = new LruQueue(late_qpos);
      knownBlocks = new set<BlockNumber, less<BlockNumber> >();
      decay_per_eighth = eighth_root(stats_decay_factor);
  }

private:
  double eighth_root(double number) { return sqrt(sqrt(sqrt(number))); }
  
  void maybe_decay_stats() {
    while (time_this_eighth > 0.125) // more than 1/8 repl. interval?
      decay_stats();
    /* do it again in case there's more than 1/8 repl. interval left
       since after decaying once.  This should only happen for very
       small queue sizes (around 8 or less), where a single fault
       can advance time by more than 1/8 of a replacement interval. */
  }

  void decay_stats() {
    // add 1/8 replacement interval to time before this eighth
    time_before_this_eighth += 0.125;
    // subtract 1/8 replacement interval from time for current eighth
    // (we're really starting a new eighth, but keeping the extra
    // left over from the previous one)
    time_this_eighth -= 0.125;
    
    // decay the counts of early and late faults by the factor
    // appropriate to an eighth of a replacement interval
    early_hits_lately *= decay_per_eighth;
    late_hits_lately *= decay_per_eighth;
  }

  
  BlockNumber evict_lru_block() {
    BlockNumber block_num = LruQueue::evict_lru_block();
    // call superclass version
    normal_evicts++;
    return block_num;
  }

  BlockNumber evict_nth_mru_block(QueuePos mru_pos) {
    BlockNumber block_num = LruQueue::evict_nth_mru_block(mru_pos);
    // call superclass version
    //    cout << "EVICTING EARLY" << endl;
    early_evicts++;
    return block_num;
  }

  BlockNumber evict(BlockNumber block_num) {
    if (evict_early_this_time())
      return evict_nth_mru_block(early_qpos);
    else 
      return evict_lru_block();
  }

  bool evict_early_this_time() {
    /* Late hits don't count as much as early ones, because they're harder to 
       get---things will only be hit in the late part of the queue if they're 
       NOT in the fraction of pages reaching the early eviction point that are 
       evicted early. MAKE SURE WE GET THIS FORMULA RIGHT.  THINK ABOUT EFFECT 
       OF EVICTING AGGRESSIVELY & HOW THAT'S MOSTLY OKAY IF LOOPS REPEAT
       ENOUGH TIMES. */
    double gettable_late_hits = (late_hits_lately + early_hits_lately) * 
      (1.0 - early_probability);
    // How many of the late hits would we most likely get?
    if (gettable_late_hits > early_hits_lately)
      return (rand() % 100 < 100*early_probability);
    return false;
  }

public:
  /* touch processes a reference and returns an LruEvent record indicating
     its significance for this (non-lru) memory. */
  LruEvent touch(BlockNumber block_num) {
    // figure out where the block would be in a pure LRU ordering
    // and update the pure LRU ordering as a side-effect
    LruEvent lru_event = lru_stats_sim->touch(block_num);

    // Use the results of touching the block in the pure LRU order to
    // determine whether this fault is compulsory and to update our
    // statistics.
    bool compulsoryFault = false;
    QueuePos lru_qpos = lru_event.queue_position();
    if (lru_qpos == 0) {
      compulsoryFault = checkAndUpdateCompulsoryFaults(block_num);
    }
    if (!compulsoryFault) {
      record_lru_event(lru_qpos);
    }
    maybe_decay_stats();

    // Update the pages held by the early-eviction LRU memory.
    lru_event = LruQueue::touch(block_num); // reusing var "lru_event"
    {
      QueuePos qpos = lru_event.queue_position();
      if (qpos == 0 && !compulsoryFault)
	misses++;
      return lru_event;
    }
  }


private:
  // Given a block number that was not in the LRU queue, determine
  // whether or not this block has ever been referenced before.  If it
  // has not, update the count of compulsory faults and insert the
  // block into the set of known blocks.  Return whether or not the
  // page has been referenced before.
  bool checkAndUpdateCompulsoryFaults (BlockNumber block) {

    bool compulsoryFault;
    if (knownBlocks->find(block) == knownBlocks->end()) {
      // The block has never been referenced before.
      compulsoryFault = true;
      knownBlocks->insert(block);
      compulsory_faults++;
    } else {
      compulsoryFault = false;
    }
    return compulsoryFault;

  }

private:
  /* recording an LRU event.  note that this updates virtual time
     as well as recording the significance of the particular event
     in terms of queue position hits in a pure lru queue */
  void record_lru_event(QueuePos qpos) {
    if (qpos == 0) {
      plain_lru_misses++;
      record_far_lru_miss(qpos);
    }
    else if (qpos <= early_qpos)
      record_easy_lru_hit(qpos);
    else record_interesting_lru_hit(qpos);
  }

  /* what should this do?  Should it update virtual time?  note that
     when we have a lot of far misses, it may decrease the reliability
     of our heuristic, because reference patterns will slide up the
     LRU queue (e.g., "blowing smoke" or "wheatfield in wind" pattern)
     Maybe eventually we should try a heuristic that guesses that the
     current patterns will move down the queue when there are a lot
     of far misses... i.e., use statistics from further up the queue.
     Or just back off to LRU?

     It's arguable that this shouldn't increment time at all (because
     it's "out of range", timescale-relativity wise.)  It's also arguable
     that it should have some special effect because it may indirectly
     affect the validity of the normal heuristic. */
  void record_far_lru_miss(QueuePos qpos) {
    time_this_eighth += far_miss_weight * time_per_fault;
  }

  void record_easy_lru_hit(QueuePos qpos) {
  }  // currently does nothing---should it do anything?

  // record a hit in the interesting range as either early (favoring LRU)
  //or late (favoring early eviction)
  void record_interesting_lru_hit(QueuePos qpos) {
    if (qpos > max_size) {
      plain_lru_misses++;
      record_late_hit(qpos);
    } 
    else record_early_hit(qpos);
  }

  void record_late_hit(QueuePos qpos) {
    late_hits_lately++;
    time_this_eighth += time_per_fault;
  }
      
  void record_early_hit(QueuePos qpos) {
    early_hits_lately++;
    time_this_eighth += time_per_fault;
  }

public:
  void disp() {
    cout << "RLY SIMULATOR STATE:" << endl;
    
    cout << "max_size: " << max_size << "   size: " << size << endl;
    cout << "early_qpos: " << early_qpos << "   late_qpos: " << late_qpos 
	 << endl;

    cout << "plain_lru_misses: " << plain_lru_misses << "    misses: " << misses
	 << endl;

    cout << "compulsory faults: " << compulsory_faults << endl;
    
    cout << "time before this eighth: " << time_before_this_eighth <<
      "   time this eighth: " << time_this_eighth << endl;

    cout << "early_hits_lately: " << early_hits_lately << 
      "   late_hits_lately: " << late_hits_lately << endl;

    cout << "normal_evicts: " << normal_evicts << "   early_evicts: "
	 << early_evicts << endl;

    cout << "block numbers in queue:";
    list<BlockNumber> l = list_of_block_nums();
    for (list<BlockNumber>::iterator i = l.begin(); i != l.end(); i++)
      cout << hex << *i << " ";
    cout << endl << "block numbers in LRU queue:";
    l = lru_stats_sim->list_of_block_nums();
    for (list<BlockNumber>::iterator i = l.begin(); i != l.end(); i++)
      cout << hex << *i << " ";
    cout << dec << endl;
  }

public:

  // Output the number of faults incurred by both plain LRU and
  // early-eviction LRU, as well as the number of compulsory faults.
  void output (ostream& LRUStream,
	       ostream& EELRUStream,
	       ostream& compulsoryStream) {

    // Write out the number of faults incurred by LRU.
    LRUStream << plain_lru_misses << endl;

    // Write out the number of faults incurred by early-eviction LRU.
    EELRUStream << misses << endl;

    // Write out the number of compulsory faults.
    compulsoryStream << compulsory_faults << endl;

  }  
};


#ifdef STANDALONE_RLY
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 6) {
    cerr << "usage: " << argv[0] << 
      " <LRU queue size> <earliness> <eviction_probability> <decay_factor>"
	 << " <far_miss_weight>" << endl;
    exit(1);
  }
  int queue_size;
  double earliness, eviction_prob, decay_factor, far_miss_weight;
  (istrstream)(argv[1]) >> queue_size;
  (istrstream)(argv[2]) >> earliness;
  (istrstream)(argv[3]) >> eviction_prob;
  (istrstream)(argv[4]) >> decay_factor;
  (istrstream)(argv[5]) >> far_miss_weight;
  RlySim q(queue_size, earliness, eviction_prob, decay_factor, far_miss_weight,
	   my_in);
  q.simulate();
  q.disp();
}

#endif

