// lrusmooth.cpp --- a simulator for a totalitarian variant of LRU in
//                  which pages are evicted early if it looks worthwhile
//                  to do so, so that other pages can stay in longer

// An lru-smooth simulator (i.e., an instance of RlySmooth) simulates a 
// given size of memory and may evict early from a particular lru 
// position. This particular version has evolved from the algorithm of
// Wood, Fernandez, and Lang (WFL) but it tries to behave more smoothly before
// the system reaches its steady state. Namely, before the first page ever
// reaches the late position, this algorithm performs early evictions with
// probability equal to the eviction probability (for misses beyond the last
// page in memory in recency order). After the first page reaches the late
// eviction point, the algorithm becomes equivalent to WFL.

// The algorithm keeps state behavior to detect transitions into early-eviction
// mode and reaching the steady state.

#include "lruadaptive.cpp"

class RlySmooth : public RlyMultiple {
protected:
  // The following stats are only valid in early eviction mode. The moment we
  // switch eviction points, these stats need to be reset.
  int last_early_index;     
  /* A "last_early_index" value of NOT_EARLY indicates that we are not
     in early eviction mode, hence the rest of these statistics are invalid! */

  bool steady_state_reached;

public:
  // constructor (mainly calls the superclass constructor)
  RlySmooth(int msize, 
	    double eness[NUM_EARLY_POINTS], 
	    double eprob[NUM_EARLY_POINTS], 
	    double decayf, 
	    double missweight,
	    Input input_object) :
    RlyMultiple(msize, eness, eprob, decayf, missweight, input_object),
    last_early_index(NOT_EARLY), 
    steady_state_reached(false)
  { };

protected:
  // Returns the position to evict early from or NOT_EARLY if we shouldn't
  // evict early
  int evict_early_this_time(BlockNumber block_num) {
    double max_difference = 0.0;
    int early_index = 0;
    forall (i) {
      double gettable_late_hits = 
	(late_hits_lately[i] + early_hits_lately[i]) * 
	(1.0 - early_probability[i]);
      // How many of the late hits would we most likely get?
      if (gettable_late_hits - early_hits_lately[i] > max_difference) {
	max_difference = gettable_late_hits - early_hits_lately[i];
	early_index = i;
      }
    }
    if (max_difference == 0.0) {
      // Plain LRU mode: Reset early eviction stats!
      last_early_index = NOT_EARLY;
      steady_state_reached = false;
    } else {
      if (last_early_index != early_index) { 
	// changing early eviction points. Reset early eviction stats!
	last_early_index = early_index;
	steady_state_reached = false;
      }
      BlockNumber last_block_in_memory = LruQueue::lru_block();
      QueuePos pos_in_histogram =
	lru_stats_sim->block_position(last_block_in_memory);
      // REVIEW: the above could probably be made more efficient since we know
      // that the page is the least recent in memory (e.g., start search from 
      // end)
      if (pos_in_histogram > late_qpos[early_index])
	return NOT_EARLY;
      if (pos_in_histogram == late_qpos[early_index])
	steady_state_reached = true;

      QueuePos block_pos = lru_stats_sim->block_position(block_num);
      // REVIEW: a weird phenomenon is that code in a superclass (e.g., the
      // "touch" code in RlyMultiple) will recompute almost the same information
      // in order to classify the fault as a compulsory miss or not.
      if (steady_state_reached) { // Act exactly like WFL
	if (pos_in_histogram == late_qpos[early_index] &&
	    block_pos > late_qpos[early_index])
	  return NOT_EARLY;
	return early_index;
      } // else
      // if the miss was on a recently touched block, evict early (it only
      // affects the distribution of blocks before the point of the miss). 
      // If the miss is on a non-recently touched block, evict early with the
      // right probability so that eventually when we reach the steady state,
      // blocks will be "uniformly" distributed in the interesting region.
      if (block_pos > pos_in_histogram ||  // NOTE: changed this from "<" to ">" temporarily for a test!!!
	  rand() % 100 < 100*early_probability[early_index])
	return early_index;
    }
    return NOT_EARLY;
  }

};


#ifdef STANDALONE_SMOOTH
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 4 + 2*NUM_EARLY_POINTS) {
    cerr << "usage: " << argv[0] << " <LRU queue size> <earliness values (" << 
      NUM_EARLY_POINTS << ")> <eviction_probabilities (" << NUM_EARLY_POINTS << 
      ")> <decay_factor>" << " <far_miss_weight>" << endl;
    exit(1);
  }
  int queue_size;
  double earliness[NUM_EARLY_POINTS], eviction_prob[NUM_EARLY_POINTS], 
    decay_factor, far_miss_weight;
  (istrstream)(argv[1]) >> queue_size;
  forall (i) 
    (istrstream)(argv[2+i]) >> earliness[i];
  forall (i)
    (istrstream)(argv[2+NUM_EARLY_POINTS+i]) >> eviction_prob[i]; 
  (istrstream)(argv[2 + 2*NUM_EARLY_POINTS]) >> decay_factor;
  (istrstream)(argv[3 + 2*NUM_EARLY_POINTS]) >> far_miss_weight;
  
  RlySmooth q(queue_size, earliness, eviction_prob, decay_factor, 
	      far_miss_weight, my_in);
  q.simulate();
  q.disp();
}

#endif

