// lruadaptive2.cpp --- a simulator for a totalitarian variant of LRU in
//                  which pages are evicted early if it looks worthwhile
//                  to do so, so that other pages can stay in longer

// An lru-early simulator (i.e., an instance of RlyMultiple2) simulates a 
// given size of memory and may evict early from a particular lru 
// position. This particular adaptive version has multiple eviction points
// and adaptively determines the best one to evict from. Having multiple
// eviction points at any time is not the same as having a single eviction
// point and conducting multiple runs. One of the disadvantages is that,
// (as Paul points out) because of the large granularity of histogram regions
// in the single point case, the simulator is actually very conservative on
// when to evict early. In this version we try to put back this conservatism in
// the multiple points case by having two kinds of "eviction probabilities".
// The one used to determine the late point and the one used to actually 
// perform the cost-benefit analysis and evict from the early point. The latter
// is the same as the probability we would have for a late eviction point
// twice as far away (from the memory size). [this comes to 2*p/(1+p), where
// p is the former eviction probability.]
// The higher probability also means that, once the simulator starts evicting
// early, it will do so with a higher probability (thus it will also be more
// "aggressive").


#include "lruadaptive.cpp"

class RlyMultiple2 : public RlyMultiple {
  // The "early_probability" in the superclass is only used to determine the 
  // late eviction point

  double adjusted_early_probability[NUM_EARLY_POINTS]; 
  // double percentages of evictions to do early when evicting early (adjusted
  // eviction probability -- see comments at beginning of this module)

public:
  RlyMultiple2(int msize,
	 double eness[NUM_EARLY_POINTS],
	 double eprob[NUM_EARLY_POINTS],
	 double decayf,
	 double missweight,
	 Input input_object) : 
    RlyMultiple(msize, eness, eprob, decayf, missweight, input_object) 
  {
    forall(i) {
      // compute the "adjusted early probability"
      adjusted_early_probability[i] = 2 * early_probability[i] / 
	(1 + early_probability[i]);
    }
  }

protected:
  // Returns the position to evict early from or NOT_EARLY if we shouldn't
  // evict early
  int evict_early_this_time(BlockNumber block_num) {
    /* Late hits don't count as much as early ones, because they're harder to 
       get---things will only be hit in the late part of the queue if they're 
       NOT in the fraction of pages reaching the early eviction point that are 
       evicted early. MAKE SURE WE GET THIS FORMULA RIGHT.  THINK ABOUT EFFECT 
       OF EVICTING AGGRESSIVELY & HOW THAT'S MOSTLY OKAY IF LOOPS REPEAT
       ENOUGH TIMES. */
    double max_difference = 0.0;
    int early_index = 0;
    forall (i) {
      double gettable_late_hits = 
	(late_hits_lately[i] + early_hits_lately[i]) * 
	(1.0 - adjusted_early_probability[i]);
      // How many of the late hits would we most likely get?
      if (gettable_late_hits - early_hits_lately[i] > max_difference) {
	max_difference = gettable_late_hits - early_hits_lately[i];
	early_index = i;
      }
    }
    if (max_difference != 0.0 && 
	rand() % 100 < 100 * adjusted_early_probability[early_index])
      return early_index;
    return NOT_EARLY;
  }
};



#ifdef STANDALONE_MULTIPLE2
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 4 + 2*NUM_EARLY_POINTS) {
    cerr << "usage: " << argv[0] << " <LRU queue size> <earliness values (" << 
      NUM_EARLY_POINTS << ")> <eviction_probabilities (" << NUM_EARLY_POINTS << 
      ")> <decay_factor>" << " <far_miss_weight>" << endl;
    exit(1);
  }
  int queue_size;
  double earliness[NUM_EARLY_POINTS], eviction_prob[NUM_EARLY_POINTS], 
    decay_factor, far_miss_weight;
  (istrstream)(argv[1]) >> queue_size;
  forall (i) 
    (istrstream)(argv[2+i]) >> earliness[i];
  forall (i)
    (istrstream)(argv[2+NUM_EARLY_POINTS+i]) >> eviction_prob[i]; 
  (istrstream)(argv[2 + 2*NUM_EARLY_POINTS]) >> decay_factor;
  (istrstream)(argv[3 + 2*NUM_EARLY_POINTS]) >> far_miss_weight;
  RlyMultiple2 q(queue_size, earliness, eviction_prob, decay_factor, 
		 far_miss_weight, my_in);
  q.simulate();
  q.disp();
}

#endif


