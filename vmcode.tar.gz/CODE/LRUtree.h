/* LRUtree.h

   Yannis Smaragdakis, 1999

   I modified the standard STL red-black tree so
   that it can be used as the basis of an efficient LRU queue implementation.
   (The kind of LRU queue I want to support returns the position of the
   touched block after it is touched.)

   The result is a kind of red-black tree that does *not* store key
   values in the nodes. The key values determining node ordering are
   implicit (they are the recency of each "block" in the LRU queue).
   That is, insertions in this tree can only happen at the leftmost
   end (since any newly inserted block is the most recently touched).
   Nevertheless, when a node is "touched", it is removed from its
   current position and entered at the top of the queue (leftmost leaf
   of the tree). The interesting part is that the recency position of
   the touched node (i.e., how many other nodes precede it) can be
   computed in log time. 

   Note that this data structure has no provision for efficient
   retrieval of nodes according to their value (i.e., retrieval of
   blocks by block number). Instead, an LRUtree can be combined with
   another data structure (e.g., a hash table storing tree
   iterators). In this way, we get fast retrieval of blocks by block
   identifier (due to the hash table) and fast computation of block
   recency (due to the LRUtree).
   

   My additions to the algorithm logic are marked with a "YANNIS" comment.

*/

/*
 *
 * Copyright (c) 1996,1997
 * Silicon Graphics Computer Systems, Inc.
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  Silicon Graphics makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 *
 *
 * Copyright (c) 1994
 * Hewlett-Packard Company
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  Hewlett-Packard Company makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 *
 *
 */

#ifndef __LRUTREE_H
#define __LRUTREE_H

/*

Red-black tree class, designed for use in implementing STL
associative containers (set, multiset, map, and multimap). The
insertion and deletion algorithms are based on those in Cormen,
Leiserson, and Rivest, Introduction to Algorithms (MIT Press, 1990),
except that

(1) the header cell is maintained with links not only to the root
but also to the leftmost node of the tree, to enable constant time
begin(), and to the rightmost node of the tree, to enable linear time
performance when used with the generic set algorithms (set_union,
etc.);

(2) when a node being deleted has two children its successor node is
relinked into its place, rather than copied, so that the only
iterators invalidated are those referring to the deleted node.

*/

#include <stl_algobase.h>
#include <stl_alloc.h>
#include <stl_construct.h>
#include <stl_function.h>

typedef bool __LRUtree_color_type;
const __LRUtree_color_type __LRUtree_red = false;
const __LRUtree_color_type __LRUtree_black = true;

struct __LRUtree_node
{
  typedef __LRUtree_color_type color_type;
  typedef __LRUtree_node* base_ptr;
  typedef __LRUtree_node* link_type;
  

  color_type color; 
  base_ptr parent;
  base_ptr left;
  base_ptr right;
  long int nodes_in_left_subtree; 
  /* YANNIS: This is a counter of all elements in the
     subtree rooted at the left child of this node */

  static base_ptr minimum(base_ptr x)
  {
    while (x->left != 0) x = x->left;
    return x;
  }

  static base_ptr maximum(base_ptr x)
  {
    while (x->right != 0) x = x->right;
    return x;
  }
};


// YANNIS: __LRUnode is the type of node used by the aggregate data structure
// consisting of a hash table and the LRUtree.
template <class Value>
struct __LRUnode : public __LRUtree_node
{
  typedef __LRUnode<Value>* link_type;
  Value value_field;
  link_type next;   // hash table link.
};



struct __LRUtree_base_iterator
{
  typedef __LRUtree_node::base_ptr base_ptr;
  typedef bidirectional_iterator_tag iterator_category;
  typedef ptrdiff_t difference_type;
  base_ptr node;

  void increment()
  {
    if (node->right != 0) {
      node = node->right;
      while (node->left != 0)
        node = node->left;
    }
    else {
      base_ptr y = node->parent;
      while (node == y->right) {
        node = y;
        y = y->parent;
      }
      if (node->right != y)
        node = y;
    }
  }

  void decrement()
  {
    if (node->color == __LRUtree_red &&
        node->parent->parent == node)
      node = node->right;
    else if (node->left != 0) {
      base_ptr y = node->left;
      while (y->right != 0)
        y = y->right;
      node = y;
    }
    else {
      base_ptr y = node->parent;
      while (node == y->left) {
        node = y;
        y = y->parent;
      }
      node = y;
    }
  }
};


template <class Value, class Ref, class Ptr>
struct __LRUtree_iterator : public __LRUtree_base_iterator
{
  typedef Value value_type;
  typedef Ref reference;
  typedef Ptr pointer;
  typedef __LRUtree_iterator<Value, Value&, Value*>             iterator;
  typedef __LRUtree_iterator<Value, const Value&, const Value*> const_iterator;
  typedef __LRUtree_iterator<Value, Ref, Ptr>                   self;
  typedef __LRUnode<Value>* link_type;

  __LRUtree_iterator() {}
  __LRUtree_iterator(link_type x) { node = x; }
  __LRUtree_iterator(const iterator& it) { node = it.node; }


  reference operator*() const { return link_type(node)->value_field; }
#ifndef __SGI_STL_NO_ARROW_OPERATOR
  pointer operator->() const { return &(operator*()); }
#endif /* __SGI_STL_NO_ARROW_OPERATOR */

  self& operator++() { increment(); return *this; }
  self operator++(int) {
    self tmp = *this;
    increment();
    return tmp;
  }
    
  self& operator--() { decrement(); return *this; }
  self operator--(int) {
    self tmp = *this;
    decrement();
    return tmp;
  }
};

inline bool operator==(const __LRUtree_base_iterator& x,
                       const __LRUtree_base_iterator& y) {
  return x.node == y.node;
}

inline bool operator!=(const __LRUtree_base_iterator& x,
                       const __LRUtree_base_iterator& y) {
  return x.node != y.node;
}

#ifndef __STL_CLASS_PARTIAL_SPECIALIZATION

inline bidirectional_iterator_tag
iterator_category(const __LRUtree_base_iterator&) {
  return bidirectional_iterator_tag();
}

inline __LRUtree_base_iterator::difference_type*
distance_type(const __LRUtree_base_iterator&) {
  return (__LRUtree_base_iterator::difference_type*) 0;
}

#endif /* __STL_CLASS_PARTIAL_SPECIALIZATION */

inline void 
__LRUtree_rotate_left(__LRUtree_node* x, __LRUtree_node*& root)
{
  __LRUtree_node* y = x->right;
  y->nodes_in_left_subtree += x->nodes_in_left_subtree + 1;  // YANNIS
  x->right = y->left;
  if (y->left !=0)
    y->left->parent = x;
  y->parent = x->parent;

  if (x == root)
    root = y;
  else if (x == x->parent->left)
    x->parent->left = y;
  else
    x->parent->right = y;
  y->left = x;
  x->parent = y;
}

inline void 
__LRUtree_rotate_right(__LRUtree_node* x, __LRUtree_node*& root)
{
  __LRUtree_node* y = x->left;
  x->nodes_in_left_subtree -= y->nodes_in_left_subtree + 1;  // YANNIS
  x->left = y->right;
  if (y->right != 0)
    y->right->parent = x;
  y->parent = x->parent;

  if (x == root)
    root = y;
  else if (x == x->parent->right)
    x->parent->right = y;
  else
    x->parent->left = y;
  y->right = x;
  x->parent = y;
}

inline void 
__LRUtree_rebalance(__LRUtree_node* x, __LRUtree_node*& root)
{
  x->color = __LRUtree_red;
  while (x != root && x->parent->color == __LRUtree_red) {
    if (x->parent == x->parent->parent->left) {
      __LRUtree_node* y = x->parent->parent->right;
      if (y && y->color == __LRUtree_red) {
        x->parent->color = __LRUtree_black;
        y->color = __LRUtree_black;
        x->parent->parent->color = __LRUtree_red;
        x = x->parent->parent;
      }
      else {
        if (x == x->parent->right) {
          x = x->parent;
          __LRUtree_rotate_left(x, root);
        }
        x->parent->color = __LRUtree_black;
        x->parent->parent->color = __LRUtree_red;
        __LRUtree_rotate_right(x->parent->parent, root);
      }
    }
    else {
      __LRUtree_node* y = x->parent->parent->left;
      if (y && y->color == __LRUtree_red) {
        x->parent->color = __LRUtree_black;
        y->color = __LRUtree_black;
        x->parent->parent->color = __LRUtree_red;
        x = x->parent->parent;
      }
      else {
        if (x == x->parent->left) {
          x = x->parent;
          __LRUtree_rotate_right(x, root);
        }
        x->parent->color = __LRUtree_black;
        x->parent->parent->color = __LRUtree_red;
        __LRUtree_rotate_left(x->parent->parent, root);
      }
    }
  }
  root->color = __LRUtree_black;
}

inline __LRUtree_node*
__LRUtree_rebalance_for_erase(__LRUtree_node* z, __LRUtree_node* header,
			      __LRUtree_node*& root,
			      __LRUtree_node*& leftmost,
			      __LRUtree_node*& rightmost)
{
  __LRUtree_node* y = z;
  __LRUtree_node* x = 0;
  __LRUtree_node* x_parent = 0;
  if (y->left == 0)             // z has at most one non-null child. y == z.
    x = y->right;               // x might be null.
  else
    if (y->right == 0)          // z has exactly one non-null child.  y == z.
      x = y->left;              // x is not null.
    else {                      // z has two non-null children.  Set y to
      y = y->right;             //   z's successor.  x might be null.
      while (y->left != 0)
        y = y->left;
      x = y->right;
    }
  
  // YANNIS begin
  {
    __LRUtree_node* temp = y;
    while (temp->parent != header) {
      if (temp == temp->parent->left)
	temp->parent->nodes_in_left_subtree--;
      temp = temp->parent;
    }
  }
  // YANNIS end
  
  if (y != z) {                 // relink y in place of z.  y is z's successor
    z->left->parent = y; 
    y->left = z->left;
    y->nodes_in_left_subtree = z->nodes_in_left_subtree; // YANNIS
    if (y != z->right) {
      x_parent = y->parent;
      if (x) x->parent = y->parent;
      y->parent->left = x;      // y must be a left child
      y->right = z->right;
      z->right->parent = y;
    }
    else
      x_parent = y;  
    if (root == z)
      root = y;
    else if (z->parent->left == z)
      z->parent->left = y;
    else 
      z->parent->right = y;
    y->parent = z->parent;
    __STD::swap(y->color, z->color);
    y = z;
    // y now points to node to be actually deleted
  }
  else {                        // y == z
    x_parent = y->parent;
    if (x) x->parent = y->parent;   
    if (root == z)
      root = x;
    else 
      if (z->parent->left == z)
        z->parent->left = x;
      else
        z->parent->right = x;
    if (leftmost == z) 
      if (z->right == 0)        // z->left must be null also
        leftmost = z->parent;
    // makes leftmost == header if z == root
      else
        leftmost = __LRUtree_node::minimum(x);
    if (rightmost == z)  
      if (z->left == 0)         // z->right must be null also
        rightmost = z->parent;  
    // makes rightmost == header if z == root
      else                      // x == z->left
        rightmost = __LRUtree_node::maximum(x);
  }
  if (y->color != __LRUtree_red) { 
    while (x != root && (x == 0 || x->color == __LRUtree_black))
      if (x == x_parent->left) {
        __LRUtree_node* w = x_parent->right;
        if (w->color == __LRUtree_red) {
          w->color = __LRUtree_black;
          x_parent->color = __LRUtree_red;
          __LRUtree_rotate_left(x_parent, root);
          w = x_parent->right;
        }
        if ((w->left == 0 || w->left->color == __LRUtree_black) &&
            (w->right == 0 || w->right->color == __LRUtree_black)) {
          w->color = __LRUtree_red;
          x = x_parent;
          x_parent = x_parent->parent;
        } else {
          if (w->right == 0 || w->right->color == __LRUtree_black) {
            if (w->left) w->left->color = __LRUtree_black;
            w->color = __LRUtree_red;
            __LRUtree_rotate_right(w, root);
            w = x_parent->right;
          }
          w->color = x_parent->color;
          x_parent->color = __LRUtree_black;
          if (w->right) w->right->color = __LRUtree_black;
          __LRUtree_rotate_left(x_parent, root);
          break;
        }
      } else {                  // same as above, with right <-> left.
        __LRUtree_node* w = x_parent->left;
        if (w->color == __LRUtree_red) {
          w->color = __LRUtree_black;
          x_parent->color = __LRUtree_red;
          __LRUtree_rotate_right(x_parent, root);
          w = x_parent->left;
        }
        if ((w->right == 0 || w->right->color == __LRUtree_black) &&
            (w->left == 0 || w->left->color == __LRUtree_black)) {
          w->color = __LRUtree_red;
          x = x_parent;
          x_parent = x_parent->parent;
        } else {
          if (w->left == 0 || w->left->color == __LRUtree_black) {
            if (w->right) w->right->color = __LRUtree_black;
            w->color = __LRUtree_red;
            __LRUtree_rotate_left(w, root);
            w = x_parent->left;
          }
          w->color = x_parent->color;
          x_parent->color = __LRUtree_black;
          if (w->left) w->left->color = __LRUtree_black;
          __LRUtree_rotate_right(x_parent, root);
          break;
        }
      }
    if (x) x->color = __LRUtree_black;
  }
  return y;
}

template <class Value, class Alloc = alloc>
class LRUtree {
protected:
  typedef void* void_pointer;
  typedef __LRUtree_node* base_ptr;
  typedef __LRUtree_node LRUtree_node;

  // YANNIS: Note that the allocator is for an extended node!
  typedef simple_alloc<__LRUnode<Value>, Alloc> LRUtree_node_allocator;

  typedef __LRUtree_color_type color_type;
public:
  typedef __LRUnode<Value>* link_type;
  typedef size_t size_type;
  typedef ptrdiff_t difference_type;
protected:
  link_type get_node() { return LRUtree_node_allocator::allocate(); }
  void put_node(link_type p) { LRUtree_node_allocator::deallocate(p); }

  link_type create_node() {
    link_type tmp = get_node();
    __STL_TRY {
      construct(&tmp->nodes_in_left_subtree, 0);
    }
    __STL_UNWIND(put_node(tmp));
    return tmp;
  }

  link_type clone_node(link_type x) {
    link_type tmp = create_node();
    tmp->color = x->color;
    tmp->left = 0;
    tmp->right = 0;
    tmp->nodes_in_left_subtree = x->nodes_in_left_subtree;
    return tmp;
  }

  void destroy_node(link_type p) {
    put_node(p);
  }

protected:
  size_type node_count; // keeps track of size of tree
  link_type header;  

  link_type& root() const { return (link_type&) header->parent; }
  link_type& leftmost() const { return (link_type&) header->left; }
  link_type& rightmost() const { return (link_type&) header->right; }

  static link_type& left(link_type x) { return (link_type&)(x->left); }
  static link_type& right(link_type x) { return (link_type&)(x->right); }
  static link_type& parent(link_type x) { return (link_type&)(x->parent); }
  static color_type& color(link_type x) { return (color_type&)(x->color); }

  static link_type minimum(link_type x) { 
    return (link_type)  __LRUtree_node::minimum(x);
  }
  static link_type maximum(link_type x) {
    return (link_type) __LRUtree_node::maximum(x);
  }

public:
  typedef __LRUtree_iterator<Value, Value &, Value *> iterator;
  typedef __LRUtree_iterator<Value, const Value &, 
    const Value *> const_iterator;

  typedef reverse_iterator<const_iterator> const_reverse_iterator;
  typedef reverse_iterator<iterator> reverse_iterator;

private:
  link_type __copy(link_type x, link_type p);
  void __erase(link_type x);
  void init() {
    header = get_node();
    color(header) = __LRUtree_red; // used to distinguish header from 
                                   // root, in iterator.operator++
    root() = 0;
    leftmost() = header;
    rightmost() = header;
  }
public:
                                // allocation/deallocation
  LRUtree()
    : node_count(0) { init(); }

  LRUtree(const LRUtree<Value, Alloc>& x) 
    : node_count(0)
  { 
    header = get_node();
    color(header) = __LRUtree_red;
    if (x.root() == 0) {
      root() = 0;
      leftmost() = header;
      rightmost() = header;
    }
    else {
      __STL_TRY {
        root() = __copy(x.root(), header);
      }
      __STL_UNWIND(put_node(header));
      leftmost() = minimum(root());
      rightmost() = maximum(root());
    }
    node_count = x.node_count;
  }
  ~LRUtree() {
    clear();
    put_node(header);
  }
  LRUtree<Value, Alloc>& 
  operator=(const LRUtree<Value, Alloc>& x);

public:    
                                // accessors:
  iterator begin() { return leftmost(); }
  const_iterator begin() const { return leftmost(); }
  iterator end() { return header; }
  const_iterator end() const { return header; }
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  const_reverse_iterator rbegin() const { 
    return const_reverse_iterator(end()); 
  }
  reverse_iterator rend() { return reverse_iterator(begin()); }
  const_reverse_iterator rend() const { 
    return const_reverse_iterator(begin());
  } 
  bool empty() const { return node_count == 0; }
  size_type size() const { return node_count; }
  size_type max_size() const { return size_type(-1); }

  void swap(LRUtree<Value, Alloc>& t) {
    __STD::swap(header, t.header);
    __STD::swap(node_count, t.node_count);
  }
    
public:
                                // insert/erase
  iterator insert();

  void erase(iterator position);
  void erase(iterator first, iterator last);
  void clear() {
    if (node_count != 0) {
      __erase(root());
      leftmost() = header;
      root() = 0;
      rightmost() = header;
      node_count = 0;
    }
  }      

public:
  // YANNIS
  long int compute_pos(iterator node_iter)
  {
    base_ptr x = node_iter.node;
    long int counter = node_iter.node->nodes_in_left_subtree + 1;
    while (x->parent != header)
      {
	if (x == x->parent->right)
	  counter += x->parent->nodes_in_left_subtree + 1;
	x = x->parent;
      }
    return counter;
  }

  iterator nth_most_recent(long int pos);

public:
                                // Debugging.
  bool __rb_verify() const;
};


template <class Value, class Alloc>
LRUtree<Value, Alloc>& 
LRUtree<Value, Alloc>::operator=(const LRUtree<Value, Alloc>& x) {
  if (this != &x) {
    clear();
    node_count = 0;
    if (x.root() == 0) {
      root() = 0;
      leftmost() = header;
      rightmost() = header;
    }
    else {
      root() = __copy(x.root(), header);
      leftmost() = minimum(root());
      rightmost() = maximum(root());
      node_count = x.node_count;
    }
  }
  return *this;
}


// YANNIS: This needed quite a bit of rewriting
template <class Value, class Alloc>
typename LRUtree<Value, Alloc>::iterator LRUtree<Value, Alloc>::insert()
{
  link_type y = header;
  link_type x = root();
  bool comp = true;
  while (x != 0) {
    y = x;
    x = left(x);
    y->nodes_in_left_subtree++;
  }

  link_type z = create_node();
  left(y) = z;                // also makes leftmost() = z when y == header
  if (y == header) {
    root() = z;
    rightmost() = z;
  }
  else
    leftmost() = z;           // maintain leftmost() pointing to min node

  parent(z) = y;
  left(z) = 0;
  right(z) = 0;
  __LRUtree_rebalance(z, header->parent);
  ++node_count;

  return iterator(z);
}


// YANNIS: extra method, specific to LRUtrees.
template <class Value, class Alloc>
typename LRUtree<Value, Alloc>::iterator 
LRUtree<Value, Alloc>::nth_most_recent(long int pos) {
  link_type y = header;        // Last node at position not less than pos. 
  link_type x = root();        // Current node. 
  long int nodes_before = pos - 1;

  while (x != 0)
    if (x->nodes_in_left_subtree >= nodes_before) {
      y = x;
      x = left(x);
    }
    else {
      nodes_before -= x->nodes_in_left_subtree + 1;
      x = right(x);
    }
 
  return (iterator(y));   
}

         
template <class Value, class Alloc>
inline void
LRUtree<Value, Alloc>::erase(iterator position) {
  link_type y = (link_type) __LRUtree_rebalance_for_erase(position.node,
							  header,
							  header->parent,
							  header->left,
							  header->right);
  destroy_node(y);
  --node_count;
}

template <class Value, class Alloc>
typename LRUtree<Value, Alloc>::link_type 
LRUtree<Value, Alloc>::__copy(link_type x, link_type p) {
                                // structural copy.  x and p must be non-null.
  link_type top = clone_node(x);
  top->parent = p;
 
  __STL_TRY {
    if (x->right)
      top->right = __copy(right(x), top);
    p = top;
    x = left(x);

    while (x != 0) {
      link_type y = clone_node(x);
      p->left = y;
      y->parent = p;
      if (x->right)
        y->right = __copy(right(x), y);
      p = y;
      x = left(x);
    }
  }
  __STL_UNWIND(__erase(top));

  return top;
}

template <class Value, class Alloc>
void LRUtree<Value, Alloc>::__erase(link_type x) {
                                // erase without rebalancing
  while (x != 0) {
    __erase(right(x));
    link_type y = left(x);
    destroy_node(x);
    x = y;
  }
}

template <class Value, class Alloc>
void LRUtree<Value, Alloc>::erase(iterator first, iterator last) {
  if (first == begin() && last == end())
    clear();
  else
    while (first != last) erase(first++);
}

inline int __black_count(__LRUtree_node* node, __LRUtree_node* root)
{
  if (node == 0)
    return 0;
  else {
    int bc = node->color == __LRUtree_black ? 1 : 0;
    if (node == root)
      return bc;
    else
      return bc + __black_count(node->parent, root);
  }
}

template <class Value, class Alloc> 
bool LRUtree<Value, Alloc>::__rb_verify() const
{
  if (node_count == 0 || begin() == end())
    return node_count == 0 && begin() == end() &&
      header->left == header && header->right == header;
  
  int len = __black_count(leftmost(), root());
  for (const_iterator it = begin(); it != end(); ++it) {
    link_type x = (link_type) it.node;
    link_type L = left(x);
    link_type R = right(x);

    if (x->color == __LRUtree_red)
      if ((L && L->color == __LRUtree_red) ||
          (R && R->color == __LRUtree_red))
        return false;

    if (!L && !R && __black_count(x, root()) != len)
      return false;
  }

  if (leftmost() != __LRUtree_node::minimum(root()))
    return false;
  if (rightmost() != __LRUtree_node::maximum(root()))
    return false;

  return true;
}


#endif /* __LRUTREE_H */
