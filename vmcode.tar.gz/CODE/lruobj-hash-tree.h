// A general purpose LRU queue. It consists of a simple, fixed-size hash
// table that is threaded together with an LRUtree structure (a modified
// red-black tree). The hash table guarantees fast lookup of blocks
// by block address, whileas the LRUtree guarantees fast computation of
// block recencies (i.e., a block's position in the LRU queue) and fast
// retrieval of blocks by recency.

// REVIEW: I can make the two data structures cooperate in a statically
// type safe manner, instead of having casts (see "Casting" comments below).
#ifndef LRUOBJ_H
#define LRUOBJ_H

#include "general.h"
#include "input.h"
#include "LRUtree.h"
#include <iostream.h>
#include <algo.h>

// The following two values are assigned to unsigned variables. Nevertheless,
// no problem should ensue, as regular block addresses will always be multiples
// of the page/block size (which is >=16b for caches, >= 4096b for VM), or
// too small to be confused for these huge numbers (if the input is block
// numbers--i.e., addresses divided by block size).
#define LOWER_LIMIT ((unsigned) -2)
#define NOEVICT ((unsigned) -3)

/* Randomly chosen parameters for the simple hash table we are using */
#define HASH_SIZE    65521
#define HASH_FACTOR1 13
#define HASH_FACTOR2 127


typedef int QueuePos;

class LruEvent {
  BlockNumber block_num;
  QueuePos queue_pos;
  BlockNumber evicted;
  
public:
  LruEvent(BlockNumber b_n, QueuePos q_p, BlockNumber ev) : block_num(b_n), 
    queue_pos(q_p), evicted(ev) { }

  QueuePos queue_position() { return queue_pos; }
  BlockNumber evicted_block() { return evicted; }
  void disp() {
    cout << "#[<lru-event> " << "block-num: " << block_num << 
      " queue-pos: " << queue_pos << " evicted: " << evicted << "]" << endl;
  }
};


class LruQueue {
protected:
  int size;
  Input input_obj;
  
  typedef LRUtree<BlockNumber, alloc> RecencyQueueType;
  typedef __LRUnode<BlockNumber>* LinkType;

  typedef RecencyQueueType::iterator RecencyIterator;

  RecencyQueueType recency_queue;
  LinkType queue[HASH_SIZE];

protected:
  // A very simple hash function
  unsigned int compute_hash(BlockNumber block_num) {
    return (((block_num * HASH_FACTOR1) + HASH_FACTOR2) * block_num) % 
      HASH_SIZE;
  }

  void insert_hash(BlockNumber block_num, RecencyIterator i) {
    LinkType node_p = LinkType(i.node);  // Casting! Unsafe but simple.
    int hash = compute_hash(block_num);
    node_p->value_field = block_num;
    node_p->next = queue[hash];
    queue[hash] = node_p;
  }

  LinkType find_hash(BlockNumber block_num) {
    int hash = compute_hash(block_num);
    LinkType current = queue[hash]; 

    while (current != NULL && current->value_field != block_num)
      current = current->next;

    return current;
  }

  // The block *must* be in the table.
  void erase_hash(BlockNumber block_num) {
    int hash = compute_hash(block_num);
    LinkType current = queue[hash];
    while (current->value_field != block_num &&
	   current->next->value_field != block_num)
      current = current->next;
    // Actual deallocation of the space is the duty of the LRUtree part of 
    // the data structure
    if (current->value_field == block_num)   // must be first in the slot
      queue[hash] = current->next;
    else
      current->next = current->next->next;
  }
      

public:
  int max_size;
  // constructor
  LruQueue(int m_size, Input input_object) : 
    max_size(m_size), size(0), input_obj(input_object), recency_queue() 
    { for (int i = 0; i < HASH_SIZE; i++) queue[i] = NULL; } 
  LruQueue(int m_size) :
    max_size(m_size), size(0), input_obj(&cin), recency_queue() 
    { for (int i = 0; i < HASH_SIZE; i++) queue[i] = NULL; } 

  bool empty() { return (size == 0); }
  bool full() { return (size == max_size); }

  void push_node_on_front(BlockNumber block_num) { 
    //    cerr << "Node " << block_num << " being added\n";
    RecencyIterator i = recency_queue.insert();
    insert_hash(block_num, i);
    //    cerr << "hash ok" << endl;
  }


  virtual LruEvent touch (BlockNumber block_num) {
    LinkType i = find_hash(block_num);

    if (i == NULL) 
      return handle_miss(block_num);
    else {
      RecencyIterator recency_i = RecencyIterator(i);
      return handle_hit(block_num, recency_queue.compute_pos(recency_i), i);
    }
  }

  // returns the set of all blocks that are less recently touched than "from"
  // (which must be in the queue)
  SetOfBlocks& blocks_after (BlockNumber from) {
    SetOfBlocks& result = *(new SetOfBlocks);
    if (from != LOWER_LIMIT) {
      LinkType i = find_hash(from);
      if (i != NULL) {
	RecencyIterator recency_i = RecencyIterator(i);
	recency_i++;
	while (recency_i != recency_queue.end()) {
	  result.insert((LinkType(recency_i.node))->value_field);
	  recency_i++;
	}
      }
    }
    return result;
  }

  // Was "recent" touched more (or equally) recently than "old"?
  bool more_recent (BlockNumber recent, BlockNumber old) {
    if (recent == LOWER_LIMIT)
      return false;
    if (old == LOWER_LIMIT)
      return true;
    
    LinkType i_recent = find_hash(recent);
    if (i_recent == NULL)
      return false;
    else {
      LinkType i_old = find_hash(old);
      if (i_old == NULL)
	return true;
      
      RecencyIterator recency_recent = RecencyIterator(i_recent);
      RecencyIterator recency_old = RecencyIterator(i_old);
      return (recency_queue.compute_pos(recency_recent) < 
	      recency_queue.compute_pos(recency_old));
    }
  }

  // This is useful for algorithms that check if the last page in an RLY
  // LRU queue is in memory (e.g., the Wood, Fernandez, and Lang algorithm).
  BlockNumber lru_block() {
    RecencyIterator lru = --(recency_queue.end());
    return *lru;
  }

  // Return the position of a block. Again, this is useful for
  // sophisticated variants of our eviction algorithm that base decisions on
  // the presence in memory of blocks other than the one currently being
  // touched.
  QueuePos block_position(BlockNumber block_num) {
    LinkType i = find_hash(block_num);
    
    if (i == NULL)
      return size + 1;
    else {
      RecencyIterator recency_i = RecencyIterator(i);
      return recency_queue.compute_pos(recency_i);
    }
  }

protected:  
  virtual BlockNumber evict(BlockNumber block_num) { 
    return evict_lru_block(); 
  }

  LruEvent handle_miss(BlockNumber block_num) {
    BlockNumber evicted = NOEVICT; 
    if (full())
      evicted = evict(block_num);
    push_node_on_front(block_num);
    size++;
    return LruEvent(block_num, 0, evicted);
    // A queue position of 0 signifies a miss.
  }
  
  LruEvent handle_hit(BlockNumber block_num, QueuePos qpos, LinkType i) {
    if (qpos != 1) {
      RecencyIterator recency_i = RecencyIterator(i);
      erase_hash(block_num);   
      // REVIEW: Probably can do without the above with some thought
      recency_queue.erase(recency_i);
      push_node_on_front(block_num);
    }
    return LruEvent(block_num, qpos, NOEVICT);
  }

  BlockNumber evict_lru_block() {
    RecencyIterator lru_block = --recency_queue.end();
     
    BlockNumber block_num = *lru_block;
    erase_hash(block_num);
    recency_queue.erase(lru_block);
    size--;
    return block_num;
  }

  // Always returns a valid block, but if the input pos is beyond the
  // end of the queue, it returns the last block.
  LinkType block_in_pos(QueuePos block_pos) {
    RecencyIterator i = recency_queue.nth_most_recent(block_pos);
    if (i == recency_queue.end())
      --i;
    return LinkType(i.node); // Cast
  }

  BlockNumber evict_nth_mru_block(QueuePos mru_pos) {
    LinkType i = block_in_pos(mru_pos);
    BlockNumber block_num = i->value_field;
    erase_hash(block_num);
    recency_queue.erase(RecencyIterator(i));
    size--;
    return block_num;
  }

  // Simulation methods
public:
  list<BlockNumber> list_of_block_nums() { 
    list<BlockNumber> temp_list;
    for (RecencyIterator i = recency_queue.begin();
	 i != recency_queue.end();
	 i++)
      temp_list.push_back((LinkType(i.node))->value_field);
    return temp_list; 
  }

  virtual void disp() { }

  // "simulate" reads from input
  void simulate() {
    do {
      BlockNumber block = input_obj.get_next();
      if (input_obj.end_of_input())
	break;
#ifdef SHOW_PROGRESS
      static int count = 0;
      if (count % 1000 == 0)
	cout << count << endl;
      count++;
#endif
      touch(block);
    } while (1);
  }

  // "sim" can be used with small inputs for testing purposes (reads from an
  // in-memory input source and produces rich output).
  void sim(list<BlockNumber> trace) {
    list<BlockNumber>::iterator i = trace.begin();
    do {
      cout << "***in sim***" << endl;
      disp();
      if (i != trace.end()) {
	LruEvent event = touch(*i);
	event.disp();
      }
      else {
	cout << "Simulation finished." << endl;
	break;
      }
      i++;
    } while (1);
  }

};

BlockNumber st0[] = {1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4};
BlockNumber st1[] = {10, 5, 10, 5, 10, 5, 7, 10, 5, 7};
BlockNumber st2[] = {1, 5, 1, 5, 6, 5, 1, 5, 1, 5, 7, 8, 9, 8, 7, 1, 5, 1, 5, 
		     7, 8, 6, 5, 1, 22, 20, 21, 8, 5, 6, 7, 8, 9, 1, 5, 1, 5, 
		     6, 5, 1, 5, 1, 22, 20, 21, 19, 17, 16, 8, 9, 8, 7, 1, 5, 
		     17, 5, 6, 5, 17, 18, 1, 6, 7, 8, 9, 10, 11, 12, 8, 9, 10, 
		     11, 12, 1, 5, 1, 6, 5, 8, 9, 10, 11, 12, 13, 14, 15, 16, 
		     11, 12, 13, 14, 15, 16, 15, 1, 6, 5, 8, 9, 10, 21, 20, 22,
		     8, 5, 6, 7, 8, 9};

list<BlockNumber> l0 (st0, st0 + 12);
list<BlockNumber> l1 (st1, st1 + 10);
list<BlockNumber> l2 (st2, st2 +  sizeof(st2)/sizeof(BlockNumber));

#endif

#ifdef STANDALONE_LRU

void main() {
  LruQueue* q;
  q = new LruQueue(5);
  q->sim(l0);
  delete(q);
  q = new LruQueue(5);
  q->sim(l1);
  delete(q);
  q = new LruQueue(5);
  q->sim(l2);
  delete(q);
}

#endif
