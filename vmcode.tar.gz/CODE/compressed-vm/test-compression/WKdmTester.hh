// WKdmTester.hh
// Yannis Smaragdakis -- smaragd@cs.utexas.edu
// June 1999
// 
// Modified version of Scot Kaplan's WKdmTester. It cooperates with a
// modified WKdm implementation and gathers statistics about the frequencies
// of tags in compressed pages.


// Prevent multiple inclusion by surrounding the header file with
// preprocessor directives.
#if !defined (_WKdmTESTER_HH)
#define _WKdmTESTER_HH

#include "WKAlgorithmTester.hh"

class WKdmTester : public WKAlgorithmTester {

public:

  // The default constructor.
  WKdmTester (char* outputFilename, const bool initUseFixedImages) : 
    WKAlgorithmTester(outputFilename, initUseFixedImages) {}

protected:

  // Perform the actual task of analyzing the compression behavior
  // of a given algorithm.
    virtual void performCompressionTest
    (void* uncompressedData,
     unsigned int uncompressedBytes,
     unsigned int& returnCompressedSize,
     four_ints & returnTagFrequencies);

  virtual void performDecompressionTest
    (void* uncompressedData,
     unsigned int uncompressedBytes,
     unsigned int& returnPreDecompressionSize,
     four_ints & returnTagFrequencies);

};



#endif // _WKdmTESTER_HH
