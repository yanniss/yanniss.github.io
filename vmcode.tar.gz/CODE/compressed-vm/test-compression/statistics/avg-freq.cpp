/* A simple program that reads a "trace" with compressibility info (including
   tag frequencies) and outputs the average frequencies */

#include "compinput.h"
#include <iostream.h>

int main() {
  CompInput my_in(&cin);
  static 
    double num_records = 0.0, 
    avg_mismatch = 0.0, 
    avg_partial = 0.0,
    avg_total = 0.0,
    avg_zero = 0.0;

  do {
    EventInfo event = my_in.get_next();
    if (my_in.end_of_input())
      break;

    if (event.eviction_tag != 'N') {
      avg_mismatch = ((avg_mismatch * num_records) + event.tagFrequencies[0]) /
	(num_records + 1);
      avg_partial = ((avg_partial * num_records) + event.tagFrequencies[1]) /
	(num_records + 1);
      avg_total = ((avg_total * num_records) + event.tagFrequencies[2]) /
	(num_records + 1);
      avg_zero = ((avg_zero * num_records) + event.tagFrequencies[3]) /
	(num_records + 1);
      num_records++;
    }
  } while (1);
  
  cout << "Average mismatched words per page: " << avg_mismatch << endl;
  cout << "Average partially matched words per page: " << avg_partial << endl;
  cout << "Average totally matched words per page: " << avg_total << endl;
  cout << "Average zero words per page: " << avg_zero << endl << endl;

  // The following is here temporarily
  double cost[3];
  cost[0] =     
    avg_mismatch * 4.0 + avg_partial * 4.0 + avg_total * 2.0 + avg_zero * 3.0;
  cost[1] = 
    avg_mismatch * 3.0 + avg_partial * 4.0 + avg_total * 4.0 + avg_zero * 1.0;
  cost[2] =
    avg_mismatch * 2.0 + avg_partial * 4.0 + avg_total * 4.0 + avg_zero * 3.0;

  cout << "Cost of first code layout: " << cost[0] << endl;
  cout << "Cost of second code layout: " << cost[1] << endl;
  cout << "Cost of third code layout: " << cost[2] << endl;
  cout << endl;
  cout << "Benefit of second over first: " << (cost[0] - cost[1]) / cost[1] <<
    endl;
  cout << "Benefit of third over first: " << (cost[0] - cost[2]) / cost[2] <<
    endl;

}
