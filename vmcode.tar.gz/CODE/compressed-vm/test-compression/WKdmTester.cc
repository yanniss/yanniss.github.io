// WKdmTester.cc
// Yannis Smaragdakis -- smaragd@cs.utexas.edu
// June 1999
// 
// Modified version of Scot Kaplan's WKdmTester. It cooperates with a
// modified WKdm implementation and gathers statistics about the frequencies
// of tags in compressed pages.


#include <iostream.h>
#include "WKdmTester.hh"
#include "WKdm.h"


const unsigned int bytesPerWK_word = sizeof(WK_word) / sizeof(char);


// The following is a HACK, but a good one. In order to avoid modifying
// the core WKdm algorithm, we read the interesting statistics directly
// from its output header. Hence, this routine has knowledge of the WKdm
// headers.

// Note that these statistics are not exact because of the padding of
// entire words by the compressor. Hence, we may overestimate the total
// matches by up to 7 (since a word fits 8 entries and up to 7 may be unused)
// and the number of partial matches by up to 2. The discrepancy is so
// small that we can ignore it for now.
void statisticsHack(four_ints & returnTagFrequencies, 
		    WK_word *compressionBuffer) {
  
  // How many mismatches?
  returnTagFrequencies[0] = compressionBuffer[1] - 68;

  // How many matches (partial or total)?
  int matches = (compressionBuffer[2] - compressionBuffer[1]) * 8;
  
  // How many partial matches?
  returnTagFrequencies[1] = (compressionBuffer[3] - compressionBuffer[2]) * 3;
  // a full word packs 3-tenbits of low-bit values

  // How many total matches? (All matches minus partial matches)
  returnTagFrequencies[2] = matches - returnTagFrequencies[1];

  // How many zeros? (The rest of the tags)
  // If it's obviously wrong, try to correct a little
  int temp = 1024 - matches - returnTagFrequencies[0];
  returnTagFrequencies[3] = temp > 0 ? temp : 0;
}


// Perform the actual task of gathering statistics on the compression
void
WKdmTester::performCompressionTest
(void* uncompressedData,
 unsigned int uncompressedBytes,
 unsigned int& returnCompressedSize,
 four_ints & returnTagFrequencies) {
  
  // I don't get it. Why such a large buffer? (YANNIS)
  WK_word compressionBuffer[4 * uncompressedBytes / bytesPerWK_word];

  returnCompressedSize =
    WKdm_compress((WK_word*)uncompressedData,
		  compressionBuffer,
		  uncompressedBytes / bytesPerWK_word);

  statisticsHack(returnTagFrequencies, compressionBuffer);
}



// Perform the actual task of timing the decompression algorithm.
void
WKdmTester::performDecompressionTest
  (void* uncompressedData,
   unsigned int uncompressedBytes,
   unsigned int& returnPreDecompressionSize,
   four_ints& returnTagFrequencies) {

  unsigned int uncompressedWords = uncompressedBytes / bytesPerWK_word;
  WK_word compressionBuffer[4 * uncompressedWords];
  WK_word decompressionBuffer[uncompressedWords];

  // Get a compressed copy of the page so that the decompression can
  // be performed.
  returnPreDecompressionSize =
    WKdm_compress((WK_word*)uncompressedData,
		  compressionBuffer,
		  uncompressedWords);

  statisticsHack(returnTagFrequencies, compressionBuffer);

  // No need to decompress anything for these statistics
  //  WKdm_decompress(compressionBuffer,
  //		  decompressionBuffer,
  //              uncompressedWords);

  
}
