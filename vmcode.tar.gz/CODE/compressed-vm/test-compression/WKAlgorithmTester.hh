// WKAlgorithmTester.hh
// Yannis Smaragdakis -- smaragd@cs.utexas.edu
// June 1999

// Based on Scott Kaplan's CompressionAlgorithmTester class, this abstract
// class (WKAlgorithmTester) is specialized for gathering interesting
// WK algorithm statistics. In particular, we care about the frequencies of
// WK tags during the compression of a trace. I.e., how many times do we
// have a partial match, total match, zero word, or no-match?
// A subclass of this abstract class
// should act as a wrapper for calls to particular WK compression and
// decompression algorithms.  Moreover, this class provides the
// functionality required to keep statistics for the results of
// compression tests performed on such subclasses.



// Prevent multiple inclusion by surrounding the header file with
// preprocessor directives.
#if !defined (_WKALGORITHMTESTER_HH)
#define _WKALGORITHMTESTER_HH



#include <String.h>
#include "zlib.h"
#include "TraceRecord.hh"


typedef unsigned int four_ints[4];


class WKAlgorithmTester {

public:

  // Open an output file whose name is based on the algorithm name
  // returned by the getAlgorithmName() private method.
  WKAlgorithmTester (char* outputFilename,
			      const bool initUseFixedImages);

  ~WKAlgorithmTester ();

  // Test the compression and output the results to the output file.
  void test (TraceRecord* currentRecord,
	     unsigned int uncompressedBytes);

protected:

  // The compressed output file to which test results are written as a
  // trace.
  gzFile outputFile;

  // A flag that indicates whether or not the fixed endianness verion
  // of each page image needs to be used.
  bool useFixedImages;

  // Perform the actual task of analyzing the compression behavior
  // of a given algorithm.  (The methods above really
  // just collect statistics, and rely on these protected methods to
  // perform the actual tests.)  These methods need to be specified in
  // the subclass.
  virtual void performCompressionTest
    (void* uncompressedData,
     unsigned int uncompressedBytes,
     unsigned int& returnCompressedSize,
     four_ints & returnTagFrequencies) = 0;

  virtual void performDecompressionTest
    (void* uncompressedData,
     unsigned int uncompressedBytes,
     unsigned int& returnPreDecompressionSize,
     four_ints & returnTagFrequencies) = 0;

  // This method is called after each test is performed.  It writes to
  // the output stream relevant information from the trace record
  // (everything but the page image) and the results of these tests.
  void outputResults (TraceRecord* currentRecord,
		      unsigned int compressedSize,
		      unsigned int tagFrequencies[4],
		      unsigned int preDecompressedSize,
		      unsigned int decompressedTagFrequencies[4]);

};

#endif // _WKALGORITHMTESTER_HH
