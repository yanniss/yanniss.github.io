// A simple program to read in references and output them numbered in order.
// Useful for turning traces into gnuplot input.
#include <iostream.h>

int main() {
  int page, i=0;
  while (cin.good()) {
    cin >> page;
    cout << i++ << " " << page << endl;
  }
}
  
