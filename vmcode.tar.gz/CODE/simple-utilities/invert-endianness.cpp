// A very simple utility to invert the endianness of the references
// represented in hex in the input stream. Not maximally efficient, but
// it shouldn't matter.
#include <iostream.h>

int main() {
  unsigned int reference, new_reference;
  while (1) {
    cin >> hex >> reference;
    if (!cin.good())
      break;
    char *p_new, *p_old;
    p_new = (char *)(&new_reference) + 3;
    p_old = (char *)(&reference);
    *p_new-- = *p_old++;
    *p_new-- = *p_old++;
    *p_new-- = *p_old++;
    *p_new = *p_old;
    cout << hex << new_reference << endl;
  }
}
