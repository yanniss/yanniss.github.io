#include <stdio.h>
main() {
  char line[80];

  while(gets(line) != 0)
	puts(line+2);
}
