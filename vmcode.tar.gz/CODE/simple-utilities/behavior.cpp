// Given a trace, output its LRU behavior as pairs of 
// <fetched block, evicted block> values.
#include <iostream.h>
#include <strstream.h>
#include <list.h>
#include "lruobj.h"
#include "input.h"

class Behavior {
  LruQueue lru_queue; // The LRU queue used as our filter
  Input input_obj;

public:
  Behavior(int queue_size, Input input_object) : lru_queue(queue_size), 
    input_obj(input_object) { }
  void simulate() {
    if (!input_obj.end_of_input()) {
      do {
	BlockNumber next_block = input_obj.get_next();
	if (!input_obj.end_of_input()) {
	  LruEvent event = lru_queue.touch(next_block);
	  if (event.queue_position() == 0)
	    cout << hex << next_block << " " << hex << 
		event.evicted_block() << endl;
	}
	else break;
      } while(1);
    }
  }
};

#ifdef STANDALONE_BEHAVIOR
// For testing
Input my_in(&cin);

void main(int argc, char** argv) {
  if (argc != 2) {
    cerr << "usage: " << argv[0] << " <LRU queue size>" << endl;
    exit(1);
  }
  int queue_size;
  istrstream ist(argv[1]);
  ist >> queue_size;
  Behavior behavior(queue_size, my_in);
  behavior.simulate();
}

#endif
