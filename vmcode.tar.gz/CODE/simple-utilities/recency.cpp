// A simple client of an LRU queue: it reads in references and spits out 
// the position of the corresponding pages in the LRU cache.
#include <iostream.h>
#include <strstream.h>
#include <list.h>
#include "lruobj.h"
#include "input.h"

void main(int argc, char** argv) {
  Input my_in(&cin);
  if (argc != 3) {
    cerr << "usage: " << argv[0] << " <LRU queue max. size> <min. interesting size>" << endl;
    exit(1);
  }
  int queue_size, min_size;
  (istrstream)(argv[1]) >> queue_size;
  (istrstream)(argv[2]) >> min_size;
  LruQueue queue(queue_size);
  while (!my_in.end_of_input()) {
    BlockNumber next_block = my_in.get_next();
    if (!my_in.end_of_input()) {
      LruEvent event = queue.touch(next_block);
      if (event.queue_position() > min_size)
	cout << event.queue_position() << endl;
    }
  }
}
