/* A very simple experiment with blocking. Re-block everything (increase
  the page size by n by merging n pages into one) */
#include <iostream.h>
#include <strstream.h>

int main(int argc, char** argv) {
  if (argc != 2) {
    cerr << "usage: " << argv[0] << " <block ratio>" << endl;
    exit(1);
  }

  int block_ratio;
  istrstream ist(argv[1]);
  ist >> block_ratio;
  int page, previous, blocked;
  bool first = true;

  while(1) {
    cin >> hex >> page;
    if (!cin.good())
      break;
    blocked = page/block_ratio;
    
    /* We only emit one reference for repeated touches to the same block */
    if (first || blocked != previous) {
      first = false;
      cout << hex << blocked << endl;
    }
    previous = blocked;
  }
	
}
