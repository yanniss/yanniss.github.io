/* A dynamic proxy example. The code is inspired from:
   http://docs.oracle.com/javase/7/docs/technotes/guides/reflection/proxy.html
*/

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("== Object of type A ==");
        A a = new A();
        a.report("Test message.");
	System.out.println("Method get() returns: " + a.get());

	System.out.println();

        System.out.println("== Dynamic proxy of I that delegates calls to a of type A ==");
	Class[] interfaces = new Class[1];
	interfaces[0] = I.class;
        I proxy = (I)Proxy.newProxyInstance(Main.class.getClassLoader(),
					    interfaces, new AHandler(a));
        proxy.report("Test message via dynamic proxy.");
	System.out.println(proxy.calc(1, 2));
	System.out.println("Method get() returns: " + proxy.get());
    }
}

interface I {
    void report(String c);
    int calc(int a, int b);
    Object get();
}

class A {
    public void report(String c) {
        System.out.println(c);
    }
    public Object get() {
	return new Object();
    }
}

class AHandler implements InvocationHandler {
    private A a;
    public AHandler(A a) { this.a = a; }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("* The dynamic proxy handler was called...");
        if (method.getName().equals("report") && (args.length==1) && args[0] instanceof String) {
            a.report((String)args[0]);
        } else if (method.getName().equals("calc") && (args.length==2)) {
	    int arg_a = (int)args[0];
	    int arg_b = (int)args[1];
	    System.out.println("Calculating " + arg_a + " + " + arg_b);
	    return arg_a + arg_b;
	} else if (method.getName().equals("get")) {
	    System.err.println("Sorry, method get() may not be called.");
	} else {
	    System.err.println("Unsupported method: " + method.getName());
	}
        return null;
    }
}
